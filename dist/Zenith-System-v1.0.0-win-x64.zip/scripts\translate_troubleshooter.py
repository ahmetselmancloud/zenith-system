import re

with open('src/system_troubleshooter.py', 'r', encoding='utf-8') as f:
    text = f.read()

replacements = [
    ('"category_name": "🌐 Ağ & İnternet"', '"category_name": "🌐 Network & Internet"'),
    ('"title": "DNS Önbelleğini Temizle"', '"title": "Flush DNS Cache"'),
    ('"description": "Bozuk veya eski DNS kayıtlarını temizleyerek web sitelerine erişim sorunlarını giderir."', '"description": "Clears corrupted or outdated DNS cache to resolve website connection and resolution issues."'),
    ('"title": "Winsock & TCP/IP Yığını Sıfırla"', '"title": "Reset Winsock & TCP/IP Stack"'),
    ('"description": "Bozulan internet bağlantısını, soket çakışmalarını ve IP yığınını fabrika ayarlarına döndürür."', '"description": "Resets corrupted socket state, IP routes, and TCP/IP stack to clean factory defaults."'),
    ('"title": "ARP Önbelleğini Temizle"', '"title": "Clear ARP Cache"'),
    ('"description": "Yerel ağ yönlendirici (modem/router) IP-MAC eşleşme tablosunu sıfırlar."', '"description": "Flushes local subnet router and gateway IP-to-MAC resolution cache."'),
    ('"title": "Tam Ağ & İnternet Onarımı (Hepsi)"', '"title": "Full Network & Internet Stack Repair"'),
    ('"description": "DNS, Winsock, TCP/IP ve ARP yığınının tümünü tek seferde sıfırlayıp onarır."', '"description": "Comprehensively flushes DNS, resets Winsock, reinitializes TCP/IP stack and clears ARP cache in one click."'),
    ('"category_name": "🔊 Ses & Medya"', '"category_name": "🔊 Audio & Media"'),
    ('"title": "Windows Ses Servislerini Yeniden Başlat"', '"title": "Restart Windows Audio Services"'),
    ('"description": "Kilitlenen, ses vermeyen veya donan kulaklık/hoparlör sürücü servislerini (AudioSrv) anında sıfırlar."', '"description": "Restarts locked or unresponsive Windows audio endpoints, engine, and AudioSrv services."'),
    ('"category_name": "🖨️ Yazdırma & Donanım"', '"category_name": "🖨️ Printing & Hardware"'),
    ('"title": "Yazdırma Kuyruğunu & Spooler\'ı Temizle"', '"title": "Clear Print Queue & Restart Spooler"'),
    ('"description": "Kuyrukta takılıp yazıcıyı kilitleyen belgeleri temizler ve yazdırma servisini yeniden başlatır."', '"description": "Purges stuck print jobs from spool directory and restarts the Windows Print Spooler service."'),
    ('"category_name": "📁 Gezgin & Masaüstü"', '"category_name": "📁 Explorer & Desktop"'),
    ('"title": "Windows Gezginini Yeniden Başlat"', '"title": "Restart Windows Explorer"'),
    ('"description": "Donan görev çubuğu, açılmayan klasörler ve yanıt vermeyen masaüstünü anında sıfırlar."', '"description": "Restarts explorer.exe to resolve frozen taskbars, unresponsive shell, and hung file dialogs."'),
    ('"title": "Windows Arama İndeks Servisini Onar"', '"title": "Repair Windows Search Indexer"'),
    ('"description": "Başlat menüsünde arama yapılamadığında WSearch dizin servisini sıfırlayıp yeniden başlatır."', '"description": "Restarts Windows Search service (WSearch) to fix non-responsive search and indexing glitches."'),
    ('"category_name": "🛡️ Sistem & Güncelleme"', '"category_name": "🛡️ System & Updates"'),
    ('"title": "Bozuk Windows Update Önbelleğini Temizle"', '"title": "Purge Corrupted Windows Update Cache"'),
    ('"description": "Takılan veya hata veren güncellemelerin indirme önbelleğini (SoftwareDistribution) sıfırlar."', '"description": "Stops update services, empties SoftwareDistribution download cache, and restarts update engine."'),
    ('"title": "Microsoft Store Önbelleğini Sıfırla"', '"title": "Reset Microsoft Store Cache (WSReset)"'),
    ('"description": "Açılmayan veya indirme hatası veren Microsoft Store mağazasını sıfırlar."', '"description": "Executes WSReset to clear Windows Store cache and resolve store download hangs."'),
    ('"category_name": "🛡️ Derin Sistem Bütünlüğü (SFC / DISM)"', '"category_name": "🛡️ Deep System Integrity (SFC / DISM)"'),
    ('"title": "SFC /scannow (Bozuk Sistem Dosyalarını Onar)"', '"title": "SFC /scannow (System File Checker)"'),
    ('"description": "Windows çekirdek sistem dosyalarını tarar, bozulmuş veya silinmiş olanları Microsoft önbelleğinden onarır."', '"description": "Scans Windows core protected system files and replaces corrupted files from cached system images."'),
    ('"cmd_desc": "sfc /scannow (Arka planda çalışır)"', '"cmd_desc": "sfc /scannow (Executes asynchronously in background)"'),
    ('"title": "DISM RestoreHealth (Bileşen Deposunu Onar)"', '"title": "DISM RestoreHealth (Component Store Repair)"'),
    ('"description": "Windows Component Store (WinSxS) hasarlarını Microsoft resmi sunucularından indirerek onarır."', '"description": "Repairs Windows Component Store (WinSxS) corruption directly using official Windows Update recovery sources."'),
    ('"cmd_desc": "DISM.exe /Online /Cleanup-image /Restorehealth"', '"cmd_desc": "DISM.exe /Online /Cleanup-image /Restorehealth"'),
    ('"Başka bir onarım görevi şu an arka planda çalışıyor."', '"Another repair task is currently running in the background."'),
    ('"DNS önbelleği başarıyla temizlendi."', '"DNS cache flushed successfully."'),
    ('"Winsock katalog sıfırlandı."', '"Winsock catalog reset successfully."'),
    ('"TCP/IP yığını sıfırlandı."', '"TCP/IP stack reinitialized successfully."'),
    ('"ARP önbelleği silindi."', '"ARP cache deleted successfully."'),
    ('"✓ DNS Önbelleği temizlendi."', '"✓ DNS cache flushed."'),
    ('"✓ Winsock ve TCP/IP bağlantı yığını sıfırlandı."', '"✓ Winsock and TCP/IP stack reset."'),
    ('"Tüm ağ bileşenleri başarıyla onarıldı."', '"All network components repaired successfully."'),
    ('"✓ Windows Ses (AudioSrv) ve Ses Bitiş Noktası servisleri yeniden başlatıldı."', '"✓ Windows Audio (AudioSrv) and Audio Endpoint services restarted."'),
    ('"✓ Yazıcı kuyruğu temizlendi ve Print Spooler servisi yeniden başlatıldı."', '"✓ Print spool queue cleared and Print Spooler restarted."'),
    ('"✓ Windows Gezgini (explorer.exe) yeniden başlatıldı."', '"✓ Windows Explorer (explorer.exe) restarted successfully."'),
    ('"✓ Windows Search dizin arama servisi yeniden başlatıldı."', '"✓ Windows Search (WSearch) indexer restarted."'),
    ('"✓ Bozuk Windows Update indirme önbelleği temizlendi ve servisler sıfırlandı."', '"✓ Corrupted Windows Update download cache cleared and services reinitialized."'),
    ('"✓ Microsoft Store önbellek sıfırlama işlemi başlatıldı (wsreset.exe)."', '"✓ Microsoft Store cache reset initiated (wsreset.exe)."'),
    ('"Görev arka planda başlatıldı. İlerlemeyi canlı konsoldan izleyebilirsiniz."', '"Task started in background. Follow live progress in console."'),
    ('f"Bilinmeyen onarım aracı: {tool_id}"', 'f"Unknown repair tool: {tool_id}"'),
    ('derin sistem onarımı başlatılıyor...', 'deep system repair initiated...'),
    ('onarım görevi başarıyla tamamlandı!', 'repair task completed successfully!'),
    ('Görev tamamlandı (Çıkış Kodu:', 'Task completed (Exit code:'),
    ('Hata oluştu:', 'Error occurred:')
]

for src, dst in replacements:
    text = text.replace(src, dst)

with open('src/system_troubleshooter.py', 'w', encoding='utf-8') as f:
    f.write(text)

remaining = len(re.findall(r'[çÇğĞıİöÖşŞüÜ]', text))
print(f"Troubleshooter translated. Remaining Turkish characters: {remaining}")
