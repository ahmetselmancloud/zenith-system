import re

with open('web/index.html', 'r', encoding='utf-8') as f:
    text = f.read()

replacements = [
    ('title="Tıkla: Güncellemeleri Denetle"', 'title="Click: Check for Updates"'),
    ('title="Detaylı Sistem & OBD Sağlık Raporunu Görüntüle / PDF Olarak Kaydet">\n              📄 Rapor İndir', 'title="View Detailed System & OBD Health Report / Save as PDF">\n              📄 Download Report'),
    ('title="Tema Değiştir (Midnight / AMOLED / Cyber)"', 'title="Switch Theme (Midnight / AMOLED / Cyber)"'),
    ('Format sonrası veya yeni sistem için tek tıkla otomatik paket kurulum presetleri', 'One-click automated package installation presets for fresh installs or new systems'),
    ('Microsoft WinGet resmi deposundan 180+ popüler uygulama, canlı arama ve güncelleme takibi', '180+ popular apps from official Microsoft WinGet repo, live search and upgrade tracker'),
    ('<span>🔄 Güncellemeleri Tara</span>', '<span>🔄 Check for Updates</span>'),
    ('<span>Seçilenleri Kur (<span id="winget-selected-count">0</span>)</span>', '<span>Install Selected (<span id="winget-selected-count">0</span>)</span>'),
    ('placeholder="🔍 Microsoft WinGet deposunda canlı ara (örn: obs, vlc, git, discord, rust, blender)..."', 'placeholder="🔍 Live search Microsoft WinGet repo (e.g. obs, vlc, git, discord, rust, blender)..."'),
    ('<button class="winget-pill active" data-cat="all">Tümü (150+)</button>', '<button class="winget-pill active" data-cat="all">All (150+)</button>'),
    ('<button class="winget-pill" data-cat="browsers">🌐 Tarayıcılar</button>', '<button class="winget-pill" data-cat="browsers">🌐 Browsers</button>'),
    ('<button class="winget-pill" data-cat="development">💻 Geliştirici</button>', '<button class="winget-pill" data-cat="development">💻 Development</button>'),
    ('<button class="winget-pill" data-cat="communication">💬 İletişim</button>', '<button class="winget-pill" data-cat="communication">💬 Communication</button>'),
    ('<button class="winget-pill" data-cat="security">🔒 Güvenlik</button>', '<button class="winget-pill" data-cat="security">🔒 Security</button>'),
    ('<button class="winget-pill" data-cat="network">📡 Ağ</button>', '<button class="winget-pill" data-cat="network">📡 Network</button>'),
    ('Katalog yükleniyor...', 'Loading catalog...'),
    ('⏳ İşlem yapılıyor...', '⏳ Processing...'),
    ('Konsolu Gizle/Göster', 'Toggle Console'),
    ('Hazır. Kurulum başlatıldığında arka plan çıktıları burada canlı akacaktır.', 'Ready. Installation logs will stream live here when started.'),
    ("Windows'un en can sıkıcı ağ, ses, gezgin, yazdırma ve sistem dosyası sorunlarını tek tıkla onarın", 'One-click repair for Windows network, audio, explorer, print spooler and system file issues'),
    ('✓ Sistem Hazır', '✓ System Ready'),
    ('Derin Sistem Onarımı Çalışıyor...', 'Deep System Repair in Progress...'),
    ('Komut başlatılıyor...', 'Initiating command...'),
    ('Onarım araçları yükleniyor...', 'Loading repair tools...'),
    ('Sisteminizi arka planda izleyen akıllı IF/THEN kuralları. Oyun açılınca fanı ve güç planını yönetir, aşırı ısınmayı önler ve pil tasarrufu sağlar.', 'Intelligent background IF/THEN automation rules. Tunes fans and power schemes on game launches, prevents overheating and saves battery.'),
    ('title="Kuralları hemen kontrol et">⚡ Şimdi Değerlendir</button>', 'title="Evaluate rules now">⚡ Evaluate Now</button>'),
    ('<span class="chip-label">Çalışma Döngüsü</span>', '<span class="chip-label">Polling Interval</span>'),
    ('<span class="chip-label">Otomatik Geri Dönüş</span>', '<span class="chip-label">Auto-Revert</span>'),
    ('Sistem Otomasyon Kuralları', 'System Automation Rules'),
    ('Aktif kurallar arka planda otomatik olarak tetiklenir ve koşul sona erdiğinde sistemi eski durumuna döndürür', 'Active rules trigger automatically in the background and revert changes when conditions clear'),
    ('Kurallar yükleniyor...', 'Loading rules...'),
    ('Otomasyon Etkinlik & Tetikleme Günlüğü', 'Automation Event & Trigger Log'),
    ('Günlüğü Temizle', 'Clear Log'),
    ('Henüz bir kural tetiklenmedi...', 'No automation rules triggered yet...'),
    ('<h3>🚗 Zenith PC OBD-II — Donanım Ekspertizi & Derin Check-Up</h3>', '<h3>🚗 Zenith PC OBD-II — Hardware Diagnostics & Deep Check-Up</h3>'),
    ('Otomobil arıza tespit cihazı (OBD-II) mantığıyla tüm donanım hatlarını, PCIe veri yollarını, WHEA kayıtlarını ve soket temassızlıklarını tarar', 'Automotive OBD-II style comprehensive scan for hardware buses, PCIe links, WHEA faults and port disconnects'),
    ('title="Arıza kodlarını sıfırla">Arıza Kodlarını Sıfırla</button>', 'title="Clear trouble codes">Clear Trouble Codes</button>'),
    ('title="OBD Ekspertiz Raporunu HTML/PDF Olarak İndir">📄 HTML Rapor</button>', 'title="Download OBD Diagnostic Report as HTML/PDF">📄 HTML Report</button>'),
    ('⚡ Derin Check-Up Başlat', '⚡ Run Deep Check-Up'),
    ('DONANIM SAĞLIK PUANI (0-100)', 'HARDWARE HEALTH SCORE (0-100)'),
    ('Son Tarama: Az önce', 'Last Scan: Just now'),
    ('Tüm donanım hatları, PCIe veri yolları ve USB/Ses portları kusursuz durumda.', 'All hardware rails, PCIe lanes, and USB/Audio ports are in pristine condition.'),
    ('Donanım alt sistemleri taranıyor...', 'Scanning hardware subsystems...'),
    ('Aktif Arıza Kodları (Diagnostic Trouble Codes - DTC)', 'Active Diagnostic Trouble Codes (DTC)'),
    ('0 Arıza Kodu', '0 Trouble Codes'),
    ('🌐 Canlı Ağ Bağlantıları & Port İzleyici', '🌐 Live Network Connections & Port Monitor'),
    ('Hangi uygulamanın hangi uzak IP ve porta bağlı olduğunu anlık olarak listeler', 'Real-time monitoring of active process connections, remote IPs, and ports'),
    ('Bağlantılar yükleniyor...', 'Loading connections...'),
    ('💻 HAL: Donanım Taranıyor...', '💻 HAL: Scanning Hardware...'),
    ('<span>Harici GPU Kapalı</span>', '<span>Discrete GPU Off</span>'),
    ('Battery Health Care Threshold (Şarj Koruma Eşiği):', 'Battery Health Care Threshold:'),
    ('<h3>Yeni Otomasyon Kuralı Oluştur</h3>', '<h3>Create Automation Rule</h3>'),
    ('Sistem koşullarına göre otomatik aksiyon tetikleyen kural tanımlayın', 'Define automated actions based on real-time system conditions'),
    ('Kural Adı:', 'Rule Name:'),
    ('placeholder="Örn: Render Modu (Blender)"', 'placeholder="e.g. Render Mode (Blender)"'),
    ('Tetikleyici Koşul (IF):', 'Trigger Condition (IF):'),
    ('GPU Sıcaklığı Belirli Eşiği Aşınca (°C)', 'GPU Temperature Exceeds (°C)'),
    ('CPU Yükü Belirli Eşiği Aşınca (%)', 'CPU Load Exceeds (%)'),
    ('Pil Seviyesi Belirli Eşiğin Altına İnince (%)', 'Battery Level Drops Below (%)'),
    ('Gece Saat Aralığı (Örn: 23:00 - 08:00)', 'Night Time Window (e.g. 23:00 - 08:00)'),
    ('Eşik Değeri (°C):', 'Threshold Value (°C):'),
    ('Yürütülecek Eylem (THEN):', 'Action to Execute (THEN):'),
    ('Fan Profilini Değiştir', 'Change Fan Profile'),
    ('Güç Planını Değiştir', 'Change Power Scheme'),
    ('Windows Tuşunu Kilitle', 'Lock Windows Key'),
    ('Masaüstü Bildirimi Gönder', 'Send Desktop Notification'),
    ('Fan: Turbo (Yüksek Performans)', 'Fan: Turbo (High Performance)'),
    ('Fan: Sessiz (Düşük Gürültü)', 'Fan: Silent (Low Noise)'),
    ('Koşul sona erdiğinde sistemi otomatik olarak önceki ayarlara geri döndür (Auto-Revert)', 'Automatically revert to previous system settings when condition clears (Auto-Revert)'),
    ('İptal</button>', 'Cancel</button>'),
    ('Kuralı Kaydet</button>', 'Save Rule</button>')
]

for src, dst in replacements:
    text = text.replace(src, dst)

with open('web/index.html', 'w', encoding='utf-8') as f:
    f.write(text)

remaining = len(re.findall(r'[çÇğĞıİöÖşŞüÜ]', text))
print(f"Translation completed. Remaining Turkish characters in web/index.html: {remaining}")
