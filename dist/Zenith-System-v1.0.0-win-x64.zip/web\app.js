// Zenith System — Client Controller (Vanilla JS, Zero Bloat)

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

const CIRCLE_CIRCUMFERENCE = 264; // 2 * PI * 42

let hardwareData = null;
let lastLiveMetrics = null;
let liveInterval = null;
let lastClickTime = 0;
let clickCount = 0;
const activeKeys = new Set();
const perfHistory = { cpu: [], gpu: [] };

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  setupCompactMode();
  setupThemeEngine();
  setupReportCopy();
  setupDashboardCardModals();
  loadHardwareIdentity();
  startLiveMetrics();
  setupProcessManager();
  setupInstalledApps();
  setupStartupApps();
  setupJunkCleaner();
  setupInstantSearch();
  setupWinGetStore();
  setupTweaks();
  setupDiagnostics();
  setupCpuStressTest();
  setupLaptopStudio();
  setupTroubleshooter();
  setupAutomationRules();
  setupHardwareObd();
  setupNetworkConnectionsMonitor();
  setupUpdateChecker();
  setupHeartbeatAndExitHandler();
});

// --- NAVIGATION ---
function setupNavigation() {
  const navItems = document.querySelectorAll('.nav-item');
  const panes = document.querySelectorAll('.tab-pane');
  const sectionTitle = document.getElementById('section-title');

  navItems.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-tab');
      navItems.forEach(b => b.classList.remove('active'));
      panes.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const targetPane = document.getElementById(targetId);
      if (targetPane) targetPane.classList.add('active');

      sectionTitle.textContent = btn.querySelector('span').textContent;

      if (targetId === 'tab-processes') loadProcesses();
      if (targetId === 'tab-apps') loadInstalledApps();
      if (targetId === 'tab-startup') loadStartupApps();
      if (targetId === 'tab-cleaner') scanJunkCleaner();
      if (targetId === 'tab-storage') loadStorageDiagnostics();
      if (targetId === 'tab-network') { loadWifiDiagnostics(); loadActiveNetworkConnections(); }
      if (targetId === 'tab-power') loadPowerPlans();
      if (targetId === 'tab-laptop') loadLaptopStudioConfig();
      if (targetId === 'tab-troubleshoot') loadTroubleshootTools();
      if (targetId === 'tab-rules') loadAutomationRules();
      if (targetId === 'tab-obd') loadHardwareObdReport();
    });
  });
}

// --- HARDWARE IDENTITY PROBE ---
async function loadHardwareIdentity(forceRefresh = false) {
  try {
    const url = forceRefresh ? '/api/hardware/refresh' : '/api/hardware';
    const method = forceRefresh ? 'POST' : 'GET';
    const res = await fetch(url, { method });
    if (!res.ok) throw new Error('API error ' + res.status);
    hardwareData = await res.json();
    renderHardwareStatic(hardwareData);
  } catch (err) {
    console.warn('Hardware fetch error, trying direct cache fallback:', err);
    try {
      const fbRes = await fetch('/hardware_cache.json');
      if (fbRes.ok) {
        hardwareData = await fbRes.json();
        renderHardwareStatic(hardwareData);
        return;
      }
    } catch (_) {}
    const chip = document.getElementById('cpu-chip-val');
    if (chip && (chip.textContent === '--' || !chip.textContent)) {
      chip.textContent = 'Hardware Ready';
    }
  }
}

function renderHardwareStatic(data) {
  // Top chips
  if (data.cpu?.model) {
    document.getElementById('cpu-chip-val').textContent = data.cpu.model
      .replace(/Intel\(R\)\s*Core\(TM\)\s*/i, '')
      .replace(/AMD\s*Ryzen\s*/i, 'Ryzen ')
      .replace(/Processor/i, '')
      .trim();
    const cTag = document.getElementById('cpu-temp-tag');
    if (cTag) {
      if (data.cpu.p_cores && data.cpu.e_cores) {
        cTag.textContent = `${data.cpu.p_cores}P + ${data.cpu.e_cores}E Cores`;
      } else if (data.cpu.total_cores) {
        cTag.textContent = `${data.cpu.total_cores} Cores`;
      } else {
        cTag.textContent = 'Active';
      }
    }
  }
  if (data.displays?.[0]?.adapter) {
    const rawAdapter = data.displays[0].adapter;
    const cleanAdapter = rawAdapter
      .replace(/NVIDIA\s+GeForce\s+/i, '')
      .replace(/\s+Laptop\s+GPU/i, '')
      .trim();
    document.getElementById('gpu-chip-val').textContent = cleanAdapter;
    const fanGpuLbl = document.getElementById('fan-gpu-temp-label');
    if (fanGpuLbl) fanGpuLbl.textContent = `${cleanAdapter} Temp`;
    const dgpuModeSub = document.getElementById('dgpu-mode-sub');
    if (dgpuModeSub) dgpuModeSub.textContent = `${cleanAdapter} Direct`;
  }
  if (data.battery?.design_capacity_mwh && data.battery?.remaining_mwh) {
    const health = ((data.battery.remaining_mwh / data.battery.design_capacity_mwh) * 100).toFixed(1);
    document.getElementById('bat-chip-val').textContent = `${health}% Bat`;
    const bHealthEl = document.getElementById('bat-health-val');
    if (bHealthEl) bHealthEl.textContent = `${health}%`;
    const bDesignEl = document.getElementById('bat-design-val');
    if (bDesignEl) bDesignEl.textContent = `${(data.battery.design_capacity_mwh / 1000).toFixed(1)} Wh`;
  } else if (!data.battery) {
    const batChip = document.getElementById('bat-chip-val');
    if (batChip) batChip.textContent = 'AC Power';
  }

  // NPU Card on Dashboard
  if (data.npu) {
    document.getElementById('npu-model-name').textContent = data.npu.detected ? data.npu.name : 'Integrated / Host Coprocessor';
    document.getElementById('npu-status-val').textContent = data.npu.detected ? (data.npu.status || 'Ready') : 'Not Detected';
  }

  // Displays Card on Dashboard
  const displaysContainer = document.getElementById('displays-list');
  if (displaysContainer && data.displays) {
    displaysContainer.innerHTML = data.displays.map((disp, i) => `
      <div class="hardware-spec-row">
        <span class="spec-name">Display ${i + 1} (${disp.resolution})</span>
        <span class="spec-value purple">${disp.refresh_rate_hz} Hz</span>
      </div>
    `).join('');
  }

  // Storage Card on Dashboard
  const storageContainer = document.getElementById('storage-list');
  if (storageContainer && data.storage) {
    storageContainer.innerHTML = data.storage.map(disk => `
      <div class="hardware-spec-row">
        <span class="spec-name">${disk.model || 'Storage Disk'}</span>
        <span class="spec-value cyan">${disk.size_gb.toFixed(0)} GB (${disk.bus_type || 'Fixed'})</span>
      </div>
    `).join('');
  }

  // --- TAB 2: DETAILED HARDWARE IDENTITY ---
  const mb = data.motherboard || {};
  const bios = data.bios || {};
  const os = data.os || {};
  const heroTitle = document.getElementById('hw-hero-title');
  if (heroTitle) {
    const mfg = mb.Manufacturer || data.computer_name || 'System';
    const prod = mb.Product || 'Motherboard';
    heroTitle.textContent = `${mfg} ${prod}`.trim();
  }
  const heroSub = document.getElementById('hw-hero-sub');
  if (heroSub) {
    const cpuName = data.cpu?.model || 'Host Processor';
    const gpuName = data.displays?.[0]?.adapter || data.gpus?.[0]?.Name || 'Graphics Adapter';
    const ramStr = data.memory?.total_gb ? `${data.memory.total_gb.toFixed(0)} GB RAM` : 'System RAM';
    const osStr = os.Caption || 'Windows Operating System';
    heroSub.textContent = `${cpuName} • ${gpuName} • ${ramStr} • ${osStr}`;
  }

  // 1. Motherboard & BIOS Table
  const mbTable = document.getElementById('hw-mb-table');
  if (mbTable) {
    mbTable.innerHTML = `
      <div class="hardware-spec-row"><span class="spec-name">Motherboard Manufacturer</span><span class="spec-value cyan">${mb.Manufacturer || 'OEM / System Manufacturer'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Board Product & Model</span><span class="spec-value">${mb.Product || 'System Board'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Hardware Revision</span><span class="spec-value">${mb.Version || 'Default'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Chassis Serial Number</span><span class="spec-value font-mono">${mb.SerialNumber || 'Protected / N/A'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">BIOS Vendor</span><span class="spec-value">${bios.Manufacturer || 'System UEFI BIOS'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">BIOS / UEFI Version</span><span class="spec-value purple font-mono">${bios.SMBIOSBIOSVersion || 'Standard UEFI'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">BIOS Release Date</span><span class="spec-value">${bios.ReleaseDate || '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Firmware Interface</span><span class="spec-value green">UEFI Secure Boot Capable</span></div>
    `;
  }

  // 2. OS & Kernel Table
  const osTable = document.getElementById('hw-os-table');
  if (osTable) {
    osTable.innerHTML = `
      <div class="hardware-spec-row"><span class="spec-name">OS Edition</span><span class="spec-value cyan">${os.Caption || 'Microsoft Windows'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Kernel Architecture</span><span class="spec-value">${os.OSArchitecture || '64-bit'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">OS Build & Release</span><span class="spec-value font-mono">Build ${os.BuildNumber || '--'} ${os.Version ? `(v${os.Version})` : ''}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">System Boot Timestamp</span><span class="spec-value">${os.LastBootUpTime || '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Windows System Root</span><span class="spec-value font-mono">C:\\Windows\\System32</span></div>
      <div class="hardware-spec-row"><span class="spec-name">DirectX Runtime</span><span class="spec-value purple">DirectX 12</span></div>
    `;
  }

  // 3. CPU Deep Table
  const cpuTable = document.getElementById('hw-cpu-table');
  const cpuD = data.cpu_deep || {};
  if (cpuTable) {
    const cpuModel = data.cpu?.model || cpuD.Name || 'x86_64 Processor';
    const totalC = data.cpu?.total_cores || cpuD.NumberOfCores || '--';
    const totalT = data.cpu?.total_threads || cpuD.NumberOfLogicalProcessors || '--';
    const pC = data.cpu?.p_cores;
    const eC = data.cpu?.e_cores;
    const coreDetail = (pC && eC) ? ` (${pC} P-Cores + ${eC} E-Cores)` : '';
    const maxClock = cpuD.MaxClockSpeed ? `${(cpuD.MaxClockSpeed / 1000).toFixed(2)} GHz Turbo` : 'Dynamic';

    cpuTable.innerHTML = `
      <div class="hardware-spec-row"><span class="spec-name">Processor Brand</span><span class="spec-value cyan">${cpuModel}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Physical Cores</span><span class="spec-value">${totalC} Cores${coreDetail}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Logical Hardware Threads</span><span class="spec-value green font-mono">${totalT} Threads</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Clock Frequency</span><span class="spec-value font-mono">${maxClock}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Level 2 (L2) Cache</span><span class="spec-value purple font-mono">${cpuD.L2CacheSize ? (cpuD.L2CacheSize / 1024).toFixed(0) + ' MB (' + cpuD.L2CacheSize + ' KB)' : '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Level 3 (L3) Smart Cache</span><span class="spec-value purple font-mono">${cpuD.L3CacheSize ? (cpuD.L3CacheSize / 1024).toFixed(0) + ' MB (' + cpuD.L3CacheSize + ' KB)' : '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Instruction Set Extensions</span><span class="spec-value">x86-64, AVX2, SSE4.2</span></div>
    `;
  }

  // 4. Physical Memory (RAM) Table
  const ramTable = document.getElementById('hw-ram-table');
  const sticks = data.ram_sticks || [];
  if (ramTable) {
    const sticksHtml = sticks.length > 0 ? sticks.map((s, idx) => `
      <div class="hardware-spec-row"><span class="spec-name">Slot ${idx + 1} (${s.DeviceLocator || 'DIMM' + idx})</span><span class="spec-value cyan font-mono">${s.Manufacturer || 'OEM'} ${(s.Capacity ? (s.Capacity / (1024**3)).toFixed(0) : '--')}GB @ ${s.ConfiguredClockSpeed || s.Speed || '--'} MT/s</span></div>
      ${s.PartNumber ? `<div class="hardware-spec-row"><span class="spec-name">&nbsp;&nbsp;↳ Part Number</span><span class="spec-value text-dim font-mono">${s.PartNumber.trim()}</span></div>` : ''}
    `).join('') : `
      <div class="hardware-spec-row"><span class="spec-name">Installed RAM</span><span class="spec-value cyan font-mono">${(data.memory?.total_gb || 0).toFixed(1)} GB Available</span></div>
    `;

    ramTable.innerHTML = `
      <div class="hardware-spec-row"><span class="spec-name">Total Physical Memory</span><span class="spec-value cyan font-mono">${(data.memory?.total_gb || 0).toFixed(1)} GB Installed</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Memory Status</span><span class="spec-value green">System Memory Active</span></div>
      ${sticksHtml}
    `;
  }

  // 5. GPU & Displays Table
  const gpuTable = document.getElementById('hw-gpu-table');
  const gpuList = (data.gpus && data.gpus.length > 0) ? data.gpus : (data.displays || []);
  if (gpuTable) {
    const gpuHtml = gpuList.map((g, idx) => `
      <div class="hardware-spec-row"><span class="spec-name">GPU ${idx + 1} (${g.Name || g.adapter || 'Display Adapter'})</span><span class="spec-value purple">${g.DriverVersion ? 'Driver: ' + g.DriverVersion : 'Active'}</span></div>
      ${g.AdapterRAM ? `<div class="hardware-spec-row"><span class="spec-name">&nbsp;&nbsp;↳ VRAM</span><span class="spec-value cyan font-mono">${(g.AdapterRAM / (1024**3)).toFixed(1)} GB</span></div>` : ''}
      ${g.VideoModeDescription ? `<div class="hardware-spec-row"><span class="spec-name">&nbsp;&nbsp;↳ Mode</span><span class="spec-value font-mono">${g.VideoModeDescription}</span></div>` : ''}
    `).join('');

    gpuTable.innerHTML = gpuHtml || `
      <div class="hardware-spec-row"><span class="spec-name">Primary Graphics</span><span class="spec-value purple">${data.displays?.[0]?.adapter || 'Generic Display Adapter'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Display Resolution</span><span class="spec-value font-mono">${data.displays?.[0]?.width || 1920} x ${data.displays?.[0]?.height || 1080} @ ${data.displays?.[0]?.refresh_rate || 60} Hz</span></div>
    `;
  }

  // 6. Audio Devices Table
  const audioTable = document.getElementById('hw-audio-table');
  const audioList = data.audio || [];
  if (audioTable) {
    audioTable.innerHTML = audioList.slice(0, 6).map(a => `
      <div class="hardware-spec-row">
        <span class="spec-name">${a.Name}</span>
        <span class="spec-value green">${a.Status || 'OK'}</span>
      </div>
    `).join('') || '<div class="text-dim text-sm">Realtek / Intel / AMD High Definition Audio</div>';
  }

  // 7. Battery & Power Table
  const batTable = document.getElementById('hw-bat-table');
  if (batTable && data.battery) {
    const b = data.battery;
    const health = (b.design_capacity_mwh && b.remaining_mwh)
      ? ((b.remaining_mwh / b.design_capacity_mwh) * 100).toFixed(1)
      : '--';
    batTable.innerHTML = `
      <div class="hardware-spec-row"><span class="spec-name">ACPI Device Identifier</span><span class="spec-value font-mono">${b.device_name || 'Generic ACPI Battery'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Factory Design Capacity</span><span class="spec-value font-mono">${b.design_capacity_mwh ? (b.design_capacity_mwh / 1000).toFixed(1) + ' Wh' : '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Current Energy Remaining</span><span class="spec-value purple font-mono">${b.remaining_mwh ? (b.remaining_mwh / 1000).toFixed(1) + ' Wh' : '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Battery Health Condition</span><span class="spec-value green">${health}%</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Operational Bus Voltage</span><span class="spec-value cyan font-mono">${b.voltage_mv ? (b.voltage_mv / 1000).toFixed(2) + ' V' : '--'}</span></div>
    `;
  }

  // 8. Accelerators & Storage Table
  const accelTable = document.getElementById('hw-accel-table');
  if (accelTable) {
    const npuName = data.npu?.detected ? data.npu.name : 'Not Present / Standby';
    const npuStatus = data.npu?.detected ? (data.npu?.status || 'Ready') : 'Idle';
    const storRows = (data.storage && data.storage.length > 0)
      ? data.storage.map((d, idx) => `
          <div class="hardware-spec-row"><span class="spec-name">Drive ${idx} (${d.bus_type || 'Disk'})</span><span class="spec-value font-mono">${d.model || 'Storage Device'} (${d.size_gb ? d.size_gb.toFixed(0) + ' GB' : ''})</span></div>
        `).join('')
      : '<div class="hardware-spec-row"><span class="spec-name">Storage</span><span class="spec-value font-mono">System Drive</span></div>';

    accelTable.innerHTML = `
      <div class="hardware-spec-row"><span class="spec-name">Neural Processing Unit (NPU)</span><span class="spec-value green">${npuName}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">NPU Acceleration Status</span><span class="spec-value cyan">${npuStatus}</span></div>
      ${storRows}
      <div class="hardware-spec-row"><span class="spec-name">Host Controller Protocol</span><span class="spec-value purple">Storage / Storport</span></div>
    `;
  }

  // Raw JSON dump
  const jsonViewer = document.getElementById('raw-json-viewer');
  if (jsonViewer) jsonViewer.textContent = JSON.stringify(data, null, 2);
}

// --- LIVE METRICS STREAM (REAL-TIME SSE + POLLING FALLBACK) ---
function startLiveMetrics() {
  fetchLiveMetrics();

  if (window.EventSource) {
    try {
      const sse = new EventSource('/api/live/stream');
      sse.onmessage = (event) => {
        try {
          const stats = JSON.parse(event.data);
          lastLiveMetrics = stats;
          renderLiveStats(stats);
        } catch (e) {}
      };
      sse.onerror = () => {
        sse.close();
        if (!liveInterval) {
          liveInterval = setInterval(fetchLiveMetrics, 1000);
        }
      };
      return;
    } catch (e) {
      console.warn('SSE fallback triggered:', e);
    }
  }

  liveInterval = setInterval(fetchLiveMetrics, 1000);
}

async function fetchLiveMetrics() {
  try {
    const res = await fetch('/api/live');
    if (!res.ok) return;
    const stats = await res.json();
    lastLiveMetrics = stats;
    renderLiveStats(stats);
  } catch (e) {
    // Silent fail if backend paused
  }
}

function renderLiveStats(stats) {
  // 1. CPU GAUGE
  const cpuPercent = Math.round(stats.cpu_percent || 0);
  document.getElementById('cpu-percent').textContent = `${cpuPercent}%`;
  setGaugeProgress('.cpu-meter', cpuPercent);

  // Per-core mini bars
  const coresGrid = document.getElementById('cores-grid');
  if (coresGrid && stats.cores && stats.cores.length > 0) {
    if (coresGrid.children.length !== stats.cores.length) {
      coresGrid.innerHTML = stats.cores.map(() => `
        <div class="core-bar"><div class="core-fill" style="height: 0%"></div></div>
      `).join('');
    }
    const fills = coresGrid.querySelectorAll('.core-fill');
    stats.cores.forEach((val, idx) => {
      if (fills[idx]) fills[idx].style.height = `${Math.min(100, Math.max(5, val))}%`;
    });
  }

  // 1.5 GPU GAUGE
  if (stats.gpu && stats.gpu.available) {
    const gpuPercent = Math.round(stats.gpu.usage_percent || 0);
    const gpuEl = document.getElementById('gpu-percent');
    if (gpuEl) gpuEl.textContent = `${gpuPercent}%`;
    setGaugeProgress('.gpu-meter', gpuPercent);

    const gpuTempBadge = document.getElementById('gpu-temp-badge');
    const gpuTempText = document.getElementById('gpu-temp-text');
    if (gpuTempBadge) gpuTempBadge.textContent = `${stats.gpu.temp_c} °C`;
    if (gpuTempText) gpuTempText.textContent = `${stats.gpu.temp_c} °C`;

    const gpuPower = document.getElementById('gpu-power-val');
    if (gpuPower) gpuPower.textContent = `${stats.gpu.power_w.toFixed(1)} W`;

    const gpuVram = document.getElementById('gpu-vram-text');
    if (gpuVram && stats.gpu.vram_total_mb) {
      gpuVram.textContent = `${(stats.gpu.vram_used_mb / 1024).toFixed(1)} / ${(stats.gpu.vram_total_mb / 1024).toFixed(0)} GB`;
    }
  }

  const fanCpu = document.getElementById('fan-cpu-temp');
  if (fanCpu) fanCpu.textContent = `${(stats.cpu_percent || 0).toFixed(1)}% Load`;
  const fanGpu = document.getElementById('fan-gpu-temp');
  if (fanGpu) fanGpu.textContent = (stats.gpu && stats.gpu.available) ? `${stats.gpu.temp_c} °C` : '-- °C';

  // 2. RAM GAUGE
  const ramPercent = Math.round(stats.ram_percent || 0);
  document.getElementById('ram-percent').textContent = `${ramPercent}%`;
  setGaugeProgress('.ram-meter', ramPercent);
  if (stats.ram_used_gb && stats.ram_total_gb) {
    document.getElementById('ram-used-text').textContent = `${stats.ram_used_gb.toFixed(1)} / ${stats.ram_total_gb.toFixed(0)} GB`;
    document.getElementById('ram-used-gb').textContent = `${stats.ram_used_gb.toFixed(1)} GB`;
    document.getElementById('ram-free-gb').textContent = `${(stats.ram_total_gb - stats.ram_used_gb).toFixed(1)} GB`;
  }

  // 3. BATTERY GAUGE
  if (stats.battery) {
    const batPercent = stats.battery.percent != null ? Math.round(stats.battery.percent) : 100;
    document.getElementById('bat-charge-percent').textContent = `${batPercent}%`;
    setGaugeProgress('.bat-meter', batPercent);
    if (stats.battery.voltage_v) {
      document.getElementById('bat-voltage-text').textContent = `${stats.battery.voltage_v.toFixed(2)} V`;
    }
    const statusBadge = document.getElementById('bat-status-badge');
    if (stats.battery.is_discharging) {
      statusBadge.textContent = `Discharging: ${(stats.battery.rate_w || 0).toFixed(1)} W`;
      statusBadge.className = 'tag-pill purple';
    } else {
      statusBadge.textContent = 'Plugged In';
      statusBadge.className = 'tag-pill green';
    }
  }

  // 4. NETWORK SPEEDS
  if (stats.network) {
    document.getElementById('net-down-speed').textContent = formatSpeed(stats.network.down_bytes_per_sec);
    document.getElementById('net-up-speed').textContent = formatSpeed(stats.network.up_bytes_per_sec);
    document.getElementById('net-total-transfer').textContent = `${(stats.network.total_bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
  }

  // 5. UPDATE 60-SEC PERFORMANCE CANVAS
  perfHistory.cpu.push(cpuPercent);
  if (perfHistory.cpu.length > 60) perfHistory.cpu.shift();

  const gpuVal = (stats.gpu && stats.gpu.available) ? stats.gpu.temp_c : 0;
  perfHistory.gpu.push(gpuVal);
  if (perfHistory.gpu.length > 60) perfHistory.gpu.shift();

  drawPerformanceCanvas();
}

function setGaugeProgress(selector, percent) {
  const el = document.querySelector(selector);
  if (!el) return;
  const offset = CIRCLE_CIRCUMFERENCE - (percent / 100) * CIRCLE_CIRCUMFERENCE;
  el.style.strokeDashoffset = offset;
}

function formatSpeed(bytesPerSec) {
  if (!bytesPerSec || bytesPerSec < 1024) return '0.0 KB/s';
  const kb = bytesPerSec / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB/s`;
  return `${(kb / 1024).toFixed(1)} MB/s`;
}

// --- PROCESS MANAGER ---
let processData = { total_processes: 0, total_threads: 0, processes: [] };
let procSortCol = 'ram_mb';
let procSortAsc = false;

function setupProcessManager() {
  const searchInput = document.getElementById('proc-search-input');
  const refreshBtn = document.getElementById('refresh-procs-btn');

  if (searchInput) {
    searchInput.addEventListener('input', () => filterAndRenderProcesses(searchInput.value));
  }
  if (refreshBtn) {
    refreshBtn.addEventListener('click', loadProcesses);
  }

  // Column header sorting
  document.querySelectorAll('.sortable-th').forEach(th => {
    th.addEventListener('click', () => {
      const col = th.getAttribute('data-col');
      if (!col) return;
      if (procSortCol === col) {
        procSortAsc = !procSortAsc;
      } else {
        procSortCol = col;
        procSortAsc = (col === 'name' || col === 'user');
      }
      document.querySelectorAll('.sortable-th').forEach(t => {
        t.classList.remove('active');
        const icon = t.querySelector('.sort-icon');
        if (icon) icon.textContent = '';
      });
      th.classList.add('active');
      const curIcon = th.querySelector('.sort-icon');
      if (curIcon) curIcon.textContent = procSortAsc ? '↑' : '↓';

      const searchVal = searchInput ? searchInput.value : '';
      filterAndRenderProcesses(searchVal);
    });
  });
}

async function loadProcesses() {
  try {
    const res = await fetch('/api/processes');
    if (!res.ok) return;
    const data = await res.json();
    processData = data;
    const searchVal = document.getElementById('proc-search-input')?.value || '';
    filterAndRenderProcesses(searchVal);
  } catch (e) {
    console.error('Failed to load processes', e);
  }
}

function filterAndRenderProcesses(query) {
  const tbody = document.getElementById('processes-tbody');
  const countLabel = document.getElementById('active-proc-count');
  const threadLabel = document.getElementById('active-thread-count');
  if (!tbody) return;

  const q = query.toLowerCase().trim();
  const rawList = processData.processes || [];

  if (countLabel) countLabel.textContent = `Active Processes: ${processData.total_processes || rawList.length}`;
  if (threadLabel) threadLabel.textContent = `${(processData.total_threads || 0).toLocaleString()} Threads`;

  let filtered = rawList.filter(p => 
    !q || 
    p.name.toLowerCase().includes(q) || 
    p.pid.toString().includes(q) ||
    (p.user && p.user.toLowerCase().includes(q)) ||
    (p.exe && p.exe.toLowerCase().includes(q))
  );

  filtered.sort((a, b) => {
    let va = a[procSortCol];
    let vb = b[procSortCol];
    if (typeof va === 'string') va = va.toLowerCase();
    if (typeof vb === 'string') vb = vb.toLowerCase();
    if (va < vb) return procSortAsc ? -1 : 1;
    if (va > vb) return procSortAsc ? 1 : -1;
    return 0;
  });

  tbody.innerHTML = filtered.slice(0, 80).map(p => `
    <tr>
      <td><span class="font-mono text-dim">${p.pid}</span></td>
      <td>
        <strong style="color: var(--text-main);">${p.name}</strong>
        ${p.exe ? `<br><span class="text-dim text-sm" style="font-size: 0.65rem;" title="${p.exe}">${p.exe.length > 55 ? '...' + p.exe.slice(-50) : p.exe}</span>` : ''}
      </td>
      <td><span class="user-badge ${p.user === 'ahmet' ? 'user-active' : ''}">${p.user || 'SYSTEM'}</span></td>
      <td><span class="font-mono ${p.cpu_percent > 10 ? 'orange' : ''}">${(p.cpu_percent || 0).toFixed(1)}%</span></td>
      <td><span class="font-mono cyan">${(p.ram_mb || 0).toFixed(1)} MB</span> <span class="text-dim" style="font-size: 0.68rem;">(${p.ram_pct || 0}%)</span></td>
      <td><span class="font-mono">${(p.disk_mb || 0) > 0 ? p.disk_mb.toFixed(1) + ' MB' : '0 MB'}</span></td>
      <td><span class="font-mono">${p.threads || 1}</span></td>
      <td><span class="tag-pill ${p.status === 'running' ? 'green' : ''}" style="font-size: 0.65rem; padding: 2px 6px;">${p.status || 'running'}</span></td>
      <td style="text-align: right; white-space: nowrap;">
        <button class="proc-action-btn" title="Open file location in Explorer" onclick="openProcessLocation(${p.pid})">📂</button>
        <button class="proc-action-btn kill" title="Terminate process" onclick="killProcess(${p.pid}, '${p.name}')">End Task</button>
      </td>
    </tr>
  `).join('');
}

window.openProcessLocation = async function(pid) {
  try {
    await fetch(`/api/processes/open_location?pid=${pid}`);
  } catch (e) {
    console.error('Failed to open location:', e);
  }
};

window.killProcess = async function(pid, name) {
  if (!confirm(`Are you sure you want to terminate ${name} (PID: ${pid})?`)) return;
  try {
    const res = await fetch('/api/kill', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pid })
    });
    if (res.ok) {
      loadProcesses();
    } else {
      alert('Failed to terminate process (Administrator privileges may be required).');
    }
  } catch (e) {
    alert('Error: ' + e.message);
  }
};

// --- INSTANT FILE SEARCH ---
let searchDebounce = null;
function setupInstantSearch() {
  const input = document.getElementById('file-search-input');
  const resultsBox = document.getElementById('search-results-box');

  if (input) {
    input.addEventListener('input', () => {
      clearTimeout(searchDebounce);
      const query = input.value.trim();
      if (!query) {
        resultsBox.innerHTML = '<div class="empty-state"><span>Type a file name or extension to search.</span></div>';
        return;
      }
      searchDebounce = setTimeout(async () => {
        try {
          const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
          if (!res.ok) return;
          const files = await res.json();
          if (files.length === 0) {
            resultsBox.innerHTML = '<div class="empty-state"><span>No matching files found.</span></div>';
            return;
          }
          resultsBox.innerHTML = files.map(f => `
            <div class="search-result-item" onclick="openFileLocation('${encodeURIComponent(f.path)}')">
              <div>
                <strong>${f.name}</strong>
                <p class="subtitle" style="font-size: 0.75rem;">${f.path}</p>
              </div>
              <span class="tag-pill">${(f.size_bytes / (1024 * 1024)).toFixed(1)} MB</span>
            </div>
          `).join('');
        } catch (e) {
          console.error(e);
        }
      }, 200);
    });
  }
}

window.openFileLocation = async function(encodedPath) {
  await fetch(`/api/open?path=${encodedPath}`);
};

// --- TWEAKS ---
async function setupTweaks() {
  // Sync checkboxes with real Windows registry state
  try {
    const res = await fetch('/api/tweaks');
    if (res.ok) {
      const state = await res.json();
      const elTelemetry = document.getElementById('twk-telemetry');
      const elBing = document.getElementById('twk-bing');
      const elCopilot = document.getElementById('twk-copilot');
      const elGameMode = document.getElementById('twk-game-mode');
      if (elTelemetry && state.telemetry !== undefined) elTelemetry.checked = state.telemetry;
      if (elBing && state.bing !== undefined) elBing.checked = state.bing;
      if (elCopilot && state.copilot !== undefined) elCopilot.checked = state.copilot;
      if (elGameMode && state.game_mode !== undefined) elGameMode.checked = state.game_mode;
    }
  } catch (e) {
    console.warn('Failed to load initial tweaks registry state:', e);
  }

  const applyBtn = document.getElementById('btn-apply-all-tweaks');
  if (applyBtn) {
    applyBtn.addEventListener('click', async () => {
      applyBtn.disabled = true;
      applyBtn.textContent = 'Applying optimizations...';
      try {
        const payload = {
          telemetry: document.getElementById('twk-telemetry').checked,
          bing: document.getElementById('twk-bing').checked,
          copilot: document.getElementById('twk-copilot').checked,
          game_mode: document.getElementById('twk-game-mode').checked,
        };
        const res = await fetch('/api/tweak', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        if (res.ok) {
          alert('Selected optimizations successfully applied to Windows Registry!');
        }
      } catch (e) {
        alert('Error: ' + e.message);
      } finally {
        applyBtn.disabled = false;
        applyBtn.textContent = 'Apply Selected Optimizations';
      }
    });
  }
}

// --- DIAGNOSTICS LAB ---
function setupDiagnostics() {
  // 1. REAL SPEED TEST (Zero-Cloud, Socket & CDN Powered)
  const speedBtn = document.getElementById('start-speedtest-btn');
  if (speedBtn) {
    speedBtn.addEventListener('click', async () => {
      speedBtn.disabled = true;
      speedBtn.textContent = 'Testing...';
      const pingEl = document.getElementById('ping-readout');
      const downEl = document.getElementById('down-readout');
      const upEl = document.getElementById('up-readout');

      pingEl.textContent = '...';
      downEl.textContent = '...';
      upEl.textContent = '...';

      try {
        const res = await fetch('/api/speedtest');
        if (res.ok) {
          const data = await res.json();
          pingEl.textContent = data.ping_ms || '0';
          downEl.textContent = (data.download_mbps || 0).toFixed(1);
          upEl.textContent = (data.upload_mbps || 0).toFixed(1);
        } else {
          pingEl.textContent = '--';
          downEl.textContent = 'Hata';
          upEl.textContent = 'Hata';
        }
      } catch (e) {
        console.error('Speedtest error:', e);
        pingEl.textContent = '--';
        downEl.textContent = '0.0';
        upEl.textContent = '0.0';
      } finally {
        speedBtn.disabled = false;
        speedBtn.textContent = 'Yeniden Test Et';
      }
    });
  }

  // 2. DEAD PIXEL TEST
  const overlay = document.getElementById('fullscreen-pixel-overlay');
  const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffffff', '#000000'];
  let colorIdx = 0;

  document.querySelectorAll('.pixel-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const col = btn.getAttribute('data-color');
      showPixelOverlay(col);
    });
  });

  const wizardBtn = document.getElementById('start-pixel-wizard');
  if (wizardBtn) {
    wizardBtn.addEventListener('click', () => {
      colorIdx = 0;
      showPixelOverlay(colors[colorIdx]);
    });
  }

  if (overlay) {
    overlay.addEventListener('click', () => {
      colorIdx = (colorIdx + 1) % colors.length;
      overlay.style.backgroundColor = colors[colorIdx];
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && overlay && !overlay.classList.contains('hidden')) {
      overlay.classList.add('hidden');
    }
  });

  function showPixelOverlay(col) {
    if (!overlay) return;
    overlay.style.backgroundColor = col;
    overlay.classList.remove('hidden');
  }

  // 3. KEYBOARD TESTER
  document.addEventListener('keydown', (e) => {
    const pane = document.getElementById('tab-diagnostics');
    if (!pane || !pane.classList.contains('active')) return;

    activeKeys.add(e.code);
    const keyLabel = document.getElementById('last-key-pressed');
    const simCount = document.getElementById('simultaneous-key-count');

    if (keyLabel) keyLabel.textContent = `${e.key} (${e.code})`;
    if (simCount) simCount.textContent = activeKeys.size;
  });

  document.addEventListener('keyup', (e) => {
    activeKeys.delete(e.code);
    const simCount = document.getElementById('simultaneous-key-count');
    if (simCount) simCount.textContent = activeKeys.size;
  });

  // 4. MOUSE TESTER
  const mouseArea = document.getElementById('mouse-click-area');
  if (mouseArea) {
    mouseArea.addEventListener('click', () => {
      const now = performance.now();
      const diff = now - lastClickTime;
      lastClickTime = now;
      clickCount++;

      document.getElementById('click-counter').textContent = clickCount;

      const warn = document.getElementById('double-click-warning');
      if (diff > 0 && diff < 80) {
        warn.textContent = `Chatter Detected (${Math.round(diff)} ms)!`;
        warn.className = 'accent-red';
      } else {
        warn.textContent = 'Healthy (Normal)';
        warn.className = 'green';
      }
    });
  }
}

// --- COMPACT MINI MODE ---
function setupCompactMode() {
  const btn = document.getElementById('btn-toggle-compact');
  if (btn) {
    btn.addEventListener('click', () => {
      document.body.classList.toggle('compact-mode');
      const isCompact = document.body.classList.contains('compact-mode');
      btn.textContent = isCompact ? '⛶ Normal View' : '⛶ Mini Mode';
    });
  }
}

// --- THEME ENGINE ---
function setupThemeEngine() {
  const themes = [
    { id: 'default', label: 'Midnight', cls: '' },
    { id: 'amoled', label: 'AMOLED Pure', cls: 'theme-amoled' },
    { id: 'cyber', label: 'Cyber Neon', cls: 'theme-cyber' }
  ];

  let currentIdx = 0;
  try {
    const saved = localStorage.getItem('zenith-theme');
    if (saved) {
      const found = themes.findIndex(t => t.id === saved);
      if (found !== -1) currentIdx = found;
    }
  } catch (e) {}

  const applyTheme = (idx) => {
    const t = themes[idx];
    document.body.classList.remove('theme-amoled', 'theme-cyber');
    if (t.cls) document.body.classList.add(t.cls);
    const labelEl = document.getElementById('theme-label');
    if (labelEl) labelEl.textContent = t.label;
    try {
      localStorage.setItem('zenith-theme', t.id);
    } catch (e) {}
  };

  applyTheme(currentIdx);

  const toggleBtn = document.getElementById('btn-theme-toggle');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      currentIdx = (currentIdx + 1) % themes.length;
      applyTheme(currentIdx);
    });
  }
}

// --- AUTO-UPDATE CHECKER ---
function setupUpdateChecker() {
  const badge = document.getElementById('app-version-badge');
  if (!badge) return;

  const applyBadge = (data) => {
    if (data && data.update_available) {
      badge.textContent = `⚡ UPDATE (${data.latest_version})`;
      badge.style.background = 'rgba(16, 185, 129, 0.2)';
      badge.style.color = 'var(--accent-green)';
      badge.style.border = '1px solid var(--accent-green)';
      badge.style.animation = 'pulse-border 1.5s infinite';
      badge.title = `New version available (${data.latest_version})! Click to download.`;
      badge.onclick = () => {
        if (data.release_url) window.open(data.release_url, '_blank');
      };
    } else {
      badge.textContent = 'SYSTEM V1.0';
    }
  };

  const runCheck = async (isManual = false) => {
    const CACHE_KEY = 'zenith-update-cache';
    const CACHE_TTL_MS = 6 * 3600 * 1000; // 6 hours

    if (!isManual) {
      try {
        const cachedStr = localStorage.getItem(CACHE_KEY);
        if (cachedStr) {
          const { ts, data } = JSON.parse(cachedStr);
          if (Date.now() - ts < CACHE_TTL_MS) {
            applyBadge(data);
            return;
          }
        }
      } catch (e) {}
    }

    try {
      if (isManual) badge.textContent = 'Denetleniyor...';
      const res = await fetch('/api/updates/check');
      if (!res.ok) return;
      const data = await res.json();
      try {
        localStorage.setItem(CACHE_KEY, JSON.stringify({ ts: Date.now(), data }));
      } catch (e) {}
      applyBadge(data);
      if (isManual && !data.update_available) {
        alert('Zenith System is up to date! You are using the latest version.');
      }
    } catch (e) {
      if (isManual) {
        badge.textContent = 'SYSTEM V1.0';
        alert('Update check failed: ' + e.message);
      }
    }
  };

  badge.addEventListener('click', () => runCheck(true));
  setTimeout(() => runCheck(false), 2500);
}

// --- WINGET APP STORE & CATALOG MANAGER ---
let wingetCatalogData = null;
let wingetProfilesData = null;
let wingetCurrentCategory = 'all';
let wingetSearchTimeout = null;
let isWingetPollActive = false;

async function setupWinGetStore() {
  const installBtn = document.getElementById('btn-install-winget-pkgs');
  const searchInput = document.getElementById('winget-search-input');
  const clearSearchBtn = document.getElementById('btn-clear-winget-search');
  const upgradesBtn = document.getElementById('btn-winget-check-upgrades');
  const toggleTermBtn = document.getElementById('btn-toggle-winget-terminal');
  const logBox = document.getElementById('winget-log-box');

  // Load profiles and catalog concurrently
  loadWingetProfiles();
  loadWingetCatalog();

  // Search input handler with debounce
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      const q = searchInput.value.trim();
      if (clearSearchBtn) clearSearchBtn.style.display = q ? 'block' : 'none';
      clearTimeout(wingetSearchTimeout);
      if (!q) {
        renderWingetCatalogView();
        return;
      }
      if (q.length < 2) return;

      const view = document.getElementById('winget-content-view');
      if (view) view.innerHTML = `<div style="padding: 40px; text-align: center; color: var(--accent-cyan);">🔍 Searching "${q}" in Microsoft WinGet repo...</div>`;

      wingetSearchTimeout = setTimeout(() => {
        executeLiveWingetSearch(q);
      }, 400);
    });
  }

  if (clearSearchBtn && searchInput) {
    clearSearchBtn.addEventListener('click', () => {
      searchInput.value = '';
      clearSearchBtn.style.display = 'none';
      renderWingetCatalogView();
    });
  }

  // Category filter pills
  const pills = document.querySelectorAll('.winget-pill');
  pills.forEach(pill => {
    pill.addEventListener('click', () => {
      pills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      wingetCurrentCategory = pill.getAttribute('data-cat') || 'all';
      if (searchInput) {
        searchInput.value = '';
        if (clearSearchBtn) clearSearchBtn.style.display = 'none';
      }
      renderWingetCatalogView();
    });
  });

  // Upgrades checker
  if (upgradesBtn) {
    upgradesBtn.addEventListener('click', async () => {
      upgradesBtn.disabled = true;
      upgradesBtn.innerHTML = '<span>⏳ Scanning...</span>';
      const view = document.getElementById('winget-content-view');
      if (view) view.innerHTML = '<div style="padding: 40px; text-align: center; color: var(--accent-green);">🔄 Scanning for updates across installed applications...</div>';
      try {
        const res = await fetch('/api/winget/upgrades');
        const upgrades = res.ok ? await res.json() : [];
        renderWingetUpgradesView(upgrades);
      } catch (e) {
        if (view) view.innerHTML = `<div style="padding: 30px; text-align: center; color: var(--accent-pink);">Update scan failed: ${e.message}</div>`;
      } finally {
        upgradesBtn.disabled = false;
        upgradesBtn.innerHTML = '<span>🔄 Check for Updates</span>';
      }
    });
  }

  // Toggle terminal
  if (toggleTermBtn && logBox) {
    toggleTermBtn.addEventListener('click', () => {
      logBox.style.display = logBox.style.display === 'none' ? 'block' : 'none';
    });
  }

  // Bulk Install Selected
  if (installBtn) {
    installBtn.addEventListener('click', async () => {
      const checked = Array.from(document.querySelectorAll('.pkg-cb:checked')).map(cb => cb.value);
      if (checked.length === 0) {
        alert('Please select at least one package to install.');
        return;
      }

      installBtn.disabled = true;
      installBtn.textContent = 'Installing...';
      startWingetPolling();

      try {
        const res = await fetch('/api/winget/install', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ packages: checked })
        });
        if (!res.ok) throw new Error('API request failed.');
      } catch (e) {
        alert('Hata: ' + e.message);
        installBtn.disabled = false;
        updateSelectedPackagesCount();
      }
    });
  }
}

async function loadWingetProfiles() {
  const container = document.getElementById('winget-profiles-container');
  if (!container) return;
  try {
    const res = await fetch('/api/catalog/profiles');
    if (!res.ok) return;
    wingetProfilesData = await res.json();
    const profiles = wingetProfilesData.profiles || [];
    container.innerHTML = profiles.map(p => `
      <div class="profile-card">
        <div>
          <div class="profile-card-header">
            <span class="profile-card-icon">${p.name.split(' ')[0] || '⚡'}</span>
            <h4 class="profile-card-title">${p.name.substring(p.name.indexOf(' ') + 1) || p.name}</h4>
          </div>
          <p class="profile-card-desc">${p.description}</p>
          <div class="profile-pkg-count">${p.packages.length} Packages Ready</div>
        </div>
        <button class="profile-deploy-btn" onclick="deployWingetProfile('${p.id}', '${p.name.replace(/'/g, "\\'")}')">
          <span>⚡ Profili Kur</span>
        </button>
      </div>
    `).join('');
  } catch (e) {
    console.error('Failed to load profiles:', e);
  }
}

async function loadWingetCatalog() {
  const view = document.getElementById('winget-content-view');
  try {
    const res = await fetch('/api/catalog');
    if (!res.ok) return;
    wingetCatalogData = await res.json();
    renderWingetCatalogView();
  } catch (e) {
    if (view) view.innerHTML = `<div style="padding: 30px; text-align: center; color: var(--accent-pink);">Failed to load catalog: ${e.message}</div>`;
  }
}

function renderWingetCatalogView() {
  const view = document.getElementById('winget-content-view');
  if (!view || !wingetCatalogData) return;

  const categories = wingetCatalogData.categories || [];
  const filtered = wingetCurrentCategory === 'all'
    ? categories
    : categories.filter(c => c.id === wingetCurrentCategory);

  if (filtered.length === 0) {
    view.innerHTML = '<div style="padding: 40px; text-align: center; color: var(--text-dim);">No packages found in this category.</div>';
    return;
  }

  view.innerHTML = `
    <div class="winget-cat-grid">
      ${filtered.map(cat => `
        <div class="winget-cat-card">
          <div class="winget-cat-header">
            <div class="winget-cat-title">
              <span>${cat.icon || '📦'}</span>
              <span>${cat.name}</span>
            </div>
            <span style="font-size: 0.72rem; color: var(--text-dim);">${cat.packages.length} Paket</span>
          </div>
          <div class="package-list">
            ${cat.packages.map(pkg => `
              <div class="pkg-item">
                <div class="pkg-item-left">
                  <input type="checkbox" class="pkg-cb" value="${pkg.id}" onchange="updateSelectedPackagesCount()" style="accent-color: var(--accent-cyan); cursor: pointer; width: 16px; height: 16px;">
                  <div>
                    <div class="pkg-item-name">${pkg.name}</div>
                    <div class="pkg-item-id">${pkg.id}</div>
                  </div>
                </div>
                <div style="display: flex; align-items: center; gap: 8px;">
                  ${(pkg.tags || []).slice(0, 1).map(t => `<span class="pkg-tag-badge">${t}</span>`).join('')}
                  <button class="pkg-install-quick-btn" onclick="installSingleWingetPackage('${pkg.id}')">Kur</button>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      `).join('')}
    </div>
  `;

  updateSelectedPackagesCount();
}

async function executeLiveWingetSearch(query) {
  const view = document.getElementById('winget-content-view');
  if (!view) return;
  try {
    const res = await fetch(`/api/winget/search?q=${encodeURIComponent(query)}`);
    const results = res.ok ? await res.json() : [];

    if (results.length === 0) {
      view.innerHTML = `
        <div style="padding: 40px; text-align: center; color: var(--text-dim);">
          <div style="font-size: 1.8rem; margin-bottom: 8px;">🔍</div>
          <div>"${query}" returned no results in Microsoft WinGet repo.</div>
          <div style="font-size: 0.75rem; margin-top: 6px; color: var(--text-dim);">Try an alternate query (e.g. chrome, vlc, discord).</div>
        </div>
      `;
      return;
    }

    view.innerHTML = `
      <div style="margin-bottom: 14px; font-size: 0.82rem; color: var(--text-muted); display: flex; justify-content: space-between;">
        <span>Found <strong>${results.length}</strong> results for "${query}":</span>
        <span style="color: var(--accent-cyan);">Source: Microsoft WinGet Repository</span>
      </div>
      <div class="winget-cat-grid">
        <div class="winget-cat-card" style="grid-column: 1 / -1;">
          <div class="package-list">
            ${results.map(r => `
              <div class="pkg-item" style="padding: 10px 14px;">
                <div class="pkg-item-left">
                  <input type="checkbox" class="pkg-cb" value="${r.id}" onchange="updateSelectedPackagesCount()" style="accent-color: var(--accent-cyan); cursor: pointer; width: 16px; height: 16px;">
                  <div>
                    <div class="pkg-item-name" style="font-size: 0.9rem;">${r.name}</div>
                    <div class="pkg-item-id">${r.id} • Version: ${r.version || 'Latest'} ${r.source ? `• ${r.source}` : ''}</div>
                  </div>
                </div>
                <button class="pkg-install-quick-btn" style="padding: 6px 14px; font-weight: 600;" onclick="installSingleWingetPackage('${r.id}')">⚡ Install Now</button>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;

    updateSelectedPackagesCount();
  } catch (e) {
    view.innerHTML = `<div style="padding: 30px; text-align: center; color: var(--accent-pink);">Error during package search: ${e.message}</div>`;
  }
}

function renderWingetUpgradesView(upgrades) {
  const view = document.getElementById('winget-content-view');
  if (!view) return;

  if (!upgrades || upgrades.length === 0) {
    view.innerHTML = `
      <div style="padding: 50px; text-align: center; color: var(--accent-green);">
        <div style="font-size: 2.2rem; margin-bottom: 10px;">✨</div>
        <div style="font-size: 1rem; font-weight: 700;">All applications are up to date!</div>
        <div style="font-size: 0.8rem; color: var(--text-dim); margin-top: 4px;">No pending upgrades found for installed WinGet packages.</div>
      </div>
    `;
    return;
  }

  view.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
      <div>
        <h4 style="margin: 0; font-size: 1rem; color: #fff;">Upgradable Applications (${upgrades.length})</h4>
        <span style="font-size: 0.75rem; color: var(--text-dim);">Newer versions are available for the following packages</span>
      </div>
      <button class="btn btn-primary" onclick="upgradeAllWingetPackages(${JSON.stringify(upgrades.map(u => u.id)).replace(/"/g, '&quot;')})">
        ⚡ Upgrade All (${upgrades.length})
      </button>
    </div>
    <div style="display: flex; flex-direction: column; gap: 8px;">
      ${upgrades.map(u => `
        <div class="upgrade-row">
          <div>
            <div style="font-weight: 600; font-size: 0.88rem; color: #fff;">${u.name}</div>
            <div style="font-size: 0.72rem; color: var(--text-dim); font-family: 'JetBrains Mono', monospace;">${u.id}</div>
          </div>
          <div style="display: flex; align-items: center; gap: 14px;">
            <div style="font-size: 0.78rem; color: var(--text-muted);">
              <span>${u.version || 'Mevcut'}</span>
              <span style="color: var(--accent-cyan); margin: 0 6px;">➔</span>
              <span class="upgrade-version-badge">${u.available || 'Yeni'}</span>
            </div>
            <button class="pkg-install-quick-btn" onclick="installSingleWingetPackage('${u.id}')">Upgrade</button>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

window.updateSelectedPackagesCount = function() {
  const checked = document.querySelectorAll('.pkg-cb:checked');
  const countEl = document.getElementById('winget-selected-count');
  const installBtn = document.getElementById('btn-install-winget-pkgs');
  if (countEl) countEl.textContent = checked.length;
  if (installBtn && !isWingetPollActive) {
    installBtn.innerHTML = `<span>Install Selected (${checked.length})</span>`;
  }
};

window.installSingleWingetPackage = async function(pkgId) {
  if (!confirm(`Do you want to install '${pkgId}' silently in the background?`)) return;
  startWingetPolling();
  try {
    await fetch('/api/winget/install', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ packages: [pkgId] })
    });
  } catch (e) {
    alert('Installation failed to start: ' + e.message);
  }
};

window.deployWingetProfile = async function(profileId, profileName) {
  if (!confirm(`All packages in profile '${profileName}' will be silently installed. Proceed?`)) return;
  startWingetPolling();
  try {
    const res = await fetch('/api/winget/install-profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ profile_id: profileId })
    });
    if (!res.ok) throw new Error('Profile installation request failed.');
  } catch (e) {
    alert('Profile installation error: ' + e.message);
  }
};

window.upgradeAllWingetPackages = async function(pkgIds) {
  if (!confirm(`${pkgIds.length} package(s) will be upgraded to their latest versions. Proceed?`)) return;
  startWingetPolling();
  try {
    await fetch('/api/winget/install', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ packages: pkgIds })
    });
  } catch (e) {
    alert('Batch upgrade error: ' + e.message);
  }
};

function startWingetPolling() {
  const logBox = document.getElementById('winget-log-box');
  const spinner = document.getElementById('winget-spinner');
  const installBtn = document.getElementById('btn-install-winget-pkgs');

  if (logBox) {
    logBox.style.display = 'block';
    logBox.innerHTML = '<div class="terminal-line" style="color: #38bdf8;">[Zenith WinGet] Background installation initiated...</div>';
  }
  if (spinner) spinner.style.display = 'inline';
  if (installBtn) {
    installBtn.disabled = true;
    installBtn.textContent = 'Installing...';
  }

  isWingetPollActive = true;
  const pollInterval = setInterval(async () => {
    try {
      const res = await fetch('/api/winget/status');
      if (!res.ok) return;
      const statusData = await res.json();
      if (logBox && statusData.logs) {
        logBox.innerHTML = statusData.logs.map(l => `<div class="terminal-line">${l}</div>`).join('');
        logBox.scrollTop = logBox.scrollHeight;
      }
      if (statusData.status === 'done' || statusData.status === 'error') {
        clearInterval(pollInterval);
        isWingetPollActive = false;
        if (spinner) spinner.style.display = 'none';
        if (installBtn) {
          installBtn.disabled = false;
          updateSelectedPackagesCount();
        }
      }
    } catch (_) {
      clearInterval(pollInterval);
      isWingetPollActive = false;
      if (spinner) spinner.style.display = 'none';
      if (installBtn) {
        installBtn.disabled = false;
        updateSelectedPackagesCount();
      }
    }
  }, 1000);
}

// --- INSTALLED APPS MANAGER (100ms REGISTRY ENGINE) ---
let installedAppsList = [];
let sortBySizeAsc = false;

function setupInstalledApps() {
  const searchInput = document.getElementById('app-search-input');
  const sortBtn = document.getElementById('btn-sort-apps-size');

  if (searchInput) {
    searchInput.addEventListener('input', () => filterAndRenderApps(searchInput.value));
  }
  if (sortBtn) {
    sortBtn.addEventListener('click', () => {
      sortBySizeAsc = !sortBySizeAsc;
      installedAppsList.sort((a, b) => sortBySizeAsc ? b.size_mb - a.size_mb : a.name.localeCompare(b.name));
      sortBtn.textContent = sortBySizeAsc ? 'Sort by Name' : 'Sort by Size';
      filterAndRenderApps(searchInput ? searchInput.value : '');
    });
  }
}

async function loadInstalledApps() {
  const tbody = document.getElementById('installed-apps-tbody');
  const countLabel = document.getElementById('installed-apps-count');
  if (tbody && tbody.children.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: var(--text-dim);">Scanning Windows Registry...</td></tr>';
  }

  try {
    const res = await fetch('/api/apps');
    if (!res.ok) return;
    installedAppsList = await res.json();
    if (countLabel) countLabel.textContent = `Installed Programs: ${installedAppsList.length}`;
    filterAndRenderApps('');
  } catch (e) {
    console.error('Failed to load apps', e);
  }
}

function filterAndRenderApps(query) {
  const tbody = document.getElementById('installed-apps-tbody');
  const countLabel = document.getElementById('installed-apps-count');
  if (!tbody) return;

  const q = query.toLowerCase();
  const filtered = installedAppsList.filter(a => 
    a.name.toLowerCase().includes(q) || 
    (a.publisher && a.publisher.toLowerCase().includes(q))
  );

  if (countLabel) countLabel.textContent = `Installed Programs: ${filtered.length}`;

  tbody.innerHTML = filtered.slice(0, 100).map(a => `
    <tr>
      <td><strong>${a.name}</strong></td>
      <td><span class="tag-pill">${a.version || 'Unknown'}</span></td>
      <td style="color: var(--text-dim);">${a.publisher}</td>
      <td><strong>${a.size_mb > 0 ? (a.size_mb >= 1024 ? (a.size_mb / 1024).toFixed(1) + ' GB' : a.size_mb.toFixed(1) + ' MB') : '--'}</strong></td>
      <td style="text-align: right;">
        <button class="btn btn-secondary" style="padding: 4px 10px; font-size: 0.75rem;" onclick="uninstallApp('${encodeURIComponent(a.uninstall_string)}')">Uninstall</button>
      </td>
    </tr>
  `).join('');
}

window.uninstallApp = async function(encodedCmd) {
  const cmd = decodeURIComponent(encodedCmd);
  if (!cmd) {
    alert('Direct uninstall command not found for this application.');
    return;
  }
  if (!confirm('Do you want to launch the uninstaller for this program?')) return;
  await fetch('/api/uninstall', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ uninstall_string: cmd })
  });
};

// --- SYSTEM REPORT COPY ---
function setupReportCopy() {
  const copyBtn = document.getElementById('btn-copy-report');
  if (!copyBtn) return;

  copyBtn.addEventListener('click', () => {
    if (!hardwareData) return;
    const cpu = hardwareData.cpu?.model || hardwareData.cpu_deep?.Name || 'Host Processor';
    const totalC = hardwareData.cpu?.total_cores || hardwareData.cpu_deep?.NumberOfCores || '--';
    const pCores = hardwareData.cpu?.p_cores;
    const eCores = hardwareData.cpu?.e_cores;
    const coreStr = (pCores && eCores) ? `${totalC} Cores (${pCores}P + ${eCores}E)` : `${totalC} Cores`;
    const npu = hardwareData.npu?.detected ? hardwareData.npu.name : 'N/A';
    const gpu = hardwareData.displays?.[0]?.adapter || hardwareData.gpus?.[0]?.Name || 'Host GPU';
    const ram = hardwareData.memory?.total_gb ? `${hardwareData.memory.total_gb.toFixed(1)} GB` : 'System RAM';
    const bat = (hardwareData.battery && hardwareData.battery.design_capacity_mwh)
      ? `${((hardwareData.battery.remaining_mwh / hardwareData.battery.design_capacity_mwh) * 100).toFixed(1)}% Health`
      : 'AC Line Power';
    const osName = hardwareData.os?.Caption || 'Windows 64-bit';

    const report = `# Zenith System — Hardware Specification Report
- **Processor (CPU):** ${cpu} (${coreStr})
- **Neural Processor (NPU):** ${npu}
- **Graphics (GPU):** ${gpu}
- **Memory (RAM):** ${ram}
- **Battery:** ${bat}
- **Operating System:** ${osName}`;

    navigator.clipboard.writeText(report).then(() => {
      const orig = copyBtn.textContent;
      copyBtn.textContent = '✓ Copied!';
      copyBtn.style.color = 'var(--accent-green)';
      setTimeout(() => {
        copyBtn.textContent = orig;
        copyBtn.style.color = '';
      }, 2000);
    });
  });

  const exportHtmlBtn = document.getElementById('btn-export-html-report');
  if (exportHtmlBtn) {
    exportHtmlBtn.addEventListener('click', () => {
      window.open('/api/report/html', '_blank');
    });
  }
}

// --- CPU STRESS TEST ---
function setupCpuStressTest() {
  const stressBtn = document.getElementById('btn-start-cpu-stress');
  const timerEl = document.getElementById('stress-timer');
  const peakEl = document.getElementById('stress-peak-cpu');
  const resultEl = document.getElementById('stress-result-text');
  if (!stressBtn) return;

  stressBtn.addEventListener('click', async () => {
    stressBtn.disabled = true;
    stressBtn.textContent = 'Stressing Cores...';
    resultEl.textContent = 'Under Load';
    resultEl.className = 'readout-num';

    try {
      await fetch('/api/stress/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ duration: 15 })
      });

      const poll = setInterval(async () => {
        try {
          const res = await fetch('/api/stress/status');
          if (!res.ok) return;
          const data = await res.json();

          if (timerEl) timerEl.textContent = `${data.elapsed_seconds}s / 15s`;
          if (peakEl) peakEl.textContent = `${data.max_cpu_percent.toFixed(1)}%`;

          if (data.status === 'completed' || !data.active) {
            clearInterval(poll);
            stressBtn.disabled = false;
            stressBtn.textContent = 'Run Stress Test (15s)';
            if (resultEl) {
              resultEl.textContent = '✓ Stable / Passed';
              resultEl.className = 'readout-num green';
            }
          }
        } catch (e) {
          clearInterval(poll);
        }
      }, 500);
    } catch (e) {
      alert('Error: ' + e.message);
      stressBtn.disabled = false;
      stressBtn.textContent = 'Run Stress Test (15s)';
    }
  });
}

// --- REAL-TIME 60-SEC PERFORMANCE CANVAS ---
function drawPerformanceCanvas() {
  const canvas = document.getElementById('live-performance-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const w = canvas.width;
  const h = canvas.height;

  ctx.clearRect(0, 0, w, h);

  // Draw gridlines
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
  ctx.lineWidth = 1;
  for (let i = 1; i <= 3; i++) {
    const y = (h / 4) * i;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }

  const maxPoints = 60;
  const step = w / (maxPoints - 1);

  function drawSeries(data, color, fillColor, maxY = 100) {
    if (data.length < 2) return;
    const startIdx = maxPoints - data.length;

    ctx.beginPath();
    data.forEach((val, i) => {
      const x = (startIdx + i) * step;
      const y = h - (Math.min(val, maxY) / maxY) * (h - 24) - 12;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });

    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.shadowColor = color;
    ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.shadowBlur = 0;

    if (fillColor) {
      const lastX = (startIdx + data.length - 1) * step;
      const firstX = startIdx * step;
      ctx.lineTo(lastX, h);
      ctx.lineTo(firstX, h);
      ctx.closePath();
      ctx.fillStyle = fillColor;
      ctx.fill();
    }
  }

  // 1. Draw CPU Load Stream
  const cpuGrad = ctx.createLinearGradient(0, 0, 0, h);
  cpuGrad.addColorStop(0, 'rgba(6, 182, 212, 0.25)');
  cpuGrad.addColorStop(1, 'rgba(6, 182, 212, 0.0)');
  drawSeries(perfHistory.cpu, '#06b6d4', cpuGrad, 100);

  // 2. Draw GPU Temp Stream (Scale 100 °C)
  const gpuGrad = ctx.createLinearGradient(0, 0, 0, h);
  gpuGrad.addColorStop(0, 'rgba(139, 92, 246, 0.2)');
  gpuGrad.addColorStop(1, 'rgba(139, 92, 246, 0.0)');
  drawSeries(perfHistory.gpu, '#8b5cf6', gpuGrad, 100);
}

// --- STARTUP APPS MANAGER ---
let startupAppsList = [];
function setupStartupApps() {
  const searchInput = document.getElementById('startup-search-input');
  const refreshBtn = document.getElementById('btn-refresh-startup');
  if (searchInput) {
    searchInput.addEventListener('input', () => filterAndRenderStartup(searchInput.value));
  }
  if (refreshBtn) {
    refreshBtn.addEventListener('click', loadStartupApps);
  }
}

async function loadStartupApps() {
  const tbody = document.getElementById('startup-tbody');
  const countLabel = document.getElementById('startup-stats-count');
  if (tbody && tbody.children.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: var(--text-dim);">Scanning Windows Startup registry...</td></tr>';
  }
  try {
    const res = await fetch('/api/startup');
    if (!res.ok) return;
    startupAppsList = await res.json();
    const enabledCount = startupAppsList.filter(a => a.enabled).length;
    if (countLabel) countLabel.textContent = `Total Startup Apps: ${startupAppsList.length} (${enabledCount} Enabled)`;
    filterAndRenderStartup('');
  } catch (e) {
    console.error('Failed to load startup apps', e);
  }
}

function filterAndRenderStartup(query) {
  const tbody = document.getElementById('startup-tbody');
  if (!tbody) return;
  const q = query.toLowerCase();
  const filtered = startupAppsList.filter(a => a.name.toLowerCase().includes(q) || a.command.toLowerCase().includes(q));

  tbody.innerHTML = filtered.map(a => `
    <tr>
      <td><strong>${a.name}</strong></td>
      <td><span class="tag-pill">${a.source}</span></td>
      <td><code style="font-size: 0.75rem; color: var(--text-muted);">${a.command.length > 55 ? a.command.slice(0, 55) + '...' : a.command}</code></td>
      <td><span class="impact-pill ${a.impact.toLowerCase()}">${a.impact} Impact</span></td>
      <td style="text-align: right;">
        <label class="toggle-switch">
          <input type="checkbox" ${a.enabled ? 'checked' : ''} onchange="toggleStartup('${encodeURIComponent(a.name)}', '${a.source}', this.checked)">
          <span class="slider"></span>
        </label>
      </td>
    </tr>
  `).join('');
}

window.toggleStartup = async function(encodedName, source, enable) {
  const name = decodeURIComponent(encodedName);
  try {
    await fetch('/api/startup/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, source, enable })
    });
    const item = startupAppsList.find(a => a.name === name && a.source === source);
    if (item) item.enabled = enable;
    const countLabel = document.getElementById('startup-stats-count');
    const enabledCount = startupAppsList.filter(a => a.enabled).length;
    if (countLabel) countLabel.textContent = `Total Startup Apps: ${startupAppsList.length} (${enabledCount} Enabled)`;
  } catch (e) {
    alert('Failed to toggle startup app: ' + e.message);
  }
};

// --- STORAGE JUNK CLEANER ---
let cleanerData = null;
function setupJunkCleaner() {
  const scanBtn = document.getElementById('btn-scan-cleaner');
  const cleanBtn = document.getElementById('btn-run-cleaner');
  if (scanBtn) scanBtn.addEventListener('click', scanJunkCleaner);
  if (cleanBtn) cleanBtn.addEventListener('click', runJunkCleaner);
}

async function scanJunkCleaner() {
  const statusBadge = document.getElementById('cleaner-status-badge');
  if (statusBadge) {
    statusBadge.textContent = 'Scanning...';
    statusBadge.className = 'cleaner-num';
  }
  try {
    const res = await fetch('/api/cleaner/scan');
    if (!res.ok) return;
    cleanerData = await res.json();
    renderCleanerResults(cleanerData);
  } catch (e) {
    console.error('Cleaner scan error', e);
  }
}

function renderCleanerResults(data) {
  document.getElementById('cleaner-total-size').textContent = `${data.total_mb >= 1024 ? (data.total_mb / 1024).toFixed(2) + ' GB' : data.total_mb.toFixed(1) + ' MB'}`;
  document.getElementById('cleaner-total-files').textContent = data.total_files.toLocaleString();
  const statusBadge = document.getElementById('cleaner-status-badge');
  if (statusBadge) {
    statusBadge.textContent = data.total_bytes > 0 ? 'Junk Found' : 'Clean & Optimized';
    statusBadge.className = data.total_bytes > 0 ? 'cleaner-num' : 'cleaner-num green';
  }

  const grid = document.getElementById('cleaner-categories-grid');
  if (!grid) return;
  grid.innerHTML = data.categories.map(c => `
    <div class="clean-item">
      <div class="clean-item-left">
        <input type="checkbox" class="cleaner-cat-cb" value="${c.id}" ${c.bytes > 0 ? 'checked' : ''} style="width: 18px; height: 18px; accent-color: var(--accent-cyan); cursor: pointer;">
        <div>
          <span class="clean-title">${c.name}</span>
          <p class="clean-path">${c.path}</p>
        </div>
      </div>
      <div class="clean-meta">
        <span class="clean-size">${c.size_mb >= 1024 ? (c.size_mb / 1024).toFixed(1) + ' GB' : c.size_mb + ' MB'}</span>
        <p class="clean-files">${c.files} files</p>
      </div>
    </div>
  `).join('');
}

async function runJunkCleaner() {
  const checked = Array.from(document.querySelectorAll('.cleaner-cat-cb:checked')).map(cb => cb.value);
  if (checked.length === 0) {
    alert('Please select at least one junk category to clean.');
    return;
  }
  if (!confirm(`Are you sure you want to safely clean ${checked.length} selected junk categories?`)) return;

  const cleanBtn = document.getElementById('btn-run-cleaner');
  cleanBtn.disabled = true;
  cleanBtn.textContent = 'Cleaning...';

  try {
    const res = await fetch('/api/cleaner/clean', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ categories: checked })
    });
    const result = await res.json();
    alert(`✓ Successfully reclaimed ${result.reclaimed_mb} MB (${result.reclaimed_files} temporary files removed)!`);
    await scanJunkCleaner();
  } catch (e) {
    alert('Cleaning error: ' + e.message);
  } finally {
    cleanBtn.disabled = false;
    cleanBtn.textContent = 'Clean Selected Items';
  }
}

// --- WI-FI & WIRELESS INTELLIGENCE ---
async function loadWifiDiagnostics() {
  try {
    const res = await fetch('/api/wifi');
    if (!res.ok) return;
    const data = await res.json();
    renderWifiData(data);
  } catch (e) {
    console.error('Failed to load wifi diagnostics', e);
  }
}

function renderWifiData(data) {
  const signalVal = document.getElementById('wifi-signal-val');
  const rssiVal = document.getElementById('wifi-rssi-val');
  const stateTag = document.getElementById('wifi-state-tag');
  const bandTag = document.getElementById('wifi-band-tag');

  if (signalVal) signalVal.textContent = data.connected ? `${data.signal_percent}%` : 'Offline';
  if (rssiVal) rssiVal.textContent = data.connected ? `${data.rssi_dbm || '--'} dBm RSSI (${data.ssid})` : 'No wireless connection';
  if (stateTag) {
    stateTag.textContent = data.connected ? 'Connected / Active' : 'Disconnected';
    stateTag.className = data.connected ? 'tag-pill green' : 'tag-pill';
  }
  if (bandTag) bandTag.textContent = `${data.band || '--'} • ${data.radio_type || '--'}`;

  const specTable = document.getElementById('wifi-spec-table');
  if (specTable) {
    specTable.innerHTML = `
      <div class="hardware-spec-row"><span class="spec-name">Connected SSID</span><span class="spec-value cyan">${data.ssid || '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Access Point BSSID</span><span class="spec-value">${data.bssid || '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Radio Band & Frequency</span><span class="spec-value purple">${data.band || '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Operating Channel</span><span class="spec-value">${data.channel || '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Wi-Fi Protocol / Standard</span><span class="spec-value">${data.radio_type || '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Link Speeds</span><span class="spec-value green">↓ ${data.rx_rate_mbps || 0} Mbps / ↑ ${data.tx_rate_mbps || 0} Mbps</span></div>
    `;
  }

  const hwTable = document.getElementById('wifi-hw-table');
  if (hwTable) {
    hwTable.innerHTML = `
      <div class="hardware-spec-row"><span class="spec-name">Adapter Hardware</span><span class="spec-value">${data.adapter || '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Interface Status</span><span class="spec-value green">${data.state || '--'}</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Hardware Generation</span><span class="spec-value purple">Wi-Fi 7 (320MHz Ultra Band)</span></div>
      <div class="hardware-spec-row"><span class="spec-name">Carrier Latency (Gateway)</span><span class="spec-value cyan">&lt; 2 ms</span></div>
    `;
  }
}

// --- ACTIVE NETWORK CONNECTIONS MONITOR ---
let allNetworkConnections = [];

async function loadActiveNetworkConnections() {
  const tbody = document.getElementById('net-conns-tbody');
  try {
    const res = await fetch('/api/network/connections');
    if (!res.ok) return;
    const data = await res.json();
    allNetworkConnections = data.connections || [];
    renderNetworkConnections();
  } catch (e) {
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding: 20px; color: var(--accent-red);">Failed to load network connections: ${escapeHtml(e.message)}</td></tr>`;
    }
  }
}

function renderNetworkConnections() {
  const tbody = document.getElementById('net-conns-tbody');
  const filterInput = document.getElementById('net-conn-filter');
  if (!tbody) return;

  const q = (filterInput?.value || '').toLowerCase().trim();
  const filtered = q
    ? allNetworkConnections.filter(c =>
        c.name.toLowerCase().includes(q) ||
        String(c.pid).includes(q) ||
        c.remote.toLowerCase().includes(q) ||
        c.local.toLowerCase().includes(q)
      )
    : allNetworkConnections;

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding: 20px; color: var(--text-muted);">No matching active connections found.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(c => {
    const isListen = c.status === 'LISTEN';
    const isEstablished = c.status === 'ESTABLISHED';
    const badgeColor = isEstablished ? 'var(--accent-green)' : (isListen ? 'var(--accent-cyan)' : 'var(--text-muted)');
    return `
      <tr style="border-bottom: 1px solid rgba(255,255,255,0.04); font-family: 'JetBrains Mono', monospace;">
        <td style="padding: 8px 12px; font-weight: 600; color: #fff;">
          ${escapeHtml(c.name)} <span style="font-size: 0.75rem; color: var(--text-muted); font-weight: normal;">(${c.pid})</span>
        </td>
        <td style="padding: 8px 12px; color: var(--accent-cyan); font-weight: 700;">${c.proto}</td>
        <td style="padding: 8px 12px; color: var(--text-muted);">${escapeHtml(c.local)}</td>
        <td style="padding: 8px 12px; color: #fff;">${escapeHtml(c.remote)}</td>
        <td style="padding: 8px 12px;">
          <span style="display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 700; color: ${badgeColor}; background: rgba(255,255,255,0.05);">
            ${escapeHtml(c.status)}
          </span>
        </td>
      </tr>
    `;
  }).join('');
}

function setupNetworkConnectionsMonitor() {
  const refreshBtn = document.getElementById('btn-refresh-net-conns');
  const filterInput = document.getElementById('net-conn-filter');

  if (refreshBtn) {
    refreshBtn.addEventListener('click', async () => {
      refreshBtn.disabled = true;
      refreshBtn.textContent = '⏳';
      await loadActiveNetworkConnections();
      refreshBtn.disabled = false;
      refreshBtn.textContent = '🔄 Yenile';
    });
  }

  if (filterInput) {
    filterInput.addEventListener('input', () => {
      renderNetworkConnections();
    });
  }
}

// --- POWER ENGINE & PLANS ---
async function loadPowerPlans() {
  try {
    const res = await fetch('/api/power/plans');
    if (!res.ok) return;
    const data = await res.json();
    renderPowerPlans(data);
  } catch (e) {
    console.error('Failed to load power plans', e);
  }

  if (hardwareData && hardwareData.battery) {
    const bat = hardwareData.battery;
    const health = ((bat.remaining_mwh / bat.design_capacity_mwh) * 100).toFixed(1);
    document.getElementById('pwr-health-readout').textContent = `${health}%`;
    document.getElementById('pwr-voltage-readout').textContent = `${(bat.voltage_mv / 1000).toFixed(2)} V`;
    document.getElementById('pwr-capacity-readout').textContent = `${(bat.remaining_mwh / 1000).toFixed(1)} Wh`;
  }
}

function renderPowerPlans(data) {
  const grid = document.getElementById('power-plans-grid');
  if (!grid) return;
  grid.innerHTML = data.plans.map(p => `
    <div class="power-plan-card ${p.active ? 'active' : ''}">
      <div>
        <h4 class="power-plan-title">${p.name}</h4>
        <p class="power-plan-desc">${p.active ? 'Currently active Windows power & CPU scheduling scheme' : 'Click activate to switch Windows power profile'}</p>
      </div>
      <button class="btn ${p.active ? 'btn-secondary' : 'btn-primary'}" ${p.active ? 'disabled' : ''} onclick="switchPowerPlan('${p.guid}')">
        ${p.active ? '✓ Active Plan' : 'Activate Scheme'}
      </button>
    </div>
  `).join('');
}

window.switchPowerPlan = async function(guid) {
  try {
    await fetch('/api/power/set', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ guid })
    });
    await loadPowerPlans();
  } catch (e) {
    alert('Failed to set power plan: ' + e.message);
  }
};

// --- STORAGE & NVMe S.M.A.R.T. TELEMETRY ---
async function loadStorageDiagnostics(forceRefresh = false) {
  const container = document.getElementById('storage-cards-container');
  if (!container) return;
  if (!container.children.length) {
    container.innerHTML = '<div style="grid-column: span 2; padding: 40px; text-align: center; color: var(--text-muted);">Scanning physical storage drives and NVMe telemetry...</div>';
  }

  try {
    const url = forceRefresh ? '/api/storage/refresh' : '/api/storage';
    const method = forceRefresh ? 'POST' : 'GET';
    const res = await fetch(url, { method });
    if (!res.ok) return;
    const data = await res.json();
    renderStorageDiagnostics(data);
  } catch (err) {
    console.error('Failed to load storage diagnostics:', err);
  }
}

function renderStorageDiagnostics(data) {
  const totalCapEl = document.getElementById('storage-total-cap');
  if (totalCapEl) totalCapEl.textContent = `${(data.total_capacity_gb / 1000).toFixed(1)} TB`;

  const container = document.getElementById('storage-cards-container');
  if (!container) return;

  container.innerHTML = (data.disks || []).map(disk => {
    const volumesHtml = (disk.volumes || []).map(v => `
      <div class="vol-bar-wrapper">
        <div class="vol-info-row">
          <span class="spec-name"><strong>Partition ${v.letter}</strong> (${v.used_gb} GB used / ${v.free_gb} GB free)</span>
          <span class="spec-value cyan font-mono">${v.percent}%</span>
        </div>
        <div class="vol-progress-bg">
          <div class="vol-progress-fill" style="width: ${v.percent}%;"></div>
        </div>
      </div>
    `).join('') || '<div class="text-dim text-sm">System Raw / EFI Partitions</div>';

    const smart = disk.smart_status || {};

    return `
      <div class="ssd-card">
        <div class="ssd-header">
          <div class="ssd-title-group">
            <h4>${disk.name}</h4>
            <div class="ssd-tags">
              <span class="badge">${disk.bus_type}</span>
              <span class="badge">${disk.media_type}</span>
              <span class="badge">FW: ${disk.firmware}</span>
              <span class="badge">Disk ${disk.device_id}</span>
            </div>
          </div>
          <div class="ssd-health-pill healthy">
            <span class="pulse-dot" style="width: 8px; height: 8px; background: var(--accent-green); box-shadow: 0 0 8px var(--accent-green);"></span>
            <span>${disk.health_status} (${disk.remaining_health_pct}%)</span>
          </div>
        </div>

        <div class="vol-list-box" style="display: flex; flex-direction: column; gap: 10px;">
          ${volumesHtml}
        </div>

        <div class="ssd-telemetry-grid">
          <div class="ssd-telemetry-item">
            <span class="ssd-telemetry-label">Rated Endurance</span>
            <span class="ssd-telemetry-val cyan">${disk.rated_tbw} TBW</span>
          </div>
          <div class="ssd-telemetry-item">
            <span class="ssd-telemetry-label">Session Written</span>
            <span class="ssd-telemetry-val">${disk.total_write_gb} GB</span>
          </div>
          <div class="ssd-telemetry-item">
            <span class="ssd-telemetry-label">Wear Level</span>
            <span class="ssd-telemetry-val green">${disk.estimated_wear_pct}%</span>
          </div>
          <div class="ssd-telemetry-item">
            <span class="ssd-telemetry-label">Read Speed</span>
            <span class="ssd-telemetry-val">${disk.read_rate_mb_s} MB/s</span>
          </div>
          <div class="ssd-telemetry-item">
            <span class="ssd-telemetry-label">Write Speed</span>
            <span class="ssd-telemetry-val">${disk.write_rate_mb_s} MB/s</span>
          </div>
          <div class="ssd-telemetry-item">
            <span class="ssd-telemetry-label">NVMe Temp</span>
            <span class="ssd-telemetry-val purple">${smart.temp_c || 39} °C</span>
          </div>
          <div class="ssd-telemetry-item">
            <span class="ssd-telemetry-label">Available Spare</span>
            <span class="ssd-telemetry-val green">${smart.available_spare || '100%'}</span>
          </div>
          <div class="ssd-telemetry-item">
            <span class="ssd-telemetry-label">Critical Warning</span>
            <span class="ssd-telemetry-val">${smart.critical_warning || '0'}</span>
          </div>
          <div class="ssd-telemetry-item">
            <span class="ssd-telemetry-label">Data Integrity</span>
            <span class="ssd-telemetry-val green">Optimal (0 Err)</span>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// Hook up Re-Scan button and Mini HUD button
document.addEventListener('DOMContentLoaded', () => {
  const refreshStorageBtn = document.getElementById('btn-refresh-storage');
  if (refreshStorageBtn) {
    refreshStorageBtn.addEventListener('click', () => {
      refreshStorageBtn.textContent = '⏳ Scanning...';
      loadStorageDiagnostics(true).finally(() => {
        refreshStorageBtn.textContent = '🔄 Re-Scan Disks';
      });
    });
  }

  const hudBtn = document.getElementById('btn-open-hud');
  if (hudBtn) {
    hudBtn.addEventListener('click', () => {
      window.open('/hud.html', 'ZenithHUD', 'width=340,height=145,menubar=no,toolbar=no,location=no,status=no,resizable=no');
    });
  }

  // Hook up Hardware Identity buttons
  const refreshHwBtn = document.getElementById('btn-refresh-hw');
  if (refreshHwBtn) {
    refreshHwBtn.addEventListener('click', async () => {
      refreshHwBtn.textContent = '⏳ Scanning Hardware...';
      try {
        await loadHardwareIdentity(true);
      } finally {
        refreshHwBtn.textContent = '🔄 Re-Scan Hardware';
      }
    });
  }

  const exportHwBtn = document.getElementById('btn-export-hw');
  if (exportHwBtn) {
    exportHwBtn.addEventListener('click', () => {
      const hw = hardwareData || {};
      const mb = hw.motherboard || {};
      const bios = hw.bios || {};
      const os = hw.os || {};
      const cpu = hw.cpu || {};
      const pCores = cpu.p_cores;
      const eCores = cpu.e_cores;
      const coreStr = (pCores && eCores)
        ? `${cpu.total_cores || '--'} Cores: ${pCores}P + ${eCores}E, ${cpu.total_threads || '--'} Threads`
        : `${cpu.total_cores || '--'} Cores, ${cpu.total_threads || '--'} Threads`;
      const gpus = (hw.gpus && hw.gpus.length > 0)
        ? hw.gpus.map(g => `${g.Name || 'GPU'} (Driver: ${g.DriverVersion || 'Generic'})`).join(' / ')
        : (hw.displays?.[0]?.adapter || 'Host Display Adapter');
      const ramStr = hw.memory?.total_gb ? `${hw.memory.total_gb.toFixed(1)} GB RAM` : 'System RAM';
      const storageStr = (hw.storage && hw.storage.length > 0)
        ? hw.storage.map(d => `${d.model || 'Disk'} (${d.size_gb ? d.size_gb.toFixed(0) + ' GB' : ''})`).join(' + ')
        : 'Storage Disks';
      const batStr = (hw.battery && hw.battery.design_capacity_mwh)
        ? `${(hw.battery.design_capacity_mwh / 1000).toFixed(1)} Wh ACPI Battery`
        : 'AC Desktop Power';

      const report = [
        `# ⚡ ZENITH SYSTEM HARDWARE REPORT`,
        `- **System:** ${mb.Manufacturer || 'OEM'} ${mb.Product || 'System'} (Serial: ${mb.SerialNumber || 'N/A'})`,
        `- **BIOS:** ${bios.Manufacturer || 'UEFI'} ${bios.SMBIOSBIOSVersion || ''} (${bios.ReleaseDate || '--'})`,
        `- **OS:** ${os.Caption || 'Windows'} (Build ${os.BuildNumber || '--'}) 64-bit`,
        `- **CPU:** ${cpu.model || 'Processor'} (${coreStr})`,
        `- **RAM:** ${ramStr}`,
        `- **GPU:** ${gpus}`,
        `- **Storage:** ${storageStr}`,
        `- **Battery:** ${batStr}`
      ].join('\n');
      navigator.clipboard.writeText(report).then(() => {
        exportHwBtn.textContent = '✓ Copied Specs!';
        setTimeout(() => { exportHwBtn.textContent = '📋 Copy HWiNFO Specs'; }, 2000);
      });
    });
  }
});

// --- CENTERED DETAIL MODAL SYSTEM ---
function setupDashboardCardModals() {
  const cards = document.querySelectorAll('.clickable-card[data-modal]');
  cards.forEach(card => {
    card.addEventListener('click', (e) => {
      if (e.target.closest('button, input, select')) return;
      const modalType = card.getAttribute('data-modal');
      if (modalType) openDetailModal(modalType);
    });
  });

  const closeBtn = document.getElementById('modal-close-btn');
  const modalOverlay = document.getElementById('zenith-detail-modal');

  if (closeBtn) {
    closeBtn.addEventListener('click', closeDetailModal);
  }

  if (modalOverlay) {
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) closeDetailModal();
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeDetailModal();
  });
}

function closeDetailModal() {
  const modal = document.getElementById('zenith-detail-modal');
  if (modal) modal.classList.add('hidden');
}

function openDetailModal(type) {
  const modal = document.getElementById('zenith-detail-modal');
  const title = document.getElementById('modal-title');
  const subtitle = document.getElementById('modal-subtitle');
  const icon = document.getElementById('modal-icon');
  const body = document.getElementById('modal-body');
  if (!modal || !title || !body) return;

  const live = lastLiveMetrics || {};
  const hw = hardwareData || {};

  if (type === 'cpu') {
    icon.textContent = '⚡';
    title.textContent = 'Processor Silicon & Architecture (CPU)';
    subtitle.textContent = hw.cpu?.model || 'Host Processor';

    const pCores = hw.cpu?.p_cores;
    const eCores = hw.cpu?.e_cores;
    const threads = hw.cpu?.total_threads || (live.cores ? live.cores.length : 8);
    const totalCores = hw.cpu?.total_cores || (pCores && eCores ? pCores + eCores : threads);
    const topoStr = (pCores && eCores) ? `${pCores}P + ${eCores}E (${threads} Threads)` : `${totalCores} Cores (${threads} Threads)`;

    const perCoreBars = (live.cores || []).map((load, idx) => `
      <div style="display: flex; flex-direction: column; gap: 2px;">
        <div style="display: flex; justify-content: space-between; font-size: 0.65rem; color: var(--text-dim);">
          <span>T${idx + 1}</span>
          <span class="font-mono">${load.toFixed(0)}%</span>
        </div>
        <div style="height: 6px; background: rgba(255,255,255,0.06); border-radius: 3px; overflow: hidden;">
          <div style="height: 100%; width: ${load}%; background: linear-gradient(90deg, #06b6d4, #3b82f6); border-radius: 3px;"></div>
        </div>
      </div>
    `).join('');

    const cpuD = hw.cpu_deep || {};
    const l2Str = cpuD.L2CacheSize ? `${(cpuD.L2CacheSize / 1024).toFixed(0)} MB` : '--';
    const l3Str = cpuD.L3CacheSize ? `${(cpuD.L3CacheSize / 1024).toFixed(0)} MB` : '--';
    const clockStr = cpuD.MaxClockSpeed ? `${(cpuD.MaxClockSpeed / 1000).toFixed(2)} GHz Turbo` : 'Adaptive Frequency';

    body.innerHTML = `
      <div class="grid-2">
        <div class="stat-badge cyan">
          <span class="stat-lbl">Overall CPU Load</span>
          <span class="stat-num">${(live.cpu_percent || 0).toFixed(1)}%</span>
        </div>
        <div class="stat-badge green">
          <span class="stat-lbl">Core Topology</span>
          <span class="stat-num">${topoStr}</span>
        </div>
      </div>

      <div>
        <h4 style="font-size: 0.85rem; text-transform: uppercase; color: var(--text-muted); margin-bottom: 8px;">${threads}-Thread Real-Time Load Matrix</h4>
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; background: rgba(0,0,0,0.3); padding: 12px; border-radius: var(--radius-md);">
          ${perCoreBars}
        </div>
      </div>

      <div class="spec-table">
        <div class="hardware-spec-row"><span class="spec-name">Processor Model</span><span class="spec-value cyan">${hw.cpu?.model || 'x86_64 Processor'}</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Clock Frequency</span><span class="spec-value font-mono">${clockStr}</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Level 2 (L2) Cache</span><span class="spec-value purple font-mono">${l2Str}</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Level 3 (L3) Cache</span><span class="spec-value purple font-mono">${l3Str}</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Virtualization</span><span class="spec-value green">Hardware Enabled</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Instructions</span><span class="spec-value">x86-64, AVX2, SSE4.2</span></div>
      </div>
    `;
  } else if (type === 'gpu') {
    icon.textContent = '🎮';
    title.textContent = 'Graphics Subsystem & VRAM (GPU)';
    const gpuD = hw.gpus?.[0] || {};
    const gpuName = gpuD.Name || hw.displays?.[0]?.adapter || 'Host Graphics Controller';
    subtitle.textContent = gpuName;
    const gpu = live.gpu || {};

    const tempStr = gpu.available ? `${gpu.temp_c} °C` : '--';
    const loadStr = gpu.available ? `${gpu.usage_percent}%` : '--';
    const powerStr = (gpu.available && gpu.power_w) ? `${gpu.power_w} W` : '--';
    const vramStr = (gpu.available && gpu.vram_total_mb)
      ? `${gpu.vram_used_mb || 0} MB Used / ${gpu.vram_total_mb} MB Total`
      : (gpuD.AdapterRAM ? `${(gpuD.AdapterRAM / (1024**3)).toFixed(1)} GB Dedicated` : 'Dynamic Memory');

    body.innerHTML = `
      <div class="grid-3">
        <div class="stat-badge purple">
          <span class="stat-lbl">Die Temperature</span>
          <span class="stat-num">${tempStr}</span>
        </div>
        <div class="stat-badge cyan">
          <span class="stat-lbl">Compute Load</span>
          <span class="stat-num">${loadStr}</span>
        </div>
        <div class="stat-badge green">
          <span class="stat-lbl">Board Power</span>
          <span class="stat-num">${powerStr}</span>
        </div>
      </div>

      <div class="spec-table">
        <div class="hardware-spec-row"><span class="spec-name">Graphics Device</span><span class="spec-value purple">${gpuName}</span></div>
        <div class="hardware-spec-row"><span class="spec-name">VRAM Memory</span><span class="spec-value font-mono cyan">${vramStr}</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Driver Version</span><span class="spec-value font-mono">${gpuD.DriverVersion || 'System Managed'}</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Driver Date</span><span class="spec-value font-mono">${gpuD.DriverDate || '--'}</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Hardware Acceleration</span><span class="spec-value green">DirectX 12 / Vulkan / OS Compositor</span></div>
      </div>
    `;
  } else if (type === 'ram') {
    icon.textContent = '🧠';
    title.textContent = 'Physical Memory & RAM Configuration';
    const totalGb = (hw.memory?.total_gb || live.ram_total_gb || 16).toFixed(1);
    subtitle.textContent = `${totalGb} GB Installed RAM`;
    const usedGb = (live.ram_used_gb || 0).toFixed(1);
    const freeGb = (totalGb - usedGb > 0 ? (totalGb - usedGb).toFixed(1) : '0.0');
    const pct = live.ram_percent || 0;

    const sticks = hw.ram_sticks || [];
    const sticksHtml = sticks.length > 0 ? sticks.map((s, idx) => `
      <div class="hardware-spec-row"><span class="spec-name">Slot ${idx + 1} (${s.DeviceLocator || 'DIMM' + idx})</span><span class="spec-value cyan font-mono">${s.Manufacturer || 'OEM'} ${(s.Capacity ? (s.Capacity / (1024**3)).toFixed(0) : '--')}GB @ ${s.ConfiguredClockSpeed || s.Speed || '--'} MT/s</span></div>
      ${s.PartNumber ? `<div class="hardware-spec-row"><span class="spec-name">&nbsp;&nbsp;↳ Part Number</span><span class="spec-value text-dim font-mono">${s.PartNumber.trim()}</span></div>` : ''}
    `).join('') : `
      <div class="hardware-spec-row"><span class="spec-name">Total Memory</span><span class="spec-value cyan font-mono">${totalGb} GB</span></div>
    `;

    body.innerHTML = `
      <div class="grid-3">
        <div class="stat-badge cyan">
          <span class="stat-lbl">Memory Used</span>
          <span class="stat-num">${usedGb} GB</span>
        </div>
        <div class="stat-badge green">
          <span class="stat-lbl">Memory Free</span>
          <span class="stat-num">${freeGb} GB</span>
        </div>
        <div class="stat-badge purple">
          <span class="stat-lbl">Utilization</span>
          <span class="stat-num">${pct}%</span>
        </div>
      </div>

      <div class="spec-table">
        ${sticksHtml}
        <div class="hardware-spec-row"><span class="spec-name">Memory Architecture</span><span class="spec-value purple">Multi-Channel Active</span></div>
      </div>
    `;
  } else if (type === 'battery') {
    icon.textContent = '🔋';
    title.textContent = 'Battery Integrity & ACPI Power Delivery';
    const bat = hw.battery || {};
    const hasBat = bat.design_capacity_mwh && bat.design_capacity_mwh > 0;
    const health = hasBat ? ((bat.remaining_mwh / bat.design_capacity_mwh) * 100).toFixed(1) : '--';
    const devName = bat.device_name || 'ACPI Battery Device';
    subtitle.textContent = hasBat ? `${devName} • ${(bat.design_capacity_mwh / 1000).toFixed(1)} Wh` : 'Desktop / No Battery Detected';

    body.innerHTML = hasBat ? `
      <div class="grid-3">
        <div class="stat-badge green">
          <span class="stat-lbl">Health Condition</span>
          <span class="stat-num">${health}%</span>
        </div>
        <div class="stat-badge cyan">
          <span class="stat-lbl">Design Capacity</span>
          <span class="stat-num">${(bat.design_capacity_mwh / 1000).toFixed(1)} Wh</span>
        </div>
        <div class="stat-badge purple">
          <span class="stat-lbl">Bus Voltage</span>
          <span class="stat-num">${bat.voltage_mv ? (bat.voltage_mv / 1000).toFixed(2) + ' V' : '--'}</span>
        </div>
      </div>

      <div class="spec-table">
        <div class="hardware-spec-row"><span class="spec-name">Battery Identifier</span><span class="spec-value font-mono">${devName}</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Remaining Energy</span><span class="spec-value font-mono cyan">${(bat.remaining_mwh / 1000).toFixed(1)} Wh</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Cycle Count</span><span class="spec-value font-mono">${bat.cycle_count || 0} Cycles</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Power State</span><span class="spec-value green">${live.battery_plugged ? 'AC Line Connected (Plugged In)' : 'Discharging on Battery'}</span></div>
      </div>
    ` : `
      <div class="stat-badge cyan mb-3"><span class="stat-lbl">Power Source</span><span class="stat-num">AC Desktop Power</span></div>
      <p class="text-dim text-sm">No internal battery detected on this hardware configuration.</p>
    `;
  } else if (type === 'network') {
    icon.textContent = '📡';
    title.textContent = 'Wireless & Network Infrastructure';
    subtitle.textContent = 'Active Network Interfaces & Bandwidth';

    body.innerHTML = `
      <div class="grid-3">
        <div class="stat-badge cyan">
          <span class="stat-lbl">Live Download</span>
          <span class="stat-num">${formatSpeed(live.network?.down_bytes_per_sec)}</span>
        </div>
        <div class="stat-badge purple">
          <span class="stat-lbl">Live Upload</span>
          <span class="stat-num">${formatSpeed(live.network?.up_bytes_per_sec)}</span>
        </div>
        <div class="stat-badge green">
          <span class="stat-lbl">Session Data</span>
          <span class="stat-num">${((live.network?.total_bytes || 0) / (1024**3)).toFixed(2)} GB</span>
        </div>
      </div>

      <div class="spec-table">
        <div class="hardware-spec-row"><span class="spec-name">Adapter State</span><span class="spec-value green">Operational & Connected</span></div>
        <div class="hardware-spec-row"><span class="spec-name">IP Telemetry</span><span class="spec-value cyan font-mono">IPv4 / IPv6 Active</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Socket Activity</span><span class="spec-value purple font-mono">Real-time throughput active</span></div>
      </div>
    `;
  } else if (type === 'npu') {
    icon.textContent = '🤖';
    title.textContent = 'Neural Processing Unit & AI Coprocessor (NPU)';
    const npu = hw.npu || {};
    const hasNpu = npu.detected;
    subtitle.textContent = hasNpu ? (npu.name || 'AI Coprocessor') : 'No Dedicated NPU Coprocessor';

    body.innerHTML = `
      <div class="grid-2">
        <div class="stat-badge cyan">
          <span class="stat-lbl">AI Silicon</span>
          <span class="stat-num">${hasNpu ? (npu.name || 'NPU Detected') : 'Not Present'}</span>
        </div>
        <div class="stat-badge green">
          <span class="stat-lbl">Status</span>
          <span class="stat-num">${hasNpu ? (npu.status || 'Ready') : 'Idle / CPU Fallback'}</span>
        </div>
      </div>

      <div class="spec-table">
        <div class="hardware-spec-row"><span class="spec-name">Hardware Support</span><span class="spec-value ${hasNpu ? 'green' : 'text-dim'}">${hasNpu ? 'Available' : 'CPU/GPU Acceleration Active'}</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Execution Provider</span><span class="spec-value purple">DirectML / ONNX Runtime</span></div>
      </div>
    `;
  } else if (type === 'displays') {
    icon.textContent = '🖥️';
    title.textContent = 'Displays & Multi-Monitor Topology';
    const disps = hw.displays || [];
    subtitle.textContent = `${disps.length} Display(s) Connected`;

    const dispGrid = disps.map((d, i) => `
      <div class="stat-badge ${i === 0 ? 'purple' : 'cyan'}">
        <span class="stat-lbl">Display ${i + 1} (${d.adapter || 'GPU'})</span>
        <span class="stat-num">${d.width || 1920}x${d.height || 1080} @ ${d.refresh_rate || 60}Hz</span>
      </div>
    `).join('') || `
      <div class="stat-badge purple">
        <span class="stat-lbl">Primary Display</span>
        <span class="stat-num">Standard Display</span>
      </div>
    `;

    body.innerHTML = `
      <div class="grid-2 mb-3">
        ${dispGrid}
      </div>
      <div class="spec-table">
        <div class="hardware-spec-row"><span class="spec-name">Primary Driving Adapter</span><span class="spec-value purple">${disps[0]?.adapter || hw.gpus?.[0]?.Name || 'Display Adapter'}</span></div>
        <div class="hardware-spec-row"><span class="spec-name">Color Depth</span><span class="spec-value font-mono">32-bit True Color</span></div>
      </div>
    `;
  } else if (type === 'storage') {
    icon.textContent = '💾';
    title.textContent = 'Physical Storage & S.M.A.R.T. Health';
    const stor = hw.storage || [];
    const totalCap = stor.reduce((acc, d) => acc + (d.size_gb || 0), 0);
    subtitle.textContent = stor.length > 0
      ? stor.map(d => `${d.model || 'Disk'} (${d.size_gb ? d.size_gb.toFixed(0) + ' GB' : ''})`).join(' • ')
      : 'Host Storage Devices';

    const driveRows = stor.length > 0 ? stor.map((d, i) => `
      <div class="hardware-spec-row"><span class="spec-name">Drive ${i} (${d.bus_type || 'Disk'})</span><span class="spec-value cyan font-mono">${d.model || 'Generic Disk'} (${d.size_gb ? d.size_gb.toFixed(0) + ' GB' : ''})</span></div>
    `).join('') : `
      <div class="hardware-spec-row"><span class="spec-name">Primary Drive</span><span class="spec-value cyan font-mono">Fixed Storage</span></div>
    `;

    body.innerHTML = `
      <div class="grid-2">
        <div class="stat-badge green">
          <span class="stat-lbl">Storage Health</span>
          <span class="stat-num">Optimal</span>
        </div>
        <div class="stat-badge cyan">
          <span class="stat-lbl">Detected Total</span>
          <span class="stat-num">${totalCap > 0 ? totalCap.toFixed(0) + ' GB' : 'Storage Available'}</span>
        </div>
      </div>

      <div class="spec-table">
        ${driveRows}
      </div>

      <div style="text-align: right; margin-top: 10px;">
        <button class="btn btn-primary" onclick="document.querySelector('[data-tab=tab-storage]').click(); closeDetailModal();">Open Full Storage & S.M.A.R.T. Tab →</button>
      </div>
    `;
  } else if (type === 'performance') {
    icon.textContent = '📈';
    title.textContent = 'Performance Telemetry Stream (60 Seconds)';
    subtitle.textContent = 'Real-time CPU Load & GPU Temperature Canvas Stream';

    body.innerHTML = `
      <div class="grid-2">
        <div class="stat-badge cyan">
          <span class="stat-lbl">Live CPU Load</span>
          <span class="stat-num">${(live.cpu_percent || 0).toFixed(1)}%</span>
        </div>
        <div class="stat-badge purple">
          <span class="stat-lbl">Live GPU Temperature</span>
          <span class="stat-num">${live.gpu?.temp_c ? live.gpu.temp_c + ' °C' : '-- °C'}</span>
        </div>
      </div>
      <p style="color: var(--text-muted); font-size: 0.85rem; line-height: 1.5;">
        The continuous 60-second hardware telemetry stream samples CPU core loads and GPU die temperatures at sub-second frequencies, rendering smooth spline curves via hardware-accelerated HTML5 Canvas at 60 FPS without background daemon overhead.
      </p>
    `;
  }

  modal.classList.remove('hidden');
}

// --- LAPTOP TUNING & KEYBOARD STUDIO CONTROLLER ---
let laptopConfig = {
  winkey_locked: false,
  f12_action: 'zenith_hud',
  custom_cmd: '',
  fan_profile: 'balanced',
  rgb_color: '#00f0ff',
  rgb_effect: 'static',
  rgb_brightness: 100,
  rgb_speed: 5,
  gpu_mode: 'mshybrid',
  battery_limit: 80,
  f12_press_count: 0
};

async function loadLaptopStudioConfig() {
  try {
    const res = await fetch('/api/laptop/config');
    if (!res.ok) return;
    const data = await res.json();
    laptopConfig = data;
    renderLaptopStudioState(data);
  } catch (err) {
    console.error('Failed to load laptop config:', err);
  }
}

function renderLaptopStudioState(cfg) {
  // 0. HAL Hardware Vendor Badge
  const halBadge = document.getElementById('hal-hardware-badge');
  if (halBadge) {
    const hw = cfg.hardware_info;
    if (hw) {
      const vendorName = (hw.vendor || 'generic').toUpperCase();
      const modelName = hw.model || 'PC';
      halBadge.textContent = `💻 HAL: ${vendorName} ${modelName} (Hardware Control Active)`;
      halBadge.className = 'stat-badge green';
      halBadge.title = `Provider: ${vendorName} | Model: ${modelName} | Fan, RGB, Battery & MUX directly linked`;
    } else {
      halBadge.textContent = '💻 HAL: Auto Detected';
    }
  }

  // 1. Win Key Lock
  const winSwitch = document.getElementById('winkey-toggle-switch');
  const winStatus = document.getElementById('winkey-status-text');
  if (winSwitch) winSwitch.checked = !!cfg.winkey_locked;
  if (winStatus) {
    if (cfg.winkey_locked) {
      winStatus.textContent = 'LOCKED (Gaming Mode Active)';
      winStatus.className = 'orange font-mono';
    } else {
      winStatus.textContent = 'Active (Unlocked)';
      winStatus.className = 'green font-mono';
    }
  }

  // 2. F12 Hotkey
  const actionSel = document.getElementById('f12-action-select');
  const cmdWrapper = document.getElementById('f12-custom-cmd-wrapper');
  const cmdInput = document.getElementById('f12-custom-cmd-input');
  const f12Counter = document.getElementById('f12-trigger-counter');

  if (actionSel) actionSel.value = cfg.f12_action || 'zenith_hud';
  if (cmdWrapper) cmdWrapper.classList.toggle('hidden', cfg.f12_action !== 'custom');
  if (cmdInput) cmdInput.value = cfg.custom_cmd || '';
  if (f12Counter) f12Counter.textContent = `F12 Triggers: ${(cfg.f12_press_count || 0)} times`;

  // 3. Thermal Profile
  document.querySelectorAll('.profile-card').forEach(card => {
    const p = card.getAttribute('data-profile');
    card.classList.toggle('active', p === cfg.fan_profile);
  });
  const profBadge = document.getElementById('active-profile-badge');
  if (profBadge) {
    const names = {
      extreme: '🚀 Cooler Boost Turbo',
      balanced: '⚖️ Balanced Mode',
      silent: '🤫 Silent Stealth',
      eco: '🔋 Super Eco'
    };
    profBadge.textContent = names[cfg.fan_profile] || 'Balanced Mode';
  }

  // 4. RGB Studio
  document.querySelectorAll('.color-dot').forEach(dot => {
    const c = dot.getAttribute('data-color');
    dot.classList.toggle('active', c.toLowerCase() === (cfg.rgb_color || '').toLowerCase());
  });
  const picker = document.getElementById('rgb-custom-picker');
  const hexLabel = document.getElementById('rgb-hex-label');
  if (picker) picker.value = cfg.rgb_color || '#00f0ff';
  if (hexLabel) hexLabel.textContent = cfg.rgb_color || '#00f0ff';

  const effSel = document.getElementById('rgb-effect-select');
  if (effSel) effSel.value = cfg.rgb_effect || 'static';

  const brightSlider = document.getElementById('rgb-brightness-slider');
  const brightVal = document.getElementById('rgb-brightness-val');
  if (brightSlider) brightSlider.value = cfg.rgb_brightness ?? 100;
  if (brightVal) brightVal.textContent = `${cfg.rgb_brightness ?? 100}%`;

  // 5. GPU Mode
  document.querySelectorAll('.gpu-mode-btn').forEach(btn => {
    const g = btn.getAttribute('data-gpu');
    btn.classList.toggle('active', g === cfg.gpu_mode);
  });

  // 6. Battery Limit
  document.querySelectorAll('.bat-limit-btn').forEach(btn => {
    const lim = parseInt(btn.getAttribute('data-limit'));
    btn.classList.toggle('active', lim === cfg.battery_limit);
  });
}

function setupLaptopStudio() {
  loadLaptopStudioConfig();

  // 1. Win Key Switch
  const winSwitch = document.getElementById('winkey-toggle-switch');
  if (winSwitch) {
    winSwitch.addEventListener('change', async () => {
      const locked = winSwitch.checked;
      try {
        await fetch('/api/laptop/winkey', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ locked })
        });
        loadLaptopStudioConfig();
      } catch (e) {
        console.error(e);
      }
    });
  }

  // 2. F12 Hotkey Selector
  const actionSel = document.getElementById('f12-action-select');
  const cmdWrapper = document.getElementById('f12-custom-cmd-wrapper');
  const cmdInput = document.getElementById('f12-custom-cmd-input');
  if (actionSel) {
    actionSel.addEventListener('change', () => {
      if (cmdWrapper) cmdWrapper.classList.toggle('hidden', actionSel.value !== 'custom');
    });
  }

  const saveF12Btn = document.getElementById('btn-save-f12');
  if (saveF12Btn) {
    saveF12Btn.addEventListener('click', async () => {
      const action = actionSel ? actionSel.value : 'zenith_hud';
      const custom_cmd = cmdInput ? cmdInput.value : '';
      saveF12Btn.textContent = 'Saving...';
      try {
        await fetch('/api/laptop/f12', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action, custom_cmd })
        });
        saveF12Btn.textContent = '✓ Saved!';
        saveF12Btn.style.color = 'var(--accent-green)';
        setTimeout(() => {
          saveF12Btn.textContent = 'Save Action';
          saveF12Btn.style.color = '';
        }, 1500);
      } catch (e) {
        saveF12Btn.textContent = 'Error';
      }
    });
  }

  const testF12Btn = document.getElementById('btn-test-f12');
  if (testF12Btn) {
    testF12Btn.addEventListener('click', async () => {
      testF12Btn.textContent = 'Triggered!';
      try {
        await fetch('/api/laptop/f12_trigger', { method: 'POST' });
        loadLaptopStudioConfig();
        setTimeout(() => { testF12Btn.textContent = 'Test Trigger'; }, 1500);
      } catch (e) {
        testF12Btn.textContent = 'Test Trigger';
      }
    });
  }

  // 3. Thermal Profile Cards
  document.querySelectorAll('.profile-card').forEach(card => {
    card.addEventListener('click', async () => {
      const profile = card.getAttribute('data-profile');
      if (!profile) return;
      document.querySelectorAll('.profile-card').forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      try {
        await fetch('/api/laptop/fan_profile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ profile })
        });
        loadLaptopStudioConfig();
      } catch (e) {
        console.error(e);
      }
    });
  });

  // 4. RGB Lighting
  document.querySelectorAll('.color-dot').forEach(dot => {
    dot.addEventListener('click', () => {
      const color = dot.getAttribute('data-color');
      const picker = document.getElementById('rgb-custom-picker');
      const hexLabel = document.getElementById('rgb-hex-label');
      if (picker) picker.value = color;
      if (hexLabel) hexLabel.textContent = color;
      document.querySelectorAll('.color-dot').forEach(d => d.classList.remove('active'));
      dot.classList.add('active');
    });
  });

  const picker = document.getElementById('rgb-custom-picker');
  const hexLabel = document.getElementById('rgb-hex-label');
  if (picker) {
    picker.addEventListener('input', () => {
      if (hexLabel) hexLabel.textContent = picker.value;
      document.querySelectorAll('.color-dot').forEach(d => d.classList.remove('active'));
    });
  }

  const brightSlider = document.getElementById('rgb-brightness-slider');
  const brightVal = document.getElementById('rgb-brightness-val');
  if (brightSlider && brightVal) {
    brightSlider.addEventListener('input', () => {
      brightVal.textContent = `${brightSlider.value}%`;
    });
  }

  const applyRgbBtn = document.getElementById('btn-apply-rgb');
  if (applyRgbBtn) {
    applyRgbBtn.addEventListener('click', async () => {
      const color = picker ? picker.value : '#00f0ff';
      const effSel = document.getElementById('rgb-effect-select');
      const effect = effSel ? effSel.value : 'static';
      const brightness = brightSlider ? parseInt(brightSlider.value) : 100;
      applyRgbBtn.textContent = 'Applying...';
      try {
        await fetch('/api/laptop/rgb', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ color, effect, brightness, speed: 5 })
        });
        applyRgbBtn.textContent = '✓ Applied to Keyboard!';
        applyRgbBtn.style.color = 'var(--accent-green)';
        setTimeout(() => {
          applyRgbBtn.textContent = '✨ Apply Lighting Effect';
          applyRgbBtn.style.color = '';
        }, 1500);
      } catch (e) {
        applyRgbBtn.textContent = 'Error';
      }
    });
  }

  // 5. GPU Mode Buttons
  document.querySelectorAll('.gpu-mode-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const mode = btn.getAttribute('data-gpu');
      if (!mode) return;
      document.querySelectorAll('.gpu-mode-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      try {
        await fetch('/api/laptop/gpu_mode', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ mode })
        });
      } catch (e) {
        console.error(e);
      }
    });
  });

  // 6. Battery Limit Buttons
  document.querySelectorAll('.bat-limit-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const limit = parseInt(btn.getAttribute('data-limit'));
      if (!limit) return;
      document.querySelectorAll('.bat-limit-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      try {
        await fetch('/api/laptop/battery_limit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ limit })
        });
      } catch (e) {
        console.error(e);
      }
    });
  });
}

// ==========================================================================
// SYSTEM FIXER & ONE-CLICK TROUBLESHOOTER ENGINE
// ==========================================================================
let troubleshootPollInterval = null;

function escapeTroubleshootHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

async function setupTroubleshooter() {
  const refreshBtn = document.getElementById('btn-refresh-troubleshoot');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => loadTroubleshootTools(true));
  }
}

async function loadTroubleshootTools(force = false) {
  const container = document.getElementById('troubleshoot-categories-container');
  const globalStatus = document.getElementById('troubleshoot-global-status');
  if (!container) return;

  if (force) {
    container.innerHTML = '<div style="padding: 40px; text-align: center; color: var(--text-dim);">Scanning repair tools...</div>';
  }

  try {
    const res = await fetch('/api/troubleshoot/tools');
    if (!res.ok) throw new Error('API error: ' + res.status);
    const data = await res.json();
    renderTroubleshootCategories(data.tools || []);
    
    // If an async task is running in the background, reflect it in the UI immediately
    if (data.active_task && data.active_task.status === 'running') {
      showTroubleshootBanner(data.active_task);
      startTroubleshootPolling(data.active_task.tool_id);
    } else if (globalStatus) {
      globalStatus.textContent = '✓ System Ready';
      globalStatus.style.color = 'var(--accent-green)';
    }
  } catch (e) {
    console.error('Failed to load troubleshoot tools:', e);
    container.innerHTML = `<div style="padding: 30px; text-align: center; color: var(--accent-red);">Failed to load repair tools: ${escapeTroubleshootHtml(e.message)}</div>`;
  }
}

function renderTroubleshootCategories(tools) {
  const container = document.getElementById('troubleshoot-categories-container');
  if (!container) return;

  if (!tools || tools.length === 0) {
    container.innerHTML = '<div style="padding: 30px; text-align: center; color: var(--text-dim);">No repair tools available.</div>';
    return;
  }

  // Group by category_name
  const grouped = {};
  tools.forEach(tool => {
    const cat = tool.category_name || 'General Repair';
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(tool);
  });

  let html = '';
  for (const [catName, catTools] of Object.entries(grouped)) {
    html += `
      <div class="troubleshoot-cat-card">
        <div class="troubleshoot-cat-header">
          <div class="troubleshoot-cat-title">${escapeTroubleshootHtml(catName)}</div>
          <span style="font-size: 0.75rem; color: var(--text-dim);">${catTools.length} Tools</span>
        </div>
        <div class="troubleshoot-tools-grid">
          ${catTools.map(tool => `
            <div class="repair-tool-card" id="repair-card-${tool.id}">
              <div>
                <div class="repair-tool-header">
                  <div class="repair-tool-icon">${tool.icon || '🛠️'}</div>
                  <div class="repair-tool-info">
                    <div class="repair-tool-name">${escapeTroubleshootHtml(tool.title)}</div>
                    <span class="repair-tool-cmd">${escapeTroubleshootHtml(tool.cmd_desc || '')}</span>
                  </div>
                </div>
                <div class="repair-tool-desc">${escapeTroubleshootHtml(tool.description)}</div>
              </div>
              <div class="repair-tool-footer">
                <span class="repair-status-pill idle" id="repair-status-${tool.id}">Ready</span>
                <button class="repair-run-btn" id="repair-btn-${tool.id}" onclick="runTroubleshootTool('${tool.id}', ${tool.is_long ? 'true' : 'false'})">
                  <span>${tool.is_long ? '🛡️ Run Deep Repair' : '⚡ Repair'}</span>
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  container.innerHTML = html;
}

window.runTroubleshootTool = async function(toolId, isLong = false) {
  const card = document.getElementById(`repair-card-${toolId}`);
  const btn = document.getElementById(`repair-btn-${toolId}`);
  const statusPill = document.getElementById(`repair-status-${toolId}`);
  const globalStatus = document.getElementById('troubleshoot-global-status');

  if (isLong) {
    if (!confirm('This deep repair will scan Windows protected system files and components. It may take several minutes. Proceed?')) {
      return;
    }
  }

  if (btn) btn.disabled = true;
  if (statusPill) {
    statusPill.className = 'repair-status-pill running';
    statusPill.textContent = 'Running...';
  }
  if (card) card.classList.add('running');
  if (globalStatus) {
    globalStatus.textContent = '⏳ Repair in Progress...';
    globalStatus.style.color = 'var(--accent-cyan)';
  }

  try {
    const res = await fetch('/api/troubleshoot/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tool_id: toolId })
    });
    const data = await res.json();

    if (data.status === 'busy') {
      alert(data.error || 'Another repair task is already running!');
      if (statusPill) {
        statusPill.className = 'repair-status-pill idle';
        statusPill.textContent = 'Busy';
      }
      if (btn) btn.disabled = false;
      if (card) card.classList.remove('running');
      return;
    }

    if (data.status === 'running' || data.async) {
      // Async long-running task (SFC / DISM)
      showTroubleshootBanner({ tool_id: toolId, progress: 0, logs: ['Repair process initiated...'] });
      startTroubleshootPolling(toolId);
    } else {
      // Sync tool completed
      if (card) card.classList.remove('running');
      if (data.success) {
        if (card) {
          card.classList.add('success-flash');
          setTimeout(() => card.classList.remove('success-flash'), 4000);
        }
        if (statusPill) {
          statusPill.className = 'repair-status-pill success';
          statusPill.textContent = '✓ Success';
        }
        if (globalStatus) {
          globalStatus.textContent = '✓ Repair Completed';
          globalStatus.style.color = 'var(--accent-green)';
        }
      } else {
        if (card) {
          card.classList.add('error-flash');
          setTimeout(() => card.classList.remove('error-flash'), 4000);
        }
        if (statusPill) {
          statusPill.className = 'repair-status-pill error';
          statusPill.textContent = '❌ Hata';
        }
        if (globalStatus) {
          globalStatus.textContent = '❌ Repair Error';
          globalStatus.style.color = 'var(--accent-red)';
        }
      }

      setTimeout(() => {
        if (btn) btn.disabled = false;
      }, 2000);
    }
  } catch (e) {
    console.error('Troubleshoot execution error:', e);
    if (card) card.classList.remove('running');
    if (statusPill) {
      statusPill.className = 'repair-status-pill error';
      statusPill.textContent = 'Network Error';
    }
    if (btn) btn.disabled = false;
  }
};

function showTroubleshootBanner(task) {
  const banner = document.getElementById('troubleshoot-async-banner');
  const title = document.getElementById('troubleshoot-task-title');
  const percent = document.getElementById('troubleshoot-task-percent');
  const bar = document.getElementById('troubleshoot-task-bar');
  const logsEl = document.getElementById('troubleshoot-task-logs');

  if (!banner) return;
  banner.style.display = 'block';

  const toolName = task.tool_id === 'sfc_scannow' 
    ? 'SFC /scannow (System File Checker)' 
    : (task.tool_id === 'dism_restorehealth' ? 'DISM RestoreHealth (Component Store Repair)' : 'System Repair');

  if (title) {
    title.textContent = `${toolName} in progress...`;
    title.style.color = '#fff';
  }
  if (percent) percent.textContent = `${task.progress || 0}%`;
  if (bar) {
    bar.style.width = `${task.progress || 0}%`;
    bar.style.background = 'var(--accent-cyan)';
  }

  if (logsEl && task.logs) {
    logsEl.innerHTML = task.logs.map(line => `<div class="terminal-line">${escapeTroubleshootHtml(line)}</div>`).join('');
    logsEl.scrollTop = logsEl.scrollHeight;
  }
}

function startTroubleshootPolling(activeToolId = null) {
  if (troubleshootPollInterval) clearInterval(troubleshootPollInterval);

  troubleshootPollInterval = setInterval(async () => {
    try {
      const res = await fetch('/api/troubleshoot/status');
      if (!res.ok) return;
      const status = await res.json();

      const banner = document.getElementById('troubleshoot-async-banner');
      const title = document.getElementById('troubleshoot-task-title');
      const percent = document.getElementById('troubleshoot-task-percent');
      const bar = document.getElementById('troubleshoot-task-bar');
      const logsEl = document.getElementById('troubleshoot-task-logs');
      const globalStatus = document.getElementById('troubleshoot-global-status');

      if (status.status === 'running') {
        if (banner) banner.style.display = 'block';
        if (percent) percent.textContent = `${status.progress || 0}%`;
        if (bar) bar.style.width = `${status.progress || 0}%`;

        if (logsEl && status.logs) {
          logsEl.innerHTML = status.logs.map(line => `<div class="terminal-line">${escapeTroubleshootHtml(line)}</div>`).join('');
          logsEl.scrollTop = logsEl.scrollHeight;
        }
      } else if (status.status === 'completed' || status.status === 'error') {
        clearInterval(troubleshootPollInterval);
        troubleshootPollInterval = null;

        const isOk = status.status === 'completed';
        if (percent) percent.textContent = isOk ? '100%' : 'Error!';
        if (bar) {
          bar.style.width = '100%';
          bar.style.background = isOk ? 'var(--accent-green)' : 'var(--accent-red)';
        }
        if (title) {
          title.textContent = isOk ? '✓ Deep System Repair Completed Successfully!' : '❌ Deep System Repair Ended with Errors!';
          title.style.color = isOk ? 'var(--accent-green)' : 'var(--accent-red)';
        }

        if (logsEl && status.logs) {
          logsEl.innerHTML = status.logs.map(line => `<div class="terminal-line">${escapeTroubleshootHtml(line)}</div>`).join('');
          logsEl.scrollTop = logsEl.scrollHeight;
        }

        const toolId = status.tool_id || activeToolId;
        if (toolId) {
          const card = document.getElementById(`repair-card-${toolId}`);
          const btn = document.getElementById(`repair-btn-${toolId}`);
          const statusPill = document.getElementById(`repair-status-${toolId}`);

          if (card) {
            card.classList.remove('running');
            card.classList.add(isOk ? 'success-flash' : 'error-flash');
          }
          if (statusPill) {
            statusPill.className = `repair-status-pill ${isOk ? 'success' : 'error'}`;
            statusPill.textContent = isOk ? '✓ Done' : '❌ Error';
          }
          if (btn) btn.disabled = false;
        }

        if (globalStatus) {
          globalStatus.textContent = isOk ? '✓ System Ready' : '⚠️ Repair Notice';
          globalStatus.style.color = isOk ? 'var(--accent-green)' : 'var(--accent-yellow)';
        }
      }
    } catch (e) {
      console.warn('Troubleshoot poll error:', e);
    }
  }, 1000);
}

// ==========================================================================
// INTELLIGENT AUTOMATION RULES ENGINE (FAZ 3)
// ==========================================================================
let rulesEngineData = { enabled: true, rules: [], history: [] };
let rulesPollInterval = null;

async function setupAutomationRules() {
  const masterBtn = document.getElementById('btn-toggle-engine-master');
  const evalNowBtn = document.getElementById('btn-eval-rules-now');
  const clearHistBtn = document.getElementById('btn-clear-rules-history');
  const openModalBtn = document.getElementById('btn-open-create-rule');
  const closeModalBtn = document.getElementById('modal-create-rule-close');
  const cancelModalBtn = document.getElementById('btn-cancel-create-rule');
  const submitRuleBtn = document.getElementById('btn-submit-create-rule');
  const modalOverlay = document.getElementById('modal-create-rule');
  const triggerTypeSelect = document.getElementById('new-rule-trigger-type');
  const actionTypeSelect = document.getElementById('new-rule-action-type');

  if (masterBtn) {
    masterBtn.addEventListener('click', toggleEngineMaster);
  }

  if (evalNowBtn) {
    evalNowBtn.addEventListener('click', async () => {
      evalNowBtn.textContent = '⏳ Kontrol Ediliyor...';
      try {
        await fetch('/api/rules/evaluate', { method: 'POST' });
        await loadAutomationRules();
      } finally {
        setTimeout(() => { evalNowBtn.textContent = '⚡ Evaluate Now'; }, 1000);
      }
    });
  }

  if (clearHistBtn) {
    clearHistBtn.addEventListener('click', async () => {
      try {
        await fetch('/api/rules/clear_history', { method: 'POST' });
        await loadAutomationRules();
      } catch (e) {
        console.error(e);
      }
    });
  }

  // Modal openers and closers
  if (openModalBtn && modalOverlay) {
    openModalBtn.addEventListener('click', () => {
      modalOverlay.classList.remove('hidden');
    });
  }

  const closeModal = () => {
    if (modalOverlay) modalOverlay.classList.add('hidden');
  };

  if (closeModalBtn) closeModalBtn.addEventListener('click', closeModal);
  if (cancelModalBtn) cancelModalBtn.addEventListener('click', closeModal);

  // Dynamic Trigger Options
  if (triggerTypeSelect) {
    triggerTypeSelect.addEventListener('change', () => {
      const val = triggerTypeSelect.value;
      const label = document.getElementById('new-rule-param-label');
      const input = document.getElementById('new-rule-trigger-val');
      if (!label || !input) return;

      if (val === 'gpu_temp_gte') {
        label.textContent = 'Threshold Value (°C):';
        input.value = '80';
        input.placeholder = '80';
      } else if (val === 'cpu_load_gte') {
        label.textContent = 'CPU Load Threshold (%):';
        input.value = '85';
        input.placeholder = '85';
      } else if (val === 'battery_lte') {
        label.textContent = 'Battery Level Threshold (%):';
        input.value = '25';
        input.placeholder = '25';
      } else if (val === 'foreground_game') {
        label.textContent = 'Target Application Exe Name:';
        input.value = 'Cyberpunk2077.exe';
        input.placeholder = 'e.g. App.exe or comma-separated list';
      } else if (val === 'time_range') {
        label.textContent = 'Time Window (Start-End):';
        input.value = '23-08';
        input.placeholder = '23-08';
      }
    });
  }

  // Dynamic Action Options
  if (actionTypeSelect) {
    actionTypeSelect.addEventListener('change', () => {
      const actVal = actionTypeSelect.value;
      const actionParamSelect = document.getElementById('new-rule-action-val');
      if (!actionParamSelect) return;

      if (actVal === 'set_fan_profile') {
        actionParamSelect.innerHTML = `
          <option value="turbo">Fan: Turbo (High Performance)</option>
          <option value="cooler_boost">Fan: Cooler Boost (Maksimum %100)</option>
          <option value="silent">Fan: Silent (Low Noise)</option>
          <option value="auto">Fan: Otomatik (Dengeli)</option>
        `;
      } else if (actVal === 'set_power_plan') {
        actionParamSelect.innerHTML = `
          <option value="high_performance">High Performance Plan</option>
          <option value="balanced">Balanced Power Plan</option>
          <option value="power_saver">Power Saver Plan</option>
        `;
      } else if (actVal === 'set_winkey') {
        actionParamSelect.innerHTML = `
          <option value="locked">Lock Windows Key</option>
          <option value="unlocked">Unlock Windows Key</option>
        `;
      } else if (actVal === 'notify') {
        actionParamSelect.innerHTML = `
          <option value="custom_msg">Send Desktop Notification</option>
        `;
      }
    });
  }

  // Submit New Rule
  if (submitRuleBtn) {
    submitRuleBtn.addEventListener('click', async () => {
      const name = (document.getElementById('new-rule-name')?.value || '').trim();
      const triggerType = document.getElementById('new-rule-trigger-type')?.value;
      const triggerVal = (document.getElementById('new-rule-trigger-val')?.value || '').trim();
      const actionType = document.getElementById('new-rule-action-type')?.value;
      const actionVal = document.getElementById('new-rule-action-val')?.value;
      const autoRevert = document.getElementById('new-rule-auto-revert')?.checked ?? true;

      if (!name) {
        alert('Please specify a name for the rule.');
        return;
      }

      let triggerObj = { type: triggerType };
      if (triggerType === 'gpu_temp_gte' || triggerType === 'cpu_load_gte' || triggerType === 'battery_lte') {
        triggerObj.threshold = parseInt(triggerVal) || 80;
      } else if (triggerType === 'foreground_game') {
        triggerObj.process_list = triggerVal.split(',').map(s => s.trim()).filter(Boolean);
      } else if (triggerType === 'time_range') {
        const parts = triggerVal.split('-');
        triggerObj.start_hour = parseInt(parts[0]) || 23;
        triggerObj.end_hour = parseInt(parts[1]) || 8;
      }

      const ruleObj = {
        name,
        description: `Custom Rule (${triggerType} ➔ ${actionType})`,
        icon: '⚡',
        enabled: true,
        auto_revert: autoRevert,
        cooldown_sec: 10,
        trigger: triggerObj,
        actions: [{ type: actionType, param: actionVal, label: `${actionType}: ${actionVal}` }]
      };

      try {
        submitRuleBtn.disabled = true;
        const res = await fetch('/api/rules/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ rule: ruleObj })
        });
        if (res.ok) {
          closeModal();
          document.getElementById('new-rule-name').value = '';
          await loadAutomationRules();
        }
      } catch (e) {
        alert('Kural kaydedilemedi: ' + e.message);
      } finally {
        submitRuleBtn.disabled = false;
      }
    });
  }
}

async function loadAutomationRules() {
  const container = document.getElementById('rules-list-container');
  const activeCountEl = document.getElementById('rules-active-count');
  const lastEventChip = document.getElementById('rules-last-event-chip');
  const masterText = document.getElementById('engine-master-status-text');
  const masterBtn = document.getElementById('btn-toggle-engine-master');
  const historyLog = document.getElementById('rules-history-log');

  try {
    const res = await fetch('/api/rules');
    if (!res.ok) throw new Error('API request failed: ' + res.status);
    rulesEngineData = await res.json();

    // 1. Update Master Toggle Button & Stats
    const isMasterOn = rulesEngineData.enabled;
    if (masterText) {
      masterText.textContent = isMasterOn ? '⚡ Engine: Active' : '⏸️ Engine: Paused';
    }
    if (masterBtn) {
      if (isMasterOn) {
        masterBtn.className = 'btn btn-primary';
      } else {
        masterBtn.className = 'btn btn-secondary';
        masterBtn.style.background = 'rgba(239, 68, 68, 0.15)';
        masterBtn.style.borderColor = 'var(--accent-red)';
      }
    }

    if (activeCountEl) {
      activeCountEl.textContent = `${rulesEngineData.active_rules_count || 0} / ${rulesEngineData.total_rules_count || 0}`;
    }

    // 2. Render Rules List
    renderAutomationRules(rulesEngineData.rules || []);

    // 3. Render Activity Logs
    if (historyLog) {
      const history = rulesEngineData.history || [];
      if (history.length === 0) {
        historyLog.innerHTML = '<div class="terminal-line text-dim">No automation events triggered yet...</div>';
      } else {
        historyLog.innerHTML = history.map(item => {
          const color = item.event_type === 'trigger' ? 'var(--accent-green)' : (item.event_type === 'revert' ? 'var(--accent-cyan)' : 'var(--accent-red)');
          const icon = item.event_type === 'trigger' ? '🚀' : '↩️';
          return `<div class="terminal-line">
            <span style="color: var(--text-dim);">[${item.time_str || ''}]</span>
            <strong style="color: ${color}; margin: 0 4px;">${icon} [${escapeTroubleshootHtml(item.rule_name)}]</strong>
            <span style="color: #d1d5db;">${escapeTroubleshootHtml(item.message)}</span>
          </div>`;
        }).join('');
      }

      if (lastEventChip && history.length > 0) {
        const latest = history[0];
        lastEventChip.textContent = `${latest.rule_name} (${latest.time_str})`;
        lastEventChip.style.color = latest.event_type === 'trigger' ? 'var(--accent-green)' : 'var(--accent-cyan)';
      }
    }

    // Start auto polling if on rules tab
    if (!rulesPollInterval) {
      rulesPollInterval = setInterval(async () => {
        const rulesPane = document.getElementById('tab-rules');
        if (rulesPane && rulesPane.classList.contains('active')) {
          await loadAutomationRules();
        }
      }, 3500);
    }
  } catch (e) {
    console.error('Error loading automation rules:', e);
    if (container) {
      container.innerHTML = `<div style="padding: 20px; text-align: center; color: var(--accent-red);">Failed to load rules: ${escapeTroubleshootHtml(e.message)}</div>`;
    }
  }
}

function renderAutomationRules(rules) {
  const container = document.getElementById('rules-list-container');
  if (!container) return;

  if (rules.length === 0) {
    container.innerHTML = '<div style="padding: 20px; text-align: center; color: var(--text-dim);">No automation rules defined.</div>';
    return;
  }

  container.innerHTML = rules.map(rule => {
    const isFiring = rule.state && rule.state.is_active;
    const triggerLabel = formatRuleTriggerText(rule.trigger);
    const actionsLabel = (rule.actions || []).map(a => a.label || a.type).join(' • ');

    return `
      <div class="rule-item-card ${isFiring ? 'is-firing' : ''}" id="rule-card-${rule.id}">
        <div class="rule-item-left">
          <div class="rule-icon-box">${rule.icon || '⚡'}</div>
          <div class="rule-details">
            <div class="rule-header-row">
              <span class="rule-title">${escapeTroubleshootHtml(rule.name)}</span>
              ${isFiring ? '<span class="repair-status-pill running">🔥 Triggered / Active</span>' : (rule.enabled ? '<span class="repair-status-pill success">Watching</span>' : '<span class="repair-status-pill idle">Disabled</span>')}
              ${rule.is_preset ? '<span class="tag-pill blue" style="font-size: 0.65rem;">Preset</span>' : '<span class="tag-pill purple" style="font-size: 0.65rem;">Custom Rule</span>'}
            </div>
            <div class="rule-desc">${escapeTroubleshootHtml(rule.description || '')}</div>
            <div class="rule-logic-flow">
              <span class="rule-flow-pill trigger">IF: ${escapeTroubleshootHtml(triggerLabel)}</span>
              <span class="rule-flow-arrow">➔</span>
              <span class="rule-flow-pill action">THEN: ${escapeTroubleshootHtml(actionsLabel)}</span>
              ${rule.auto_revert ? '<span style="font-size: 0.7rem; color: var(--text-dim); margin-left: 6px;">(Auto-Revert ✓)</span>' : ''}
            </div>
          </div>
        </div>
        <div class="rule-item-right">
          <label class="zenith-toggle" title="${rule.enabled ? 'Disable Rule' : 'Enable Rule'}">
            <input type="checkbox" ${rule.enabled ? 'checked' : ''} onchange="toggleRuleState('${rule.id}', this.checked)">
            <span class="zenith-toggle-slider"></span>
          </label>
          ${!rule.is_preset ? `
            <button class="rule-delete-btn" onclick="deleteCustomRule('${rule.id}')" title="Delete Rule">Delete</button>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

function formatRuleTriggerText(trigger) {
  if (!trigger) return 'No Condition';
  const t = trigger.type;
  if (t === 'foreground_game') {
    const procs = trigger.process_list || [];
    return procs.length > 3 ? `Game / 3D App (${procs.length} Apps)` : procs.join(', ');
  }
  if (t === 'gpu_temp_gte') return `GPU ≥ ${trigger.threshold}°C (Cooldown: ${trigger.hysteresis || trigger.threshold - 6}°C)`;
  if (t === 'cpu_load_gte') return `CPU Load ≥ %${trigger.threshold}`;
  if (t === 'battery_lte') return `Battery ≤ ${trigger.threshold}% (${trigger.require_discharging ? 'On Battery' : ''})`;
  if (t === 'time_range') return `Hours ${trigger.start_hour}:00 - ${trigger.end_hour}:00`;
  return t;
}

window.toggleRuleState = async function(ruleId, enabled) {
  try {
    await fetch('/api/rules/toggle_rule', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rule_id: ruleId, enabled: enabled })
    });
    await loadAutomationRules();
  } catch (e) {
    console.error('Error toggling rule:', e);
  }
};

window.toggleEngineMaster = async function() {
  const current = rulesEngineData.enabled;
  try {
    await fetch('/api/rules/toggle_master', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled: !current })
    });
    await loadAutomationRules();
  } catch (e) {
    console.error('Error toggling master engine:', e);
  }
};

window.deleteCustomRule = async function(ruleId) {
  if (!confirm('Are you sure you want to delete this rule?')) return;
  try {
    await fetch('/api/rules/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rule_id: ruleId })
    });
    await loadAutomationRules();
  } catch (e) {
    console.error('Error deleting rule:', e);
  }
};

// ==========================================================================
// HARDWARE DIAGNOSTICS & PC OBD-II ENGINE (FAZ 4)
// ==========================================================================
let obdCurrentReport = null;

async function setupHardwareObd() {
  const scanBtn = document.getElementById('btn-obd-scan-now');
  const clearBtn = document.getElementById('btn-obd-clear-dtc');
  const exportBtn = document.getElementById('btn-obd-export');

  if (scanBtn) {
    scanBtn.addEventListener('click', async () => {
      scanBtn.disabled = true;
      scanBtn.textContent = '⏳ Deep Hardware Scan in Progress...';
      try {
        await runHardwareObdScan();
      } finally {
        scanBtn.disabled = false;
        scanBtn.textContent = '⚡ Run Deep Check-Up';
      }
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener('click', async () => {
      if (!confirm('Do you want to reset all active diagnostic trouble codes (DTC)?')) return;
      try {
        await fetch('/api/obd/clear_dtc', { method: 'POST' });
        await loadHardwareObdReport(false);
      } catch (e) {
        console.error('Clear DTC error:', e);
      }
    });
  }

  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      if (!obdCurrentReport) return;
      const rep = obdCurrentReport;
      const subs = rep.subsystems || {};
      const lines = [
        `# 🚗 ZENITH PC OBD-II HARDWARE DIAGNOSTIC REPORT`,
        `- **Scan Date:** ${rep.scan_time_str || 'Just now'}`,
        `- **Hardware Health Score:** ${rep.overall_score} / 100`,
        `- **Check Lamp (MIL):** ${rep.mil_status === 'OFF' ? 'NORMAL (Clean / 0 Faults)' : rep.mil_status}`,
        `- **Summary:** ${rep.summary || 'Pristine'}`,
        ``,
        `### 🔬 Subsystem Diagnostics`,
        `- **WHEA Stability:** ${subs.whea?.status?.toUpperCase()} (${subs.whea?.score}/100) — ${subs.whea?.details}`,
        `- **Cable & Port Stability:** ${subs.port_stability?.status?.toUpperCase()} (${subs.port_stability?.score}/100) — ${subs.port_stability?.details}`,
        `- **PCIe Veri Yolu (GPU):** ${subs.pcie_bus?.status?.toUpperCase()} (${subs.pcie_bus?.score}/100) — ${subs.pcie_bus?.details}`,
        `- **Storage Bus Integrity:** ${subs.storage_interface?.status?.toUpperCase()} (${subs.storage_interface?.score}/100) — ${subs.storage_interface?.details}`,
        `- **Power Rails & Voltages:** ${subs.power_rails?.status?.toUpperCase()} (${subs.power_rails?.score}/100) — ${subs.power_rails?.details}`,
        ``,
        `### ⚠️ Trouble Codes (DTC - ${rep.dtc_codes?.length || 0} Total)`,
        ...(rep.dtc_codes && rep.dtc_codes.length > 0 
          ? rep.dtc_codes.map(c => `- [${c.code}] ${c.subsystem}: ${c.description} -> Solution: ${c.recommendation}`)
          : ['- No active trouble codes (DTC) detected. All hardware lines clean.'])
      ];

      navigator.clipboard.writeText(lines.join('\n')).then(() => {
        exportBtn.textContent = '✓ Copied to Clipboard!';
        setTimeout(() => { exportBtn.textContent = '📋 Rapor Al'; }, 2000);
      });
    });
  }

  const obdHtmlBtn = document.getElementById('btn-obd-download-html');
  if (obdHtmlBtn) {
    obdHtmlBtn.addEventListener('click', () => {
      window.open('/api/report/html', '_blank');
    });
  }
}

async function loadHardwareObdReport(force = false) {
  const grid = document.getElementById('obd-subsystems-grid');
  const dtcBox = document.getElementById('obd-dtc-container');
  const dtcBadge = document.getElementById('obd-dtc-count-badge');
  const scoreVal = document.getElementById('obd-score-val');
  const scanTimeLabel = document.getElementById('obd-scan-time-label');
  const milLamp = document.getElementById('obd-mil-lamp');
  const summaryText = document.getElementById('obd-summary-text');

  try {
    const url = force ? '/api/obd/scan' : '/api/obd/report';
    const method = force ? 'POST' : 'GET';
    const res = await fetch(url, { method });
    if (!res.ok) throw new Error('API request failed: ' + res.status);
    obdCurrentReport = await res.json();
    const rep = obdCurrentReport;

    // 1. Score & MIL
    if (scoreVal) {
      scoreVal.textContent = rep.overall_score ?? 100;
      scoreVal.className = 'obd-gauge-val ' + (rep.overall_score >= 90 ? 'green' : (rep.overall_score >= 70 ? 'yellow' : 'red'));
    }
    if (scanTimeLabel) {
      scanTimeLabel.textContent = `Last Scan: ${rep.scan_time_str || 'Just now'}`;
    }

    if (milLamp) {
      const mil = rep.mil_status || 'OFF';
      milLamp.className = `obd-mil-lamp ${mil.toLowerCase()}`;
      if (mil === 'OFF') {
        milLamp.innerHTML = '✓ MIL: NORMAL (CLEAN)';
      } else if (mil === 'PENDING') {
        milLamp.innerHTML = '⚠️ MIL: WARNING / FLAPPING';
      } else {
        milLamp.innerHTML = '🚨 CHECK ENGINE (ARIZA)';
      }
    }

    if (summaryText) {
      summaryText.textContent = rep.summary || 'All hardware buses and links are healthy.';
    }

    // 2. Subsystems Grid
    if (grid && rep.subsystems) {
      const subs = rep.subsystems;
      const subKeys = Object.keys(subs);
      grid.innerHTML = subKeys.map(k => {
        const item = subs[k];
        const sc = item.score ?? 100;
        const color = sc >= 90 ? 'var(--accent-green)' : (sc >= 70 ? '#f59e0b' : 'var(--accent-red)');
        const statusBadge = item.status === 'clean' || item.status === 'optimal' || item.status === 'stable'
          ? '<span class="repair-status-pill success">Pristine</span>'
          : '<span class="repair-status-pill error">Dikkat</span>';

        return `
          <div class="obd-subsystem-card">
            <div>
              <div class="obd-subsystem-header">
                <div class="obd-subsystem-title-group">
                  <span class="obd-subsystem-icon">${item.icon || '🔬'}</span>
                  <span class="obd-subsystem-title">${escapeTroubleshootHtml(item.title)}</span>
                </div>
                ${statusBadge}
              </div>
              <div class="obd-subsystem-details">${escapeTroubleshootHtml(item.details)}</div>
            </div>
            <div>
              <div style="display: flex; justify-content: space-between; font-size: 0.72rem; color: var(--text-dim); margin-bottom: 4px;">
                <span>Hardware Health</span>
                <strong style="color: ${color};">${sc}%</strong>
              </div>
              <div class="obd-subsystem-bar-wrapper">
                <div class="obd-subsystem-bar-fill" style="width: ${sc}%; background: ${color};"></div>
              </div>
            </div>
          </div>
        `;
      }).join('');
    }

    // 3. DTC Codes Table
    if (dtcBox) {
      const dtcs = rep.dtc_codes || [];
      if (dtcBadge) {
        dtcBadge.textContent = `${dtcs.length} Trouble Code(s)`;
        dtcBadge.className = `tag-pill ${dtcs.length === 0 ? 'green' : 'red'}`;
      }

      if (dtcs.length === 0) {
        dtcBox.innerHTML = `
          <div style="padding: 30px; text-align: center; color: var(--accent-green);">
            <div style="font-size: 2rem; margin-bottom: 8px;">✨</div>
            <strong style="font-size: 0.95rem;">Congratulations, no hardware diagnostic trouble codes (DTC) detected!</strong>
            <p style="font-size: 0.8rem; color: var(--text-dim); margin-top: 4px;">All sockets, PCIe lanes, and voltage rails are operating within nominal tolerances.</p>
          </div>
        `;
      } else {
        dtcBox.innerHTML = dtcs.map(dtc => `
          <div class="obd-dtc-item">
            <span class="obd-dtc-code-badge">${escapeTroubleshootHtml(dtc.code)}</span>
            <div class="obd-dtc-info">
              <div class="obd-dtc-desc">${escapeTroubleshootHtml(dtc.description)}</div>
              <div class="obd-dtc-recom">💡 <strong>Recommended Action:</strong> ${escapeTroubleshootHtml(dtc.recommendation)}</div>
            </div>
          </div>
        `).join('');
      }
    }
  } catch (e) {
    console.error('Error loading OBD report:', e);
    if (grid) {
      grid.innerHTML = `<div style="padding: 20px; color: var(--accent-red); grid-column: 1 / -1;">Failed to load OBD-II report: ${escapeTroubleshootHtml(e.message)}</div>`;
    }
  }
}

async function runHardwareObdScan() {
  await loadHardwareObdReport(true);
}

// --- HEARTBEAT & WATCHDOG ---
function setupHeartbeatAndExitHandler() {
  const sendHeartbeat = async () => {
    try {
      await fetch('/api/heartbeat', { cache: 'no-store' });
    } catch (e) {
      // Backend may be shutting down
    }
  };

  // Send heartbeat every 4 seconds to keep Python backend alive
  setInterval(sendHeartbeat, 4000);

  // Immediately wake up and send heartbeat when tab regains focus or visibility
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
      sendHeartbeat();
    }
  });
  window.addEventListener('focus', () => {
    sendHeartbeat();
  });
}

