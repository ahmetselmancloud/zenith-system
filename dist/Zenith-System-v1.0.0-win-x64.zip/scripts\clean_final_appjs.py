import re

with open('web/app.js', 'r', encoding='utf-8') as f:
    text = f.read()

replacements = [
    ('Katalog yüklenemedi:', 'Failed to load catalog:'),
    ('[Zenith WinGet] Arka plan kurulum işi başlatıldı...', '[Zenith WinGet] Background installation initiated...'),
    ("installBtn.textContent = 'Kuruluyor...';", "installBtn.textContent = 'Installing...';"),
    ("Birkaç dakika sürebilir. Başlatmak istiyor musunuz?", "It may take several minutes. Proceed?"),
    ("percent.textContent = isOk ? '100%' : 'Hata!';", "percent.textContent = isOk ? '100%' : 'Error!';"),
    ("title.textContent = isOk ? '✓ Deep System Repair Completed Successfully!' : '❌ Derin System Repair Hatayla Latestlandı!';", "title.textContent = isOk ? '✓ Deep System Repair Completed Successfully!' : '❌ Deep System Repair Ended with Errors!';"),
    ('Kurallar yüklenemedi:', 'Failed to load rules:'),
    ('All sockets, PCIe lanes, and voltaj rayları nominal toleranslar içinde çalışıyor.', 'All sockets, PCIe lanes, and voltage rails are operating within nominal tolerances.')
]

for src, dst in replacements:
    text = text.replace(src, dst)

with open('web/app.js', 'w', encoding='utf-8') as f:
    f.write(text)

remaining = len(re.findall(r'[çÇğĞıİöÖşŞüÜ]', text))
print(f"app.js fully cleaned. Remaining Turkish characters: {remaining}")
