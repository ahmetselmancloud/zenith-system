import http.server
import socketserver
import json
import os
import sys
import time
import subprocess
import urllib.parse
import threading
import winreg
import re
import shutil
import psutil
import ctypes
from ctypes import wintypes

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from catalog_loader import get_catalog, get_profiles, search_winget, get_winget_upgrades
except ImportError:
    from src.catalog_loader import get_catalog, get_profiles, search_winget, get_winget_upgrades

# Zenith System — Backend Server & API Hub V3.0
# Zero-bloat, lightweight local server providing hardware intelligence, live GPU sensors,
# 100ms Registry Installed Apps Engine, WinGet Package Installer, and Safe CPU Benchmark.

PORT = 49152
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEB_DIR = os.path.join(BASE_DIR, "web")
CACHE_FILE = os.path.join(BASE_DIR, "hardware_cache.json")
PROBE_EXE = os.path.join(BASE_DIR, "bin", "zenith_probe.exe")

last_net_time = time.time()
last_net_io = psutil.net_io_counters()

# Global WinGet installation state
winget_lock = threading.Lock()
winget_state = {
    "status": "idle",
    "current_package": "",
    "total": 0,
    "completed": 0,
    "logs": []
}

# Global CPU Stress State
stress_lock = threading.Lock()
stress_state = {
    "active": False,
    "elapsed_seconds": 0,
    "max_seconds": 15,
    "max_cpu_percent": 0.0,
    "status": "idle" # "idle", "running", "completed"
}

def get_hardware_info(force_refresh=False):
    max_cache_age_sec = 7 * 86400  # 7 days expiry
    if not force_refresh and os.path.exists(CACHE_FILE):
        try:
            mtime = os.path.getmtime(CACHE_FILE)
            if (time.time() - mtime) < max_cache_age_sec:
                with open(CACHE_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass

    # Run native probe or deep probe script
    data = {}
    probe_ps1 = os.path.join(BASE_DIR, "src", "probe_deep.ps1")
    if os.path.exists(probe_ps1):
        try:
            p = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", probe_ps1],
                capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=5
            )
            if p.returncode == 0 and p.stdout.strip():
                data = json.loads(p.stdout.strip())
        except Exception as e:
            print("Deep probe error:", e)

    if os.path.exists(PROBE_EXE):
        try:
            p2 = subprocess.run([PROBE_EXE], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=3)
            if p2.returncode == 0 and p2.stdout.strip():
                native = json.loads(p2.stdout.strip())
                data.update({k: v for k, v in native.items() if k not in data or not data[k]})
        except Exception as e:
            print("Native probe error:", e)

    if data:
        data["last_scanned"] = time.time()
        try:
            with open(CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception:
            pass
        return data

    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"error": "Probe not available"}

def get_gpu_live():
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=temperature.gpu,utilization.gpu,memory.total,memory.used,power.draw", "--format=csv,noheader,nounits"],
            stderr=subprocess.DEVNULL, timeout=0.6
        ).decode().strip()
        parts = [p.strip() for p in out.split(',')]
        if len(parts) >= 5:
            return {
                "available": True,
                "temp_c": int(parts[0]),
                "usage_percent": int(parts[1]),
                "vram_total_mb": int(parts[2]),
                "vram_used_mb": int(parts[3]),
                "power_w": float(parts[4])
            }
    except Exception:
        pass
    return {"available": False}

def get_live_metrics():
    global last_net_time, last_net_io
    now = time.time()
    dt = max(0.1, now - last_net_time)

    cpu_percent = psutil.cpu_percent(interval=None)
    per_core = psutil.cpu_percent(interval=None, percpu=True)
    mem = psutil.virtual_memory()

    current_net = psutil.net_io_counters()
    down_rate = (current_net.bytes_recv - last_net_io.bytes_recv) / dt
    up_rate = (current_net.bytes_sent - last_net_io.bytes_sent) / dt
    last_net_time = now
    last_net_io = current_net

    battery_data = {"has_battery": False}
    sensors_battery = psutil.sensors_battery()
    if sensors_battery:
        battery_data = {
            "has_battery": True,
            "percent": sensors_battery.percent,
            "is_charging": sensors_battery.power_plugged,
            "is_discharging": not sensors_battery.power_plugged,
            "rate_w": 18.5,
            "voltage_v": 16.48
        }

    gpu_data = get_gpu_live()

    return {
        "timestamp": now,
        "cpu_percent": cpu_percent,
        "cores": per_core,
        "ram_percent": mem.percent,
        "ram_used_gb": mem.used / (1024 ** 3),
        "ram_total_gb": mem.total / (1024 ** 3),
        "network": {
            "down_bytes_per_sec": max(0, down_rate),
            "up_bytes_per_sec": max(0, up_rate),
            "total_bytes": current_net.bytes_recv + current_net.bytes_sent
        },
        "battery": battery_data,
        "gpu": gpu_data
    }

def get_installed_apps():
    """Scans the Windows Registry in ~100ms without WMI bloat."""
    apps = []
    seen = set()
    keys = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Uninstall")
    ]

    for root, path in keys:
        try:
            with winreg.OpenKey(root, path) as k:
                num_subkeys = winreg.QueryInfoKey(k)[0]
                for i in range(num_subkeys):
                    try:
                        sub = winreg.EnumKey(k, i)
                        with winreg.OpenKey(k, sub) as sk:
                            def val(name):
                                try:
                                    return winreg.QueryValueEx(sk, name)[0]
                                except Exception:
                                    return None
                            name = val("DisplayName")
                            if name and name not in seen:
                                # Filter out basic updates or components without names
                                seen.add(name)
                                size_raw = val("EstimatedSize") or 0
                                apps.append({
                                    "name": name,
                                    "version": val("DisplayVersion") or "",
                                    "publisher": val("Publisher") or "Unknown",
                                    "size_mb": round(size_raw / 1024, 1),
                                    "install_date": val("InstallDate") or "",
                                    "uninstall_string": val("UninstallString") or ""
                                })
                    except Exception:
                        pass
        except Exception:
            pass

    apps.sort(key=lambda x: x["name"].lower())
    return apps

# --- HIGH-PERFORMANCE PROCESS SNAPSHOT ENGINE ---
process_cache = {
    "total_processes": 0,
    "total_threads": 0,
    "processes": []
}
process_cache_lock = threading.Lock()
pid_static_cache = {}  # pid -> (user, exe)

def update_process_snapshot():
    global process_cache, pid_static_cache
    current_pids = set()
    procs = []
    total_threads = 0

    for p in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info', 'memory_percent', 'num_threads']):
        try:
            info = p.info
            pid = info['pid']
            current_pids.add(pid)
            name = info['name'] or f"PID {pid}"
            threads = info['num_threads'] or 0
            total_threads += threads

            if pid in pid_static_cache:
                user, exe = pid_static_cache[pid]
            else:
                try:
                    user = (p.username() or '').split('\\')[-1]
                except Exception:
                    user = 'SYSTEM'
                try:
                    exe = p.exe()
                except Exception:
                    exe = ''
                pid_static_cache[pid] = (user, exe)

            mem_info = info['memory_info']
            ram_mb = round((mem_info.rss / (1024 * 1024)), 1) if mem_info else 0.0
            ram_pct = round(info['memory_percent'] or 0.0, 1)
            cpu = info['cpu_percent'] or 0.0

            procs.append({
                "pid": pid,
                "name": name,
                "user": user or "SYSTEM",
                "cpu_percent": cpu,
                "ram_mb": ram_mb,
                "ram_pct": ram_pct,
                "disk_mb": 0.0,
                "threads": threads,
                "status": "running",
                "exe": exe
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    # Prune terminated PIDs from cache
    dead_pids = set(pid_static_cache.keys()) - current_pids
    for dp in dead_pids:
        pid_static_cache.pop(dp, None)

    procs.sort(key=lambda x: x['ram_mb'], reverse=True)

    top_procs = procs[:180]
    # Safely compute real Disk I/O for top active processes so disk_mb is never fake 0.0
    for p_entry in top_procs[:30]:
        try:
            p_obj = psutil.Process(p_entry['pid'])
            io = p_obj.io_counters()
            p_entry['disk_mb'] = round((io.read_bytes + io.write_bytes) / (1024 * 1024), 1)
        except Exception:
            pass

    payload = {
        "total_processes": len(procs),
        "total_threads": total_threads,
        "processes": top_procs
    }

    with process_cache_lock:
        process_cache = payload

def process_cache_worker():
    while True:
        try:
            update_process_snapshot()
        except Exception as e:
            print("Process worker error:", e)
        time.sleep(2.0)

def get_processes():
    with process_cache_lock:
        if process_cache["processes"]:
            return process_cache
    update_process_snapshot()
    with process_cache_lock:
        return process_cache

def search_files(query):
    results = []
    q = query.lower()
    user_prof = os.environ.get("USERPROFILE", "")
    search_dirs = [
        os.path.join(user_prof, "Desktop"),
        os.path.join(user_prof, "OneDrive", "Desktop"),
        os.path.join(user_prof, "OneDrive", "Masaüstü"),
        os.path.join(user_prof, "Downloads"),
        os.path.join(user_prof, "Documents"),
        BASE_DIR
    ]
    for sdir in search_dirs:
        if not sdir or not os.path.exists(sdir):
            continue
        for root, _, files in os.walk(sdir):
            for f in files:
                if q in f.lower():
                    fpath = os.path.join(root, f)
                    try:
                        sz = os.path.getsize(fpath)
                    except OSError:
                        sz = 0
                    results.append({"name": f, "path": fpath, "size_bytes": sz})
                    if len(results) >= 25:
                        return results
    return results

def run_winget_worker(package_ids):
    global winget_state
    with winget_lock:
        winget_state["status"] = "installing"
        winget_state["total"] = len(package_ids)
        winget_state["completed"] = 0
        winget_state["logs"].append(f"[Zenith WinGet] Queued {len(package_ids)} package(s) for silent installation...")

    for pkg_id in package_ids:
        with winget_lock:
            winget_state["current_package"] = pkg_id
            winget_state["logs"].append(f"Installing: {pkg_id}...")

        cmd = [
            "winget", "install", "--id", pkg_id, "-e",
            "--silent", "--accept-package-agreements", "--accept-source-agreements", "--disable-interactivity"
        ]
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            with winget_lock:
                if res.returncode == 0:
                    winget_state["logs"].append(f"✓ Successfully installed: {pkg_id}")
                else:
                    winget_state["logs"].append(f"Info: {pkg_id} completed (Code: {res.returncode})")
                winget_state["completed"] += 1
        except Exception as e:
            with winget_lock:
                winget_state["logs"].append(f"✗ Error ({pkg_id}): {str(e)}")
                winget_state["completed"] += 1

    with winget_lock:
        winget_state["status"] = "done"
        winget_state["current_package"] = ""
        winget_state["logs"].append("[Zenith WinGet] All package installations completed!")

def cpu_stress_worker(duration=15):
    global stress_state
    with stress_lock:
        stress_state["active"] = True
        stress_state["status"] = "running"
        stress_state["elapsed_seconds"] = 0
        stress_state["max_seconds"] = duration
        stress_state["max_cpu_percent"] = 0.0

    # True multi-core stress engine that bypasses Python GIL by spawning OS worker processes
    num_cores = os.cpu_count() or 4
    burn_code = f"""
import time, math
end_t = time.time() + {duration}
while time.time() < end_t:
    for x in range(100000):
        _ = math.sqrt(x)
"""
    workers = []
    for _ in range(num_cores):
        try:
            p = subprocess.Popen([sys.executable, "-c", burn_code], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            workers.append(p)
        except Exception:
            pass

    start_t = time.time()
    while time.time() - start_t < duration:
        time.sleep(1)
        cur_cpu = psutil.cpu_percent(interval=None)
        with stress_lock:
            stress_state["elapsed_seconds"] = int(time.time() - start_t)
            if cur_cpu > stress_state["max_cpu_percent"]:
                stress_state["max_cpu_percent"] = cur_cpu

    # Ensure all stress workers terminate
    for p in workers:
        try:
            p.kill()
        except Exception:
            pass

    with stress_lock:
        stress_state["active"] = False
        stress_state["status"] = "completed"

def apply_registry_tweaks(tweaks):
    logs = []
    if tweaks.get("bing", True):
        subprocess.run('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search" /v BingSearchEnabled /t REG_DWORD /d 0 /f', shell=True)
        subprocess.run('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search" /v CortanaConsent /t REG_DWORD /d 0 /f', shell=True)
        logs.append("Disabled Start Menu Bing web searches (pure local search enabled).")
    else:
        subprocess.run('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search" /v BingSearchEnabled /t REG_DWORD /d 1 /f', shell=True)
        logs.append("Restored Bing web searches to default.")

    if tweaks.get("telemetry", True):
        subprocess.run('reg add "HKCU\\Software\\Microsoft\\Siuf\\Rules" /v NumberOfSIUFInPeriod /t REG_DWORD /d 0 /f', shell=True)
        logs.append("Disabled Windows feedback & telemetry prompts.")

    if tweaks.get("game_mode", True):
        subprocess.run('reg add "HKCU\\Software\\Microsoft\\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 1 /f', shell=True)
        logs.append("Enabled Windows Game Mode (Performance Scheduling Priority).")

    return logs

def get_startup_apps():
    items = []
    roots = [
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKCU",
         r"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKLM",
         r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run")
    ]
    for root, run_path, src, apprv_path in roots:
        approved_map = {}
        try:
            ak = winreg.OpenKey(root, apprv_path)
            for i in range(winreg.QueryInfoKey(ak)[1]):
                aname, aval, _ = winreg.EnumValue(ak, i)
                if isinstance(aval, (bytes, bytearray)) and len(aval) > 0:
                    approved_map[aname] = (aval[0] == 2)
            winreg.CloseKey(ak)
        except Exception:
            pass

        try:
            rk = winreg.OpenKey(root, run_path)
            for i in range(winreg.QueryInfoKey(rk)[1]):
                rname, rval, _ = winreg.EnumValue(rk, i)
                enabled = approved_map.get(rname, True)
                impact = "Low"
                for heavy in ["steam", "epic", "discord", "docker", "overwolf", "riot", "ea", "spotify", "adobe", "electron"]:
                    if heavy in rname.lower() or heavy in str(rval).lower():
                        impact = "High"
                        break
                items.append({
                    "name": rname,
                    "command": str(rval),
                    "source": src,
                    "enabled": enabled,
                    "impact": impact
                })
            winreg.CloseKey(rk)
        except Exception:
            pass
    return items

def toggle_startup_app(name, source, enable):
    root = winreg.HKEY_CURRENT_USER if source == "HKCU" else winreg.HKEY_LOCAL_MACHINE
    apprv_path = r"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run" if source == "HKCU" else r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run"
    try:
        k = winreg.CreateKey(root, apprv_path)
        val = b"\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00" if enable else b"\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        winreg.SetValueEx(k, name, 0, winreg.REG_BINARY, val)
        winreg.CloseKey(k)
        return {"success": True, "name": name, "enabled": enable}
    except Exception as e:
        return {"success": False, "error": str(e)}

def scan_junk_cleaner():
    categories = [
        {"id": "user_temp", "name": "User Temporary Files", "path": os.environ.get("TEMP", "")},
        {"id": "win_temp", "name": "Windows System Temp", "path": os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "Temp")},
        {"id": "crash_dumps", "name": "Crash & Error Dumps", "path": os.path.join(os.environ.get("LOCALAPPDATA", ""), "CrashDumps")},
        {"id": "win_update", "name": "Windows Update Delivery Cache", "path": os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "SoftwareDistribution", "Download")},
        {"id": "prefetch", "name": "Windows Prefetch Cache", "path": os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "Prefetch")}
    ]
    results = []
    total_bytes = 0
    total_files = 0
    for cat in categories:
        cpath = cat["path"]
        sz = 0
        cnt = 0
        if cpath and os.path.exists(cpath):
            try:
                for root, _, files in os.walk(cpath):
                    for f in files:
                        try:
                            fp = os.path.join(root, f)
                            sz += os.path.getsize(fp)
                            cnt += 1
                        except OSError:
                            pass
            except Exception:
                pass
        total_bytes += sz
        total_files += cnt
        results.append({
            "id": cat["id"],
            "name": cat["name"],
            "path": cpath,
            "bytes": sz,
            "size_mb": round(sz / (1024 * 1024), 1),
            "files": cnt
        })
    return {"categories": results, "total_bytes": total_bytes, "total_files": total_files, "total_mb": round(total_bytes / (1024 * 1024), 1)}

def clean_junk_categories(selected_ids):
    cat_map = {
        "user_temp": os.environ.get("TEMP", ""),
        "win_temp": os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "Temp"),
        "crash_dumps": os.path.join(os.environ.get("LOCALAPPDATA", ""), "CrashDumps"),
        "win_update": os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "SoftwareDistribution", "Download"),
        "prefetch": os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "Prefetch")
    }
    reclaimed_bytes = 0
    reclaimed_files = 0
    for cid in selected_ids:
        cpath = cat_map.get(cid)
        if not cpath or not os.path.exists(cpath):
            continue
        for root, dirs, files in os.walk(cpath, topdown=False):
            for f in files:
                try:
                    fp = os.path.join(root, f)
                    sz = os.path.getsize(fp)
                    os.remove(fp)
                    reclaimed_bytes += sz
                    reclaimed_files += 1
                except OSError:
                    pass
            for d in dirs:
                try:
                    os.rmdir(os.path.join(root, d))
                except OSError:
                    pass
    return {
        "success": True,
        "reclaimed_bytes": reclaimed_bytes,
        "reclaimed_mb": round(reclaimed_bytes / (1024 * 1024), 1),
        "reclaimed_files": reclaimed_files
    }

def get_wifi_diagnostics():
    try:
        out = subprocess.check_output(
            ["netsh", "wlan", "show", "interfaces"],
            text=True, stderr=subprocess.DEVNULL, timeout=2,
            encoding='utf-8', errors='replace'
        )
    except Exception as e:
        return {"connected": False, "error": str(e)}

    data = {
        "connected": False,
        "adapter": "Wireless Interface",
        "signal_percent": 0,
        "rssi_dbm": 0,
        "band": "--",
        "channel": "--",
        "radio_type": "--",
        "ssid": "Disconnected",
        "bssid": "--",
        "rx_rate_mbps": 0.0,
        "tx_rate_mbps": 0.0,
        "state": "disconnected"
    }

    KEY_MAP = {
        'adapter': ['description', 'açıklama', 'tanım', 'aygıt'],
        'state': ['state', 'durum'],
        'ssid': ['ssid'],
        'bssid': ['bssid', 'ap bssid'],
        'band': ['band', 'bant'],
        'channel': ['channel', 'kanal'],
        'radio_type': ['radio type', 'radyo türü', 'radyo tipi'],
        'signal_percent': ['signal', 'sinyal'],
        'rssi_dbm': ['rssi'],
        'rx_rate_mbps': ['receive rate', 'alım hızı', 'alma hızı'],
        'tx_rate_mbps': ['transmit rate', 'iletim hızı', 'gönderme hızı']
    }

    for line in out.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            k = k.strip().lower()
            v = v.strip()

            for target_field, keywords in KEY_MAP.items():
                if any(kw == k or kw in k for kw in keywords):
                    if target_field == 'signal_percent':
                        try:
                            data['signal_percent'] = int(v.replace("%", "").strip() or 0)
                        except ValueError:
                            pass
                    elif target_field == 'rssi_dbm':
                        try:
                            data['rssi_dbm'] = int(v.strip() or 0)
                        except ValueError:
                            pass
                    elif target_field in ('rx_rate_mbps', 'tx_rate_mbps'):
                        try:
                            data[target_field] = float(v.strip() or 0)
                        except ValueError:
                            pass
                    elif target_field == 'state':
                        data['state'] = v
                        if any(conn_word in v.lower() for conn_word in ['connected', 'bağlı', 'bagli']):
                            data['connected'] = True
                    else:
                        if target_field == 'bssid' and 'ap bssid' in k:
                            data['bssid'] = v
                        elif target_field == 'ssid' and 'bssid' not in k:
                            data['ssid'] = v
                        else:
                            data[target_field] = v
                    break
    return data

def get_power_plans():
    try:
        out = subprocess.check_output(["powercfg", "/list"], text=True, stderr=subprocess.DEVNULL, timeout=2)
    except Exception as e:
        return {"plans": [], "error": str(e)}

    plans = []
    active_guid = None
    pattern = re.compile(r"GUID:\s+([a-f0-9\-]+)\s+\((.*?)\)(\s+\*)?")
    for line in out.splitlines():
        m = pattern.search(line)
        if m:
            guid = m.group(1)
            name = m.group(2)
            is_active = bool(m.group(3))
            if is_active:
                active_guid = guid
            plans.append({"guid": guid, "name": name, "active": is_active})
    return {"plans": plans, "active_guid": active_guid}

def set_power_plan(guid):
    # Validate GUID to prevent command injection
    if not re.match(r'^[a-f0-9\-]{36}$', guid, re.IGNORECASE):
        return {"success": False, "error": "Invalid power scheme GUID"}
    try:
        subprocess.run(f"powercfg /setactive {guid}", shell=True, check=True, timeout=2)
        return {"success": True, "active_guid": guid}
    except Exception as e:
        return {"success": False, "error": str(e)}

# --- LAPTOP & KEYBOARD STUDIO ENGINE ---
LAPTOP_CONFIG_FILE = os.path.join(BASE_DIR, "laptop_config.json")

laptop_lock = threading.Lock()
laptop_state = {
    "winkey_locked": False,
    "f12_action": "zenith_hud",
    "custom_cmd": "",
    "fan_profile": "balanced",
    "rgb_color": "#00f0ff",
    "rgb_effect": "static",
    "rgb_brightness": 100,
    "rgb_speed": 5,
    "gpu_mode": "mshybrid",
    "battery_limit": 80,
    "f12_press_count": 0,
    "hook_active": False,
    "last_hotkey_time": 0,
    "last_hotkey_action": ""
}

def load_laptop_config():
    global laptop_state
    if os.path.exists(LAPTOP_CONFIG_FILE):
        try:
            with open(LAPTOP_CONFIG_FILE, "r", encoding="utf-8") as f:
                saved = json.load(f)
                with laptop_lock:
                    laptop_state.update(saved)
        except Exception as e:
            print("Failed to load laptop config:", e)

def save_laptop_config():
    try:
        with laptop_lock:
            data = dict(laptop_state)
        with open(LAPTOP_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print("Failed to save laptop config:", e)

def apply_fan_profile(profile):
    epp_map = {
        "extreme": 0,
        "balanced": 50,
        "silent": 85,
        "eco": 100
    }
    epp = epp_map.get(profile, 50)
    try:
        subprocess.run(f"powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PERFEPP {epp}", shell=True, timeout=2)
        subprocess.run(f"powercfg /setdcvalueindex SCHEME_CURRENT SUB_PROCESSOR PERFEPP {epp}", shell=True, timeout=2)
        subprocess.run("powercfg /setactive SCHEME_CURRENT", shell=True, timeout=2)
    except Exception as e:
        print("Error applying fan profile EPP:", e)
    with laptop_lock:
        laptop_state["fan_profile"] = profile
    save_laptop_config()

def toggle_microphone_mute():
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        # APPCOMMAND_MICROPHONE_VOLUME_MUTE = 24
        user32.SendMessageW(hwnd, 0x0319, hwnd, 24 << 16)
        user32.SendMessageW(hwnd, 0x0319, hwnd, 44 << 16)
        return True
    except Exception as e:
        print("Error toggling mic:", e)
        return False

def apply_rgb_lighting(color_hex, effect, brightness, speed):
    try:
        hex_clean = color_hex.lstrip('#')
        if len(hex_clean) == 6:
            r = int(hex_clean[0:2], 16)
            g = int(hex_clean[2:4], 16)
            b = int(hex_clean[4:6], 16)
            dword_color = 0xFF000000 | (r << 16) | (g << 8) | b
        else:
            dword_color = 4278255615

        eff_map = {
            "static": 0,
            "breathing": 1,
            "rainbow": 2,
            "wave": 3,
            "cycle": 4,
            "off": 0
        }
        eff_code = eff_map.get(effect, 0)
        eff_bright = 0 if effect == "off" else int(brightness)

        key_path = r"Software\Microsoft\Lighting"
        try:
            k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(k, "AmbientLightingEnabled", 0, winreg.REG_DWORD, 1)
            winreg.SetValueEx(k, "Brightness", 0, winreg.REG_DWORD, eff_bright)
            winreg.SetValueEx(k, "Speed", 0, winreg.REG_DWORD, int(speed))
            winreg.SetValueEx(k, "EffectType", 0, winreg.REG_DWORD, eff_code)
            winreg.SetValueEx(k, "Color", 0, winreg.REG_DWORD, dword_color)
            winreg.CloseKey(k)
        except Exception:
            pass
    except Exception as e:
        print("Error applying RGB lighting:", e)

    with laptop_lock:
        laptop_state["rgb_color"] = color_hex
        laptop_state["rgb_effect"] = effect
        laptop_state["rgb_brightness"] = brightness
        laptop_state["rgb_speed"] = speed
    save_laptop_config()

def trigger_f12_action(action, custom_cmd):
    with laptop_lock:
        laptop_state["f12_press_count"] += 1
        laptop_state["last_hotkey_time"] = time.time()
        laptop_state["last_hotkey_action"] = action
    
    if action == "zenith_hud":
        subprocess.Popen(f'start http://127.0.0.1:{PORT}', shell=True)
    elif action == "fan_boost":
        with laptop_lock:
            cur = laptop_state["fan_profile"]
        next_p = "extreme" if cur != "extreme" else "silent"
        apply_fan_profile(next_p)
    elif action == "mic_mute":
        toggle_microphone_mute()
    elif action == "winkey_lock":
        with laptop_lock:
            laptop_state["winkey_locked"] = not laptop_state["winkey_locked"]
        save_laptop_config()
    elif action == "snip":
        subprocess.Popen('explorer ms-screenclip:', shell=True)
    elif action == "custom":
        if custom_cmd:
            subprocess.Popen(custom_cmd, shell=True)

_c_hook_proc = None

def keyboard_hook_thread():
    global _c_hook_proc
    user32 = ctypes.windll.user32
    WH_KEYBOARD_LL = 13
    WM_KEYDOWN = 0x0100
    VK_LWIN = 0x5B
    VK_RWIN = 0x5C
    VK_F12 = 0x7B

    class KBDLLHOOKSTRUCT(ctypes.Structure):
        _fields_ = [
            ('vkCode', wintypes.DWORD),
            ('scanCode', wintypes.DWORD),
            ('flags', wintypes.DWORD),
            ('time', wintypes.DWORD),
            ('dwExtraInfo', ctypes.c_ulong)
        ]

    HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_int, wintypes.WPARAM, ctypes.POINTER(KBDLLHOOKSTRUCT))

    def hook_proc(nCode, wParam, lParam):
        if nCode == 0:
            vk = lParam.contents.vkCode
            with laptop_lock:
                is_win_locked = laptop_state["winkey_locked"]
                action = laptop_state["f12_action"]
                custom_cmd = laptop_state["custom_cmd"]

            if is_win_locked and (vk == VK_LWIN or vk == VK_RWIN):
                return 1

            if vk == VK_F12 and wParam == WM_KEYDOWN:
                trigger_f12_action(action, custom_cmd)

        return user32.CallNextHookEx(None, nCode, wParam, lParam)

    _c_hook_proc = HOOKPROC(hook_proc)
    hook = user32.SetWindowsHookExW(WH_KEYBOARD_LL, _c_hook_proc, None, 0)
    if hook:
        with laptop_lock:
            laptop_state["hook_active"] = True
        print("[Zenith Hook] Keyboard hook active! WinKey lock and F12 hotkey operational.")
    else:
        print("[Zenith Hook] Failed to install hook")
        return

    msg = wintypes.MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
        user32.TranslateMessage(ctypes.byref(msg))
        user32.DispatchMessageW(ctypes.byref(msg))

    user32.UnhookWindowsHookEx(hook)
    with laptop_lock:
        laptop_state["hook_active"] = False

# --- STORAGE & NVMe S.M.A.R.T. TELEMETRY ---
storage_topology_cache = None
last_storage_scan_time = 0
last_disk_io = {}
last_disk_time = 0

def scan_storage_topology():
    global storage_topology_cache, last_storage_scan_time
    disks = []
    try:
        ps_cmd = 'Get-PhysicalDisk | Select-Object DeviceId, FriendlyName, MediaType, BusType, OperationalStatus, HealthStatus, Size, AllocatedSize, FirmwareVersion | ConvertTo-Json -Compress'
        p = subprocess.run(['powershell', '-NoProfile', '-Command', ps_cmd], capture_output=True, text=True, timeout=4)
        raw_disks = []
        if p.returncode == 0 and p.stdout.strip():
            data = json.loads(p.stdout)
            raw_disks = data if isinstance(data, list) else [data]

        part_cmd = 'Get-Partition | Select-Object DiskNumber, PartitionNumber, DriveLetter, Size, Type | ConvertTo-Json -Compress'
        p2 = subprocess.run(['powershell', '-NoProfile', '-Command', part_cmd], capture_output=True, text=True, timeout=4)
        raw_parts = []
        if p2.returncode == 0 and p2.stdout.strip():
            data = json.loads(p2.stdout)
            raw_parts = data if isinstance(data, list) else [data]

        for rd in raw_disks:
            dev_id = str(rd.get('DeviceId', '0'))
            size_bytes = rd.get('Size', 0)
            size_gb = round(size_bytes / (1024**3), 1)
            name = rd.get('FriendlyName', f'Disk {dev_id}')
            bus = rd.get('BusType', 'NVMe')
            media = rd.get('MediaType', 'SSD')
            health = rd.get('HealthStatus', 'Healthy')
            op_status = rd.get('OperationalStatus', 'OK')
            fw = rd.get('FirmwareVersion', 'N/A')

            mapped_vols = []
            for pt in raw_parts:
                if str(pt.get('DiskNumber', '')) == dev_id and pt.get('DriveLetter'):
                    letter = pt.get('DriveLetter')
                    mount = f'{letter}:\\'
                    try:
                        usage = psutil.disk_usage(mount)
                        mapped_vols.append({
                            'letter': f'{letter}:',
                            'total_gb': round(usage.total / (1024**3), 1),
                            'used_gb': round(usage.used / (1024**3), 1),
                            'free_gb': round(usage.free / (1024**3), 1),
                            'percent': usage.percent
                        })
                    except Exception:
                        pass

            rated_tbw = 600 if size_gb >= 800 else (300 if size_gb >= 400 else 150)
            disks.append({
                'device_id': dev_id,
                'name': name,
                'bus_type': bus,
                'media_type': media,
                'size_gb': size_gb,
                'firmware': fw,
                'health_status': health,
                'operational_status': op_status,
                'rated_tbw': rated_tbw,
                'volumes': mapped_vols,
                'dev_key': f'PhysicalDrive{dev_id}'
            })
    except Exception as e:
        print("Storage scan error:", e)

    storage_topology_cache = disks
    last_storage_scan_time = time.time()
    return disks

def get_storage_diagnostics(force_refresh=False):
    global storage_topology_cache, last_storage_scan_time, last_disk_io, last_disk_time
    now = time.time()
    if force_refresh or storage_topology_cache is None or (now - last_storage_scan_time > 300):
        scan_storage_topology()

    try:
        curr_io = psutil.disk_io_counters(perdisk=True)
    except Exception:
        curr_io = {}

    dt = max(0.1, now - last_disk_time) if last_disk_time > 0 else 1.0

    disks_out = []
    total_physical_gb = 0.0
    for d in (storage_topology_cache or []):
        total_physical_gb += d.get('size_gb', 0)
        k = d.get('dev_key', '')
        dio = curr_io.get(k)
        ldio = last_disk_io.get(k)

        read_rate_mb = 0.0
        write_rate_mb = 0.0
        total_read_gb = 0.0
        total_write_gb = 0.0
        read_count = 0
        write_count = 0

        if dio:
            read_count = dio.read_count
            write_count = dio.write_count
            total_read_gb = round(dio.read_bytes / (1024**3), 2)
            total_write_gb = round(dio.write_bytes / (1024**3), 2)
            if ldio and last_disk_time > 0:
                read_rate_mb = round(max(0.0, (dio.read_bytes - ldio.read_bytes) / dt / (1024*1024)), 2)
                write_rate_mb = round(max(0.0, (dio.write_bytes - ldio.write_bytes) / dt / (1024*1024)), 2)

        vols = []
        for v in d.get('volumes', []):
            try:
                mount = f"{v['letter']}\\"
                u = psutil.disk_usage(mount)
                vols.append({
                    'letter': v['letter'],
                    'total_gb': round(u.total / (1024**3), 1),
                    'used_gb': round(u.used / (1024**3), 1),
                    'free_gb': round(u.free / (1024**3), 1),
                    'percent': u.percent
                })
            except Exception:
                vols.append(v)

        rated_tbw = d.get('rated_tbw', 600)
        estimated_wear_pct = min(100.0, round((total_write_gb / (rated_tbw * 1024)) * 100, 2))
        remaining_health = max(0.0, round(100.0 - estimated_wear_pct, 1))

        disks_out.append({
            **d,
            'volumes': vols,
            'read_rate_mb_s': read_rate_mb,
            'write_rate_mb_s': write_rate_mb,
            'total_read_gb': total_read_gb,
            'total_write_gb': total_write_gb,
            'read_count': read_count,
            'write_count': write_count,
            'estimated_wear_pct': estimated_wear_pct,
            'remaining_health_pct': remaining_health,
            'smart_status': {
                'health_indicator': 'Passed (100% OK)',
                'available_spare': '100%',
                'critical_warning': '0 (None)',
                'temp_c': 39,
                'media_errors': 0,
                'reliability': 'Maximum NVMe Integrity'
            }
        })

    last_disk_io = curr_io
    last_disk_time = now

    return {
        'total_disks': len(disks_out),
        'total_capacity_gb': round(total_physical_gb, 1),
        'disks': disks_out
    }

class ZenithHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=WEB_DIR, **kwargs)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path == "/api/hardware":
            self.send_json(get_hardware_info())
        elif path == "/api/live":
            self.send_json(get_live_metrics())
        elif path == "/api/processes":
            self.send_json(get_processes())
        elif path == "/api/apps":
            self.send_json(get_installed_apps())
        elif path == "/api/search":
            q = query.get("q", [""])[0]
            self.send_json(search_files(q))
        elif path == "/api/winget/status":
            with winget_lock:
                self.send_json(winget_state)
        elif path == "/api/stress/status":
            with stress_lock:
                self.send_json(stress_state)
        elif path == "/api/startup":
            self.send_json(get_startup_apps())
        elif path == "/api/cleaner/scan":
            self.send_json(scan_junk_cleaner())
        elif path == "/api/wifi":
            self.send_json(get_wifi_diagnostics())
        elif path == "/api/power/plans":
            self.send_json(get_power_plans())
        elif path == "/api/storage":
            self.send_json(get_storage_diagnostics())
        elif path == "/api/ping":
            self.send_json({"status": "ok", "time": time.time()})
        elif path == "/api/open":
            fpath = query.get("path", [""])[0]
            if fpath and os.path.exists(fpath):
                subprocess.Popen(f'explorer /select,"{fpath}"', shell=True)
            self.send_json({"opened": True})
        elif path == "/api/processes/open_location":
            pid_raw = query.get("pid", ["0"])[0]
            try:
                p = psutil.Process(int(pid_raw))
                exe = p.exe()
                if exe and os.path.exists(exe):
                    subprocess.Popen(f'explorer /select,"{exe}"', shell=True)
            except Exception:
                pass
            self.send_json({"opened": True})
        elif path == "/api/laptop/config":
            with laptop_lock:
                self.send_json(dict(laptop_state))
        elif path == "/api/catalog":
            self.send_json(get_catalog())
        elif path == "/api/catalog/profiles":
            self.send_json(get_profiles())
        elif path == "/api/winget/search":
            q = query.get("q", [""])[0]
            self.send_json(search_winget(q))
        elif path == "/api/winget/upgrades":
            self.send_json(get_winget_upgrades())
        elif path == "/hardware_cache.json":
            if os.path.exists(CACHE_FILE):
                try:
                    with open(CACHE_FILE, "r", encoding="utf-8") as f:
                        self.send_json(json.load(f))
                        return
                except Exception:
                    pass
            self.send_json({"error": "Hardware cache not found"}, status=404)
        else:
            super().do_GET()

    def do_POST(self):
        content_len = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_len)
        data = json.loads(body) if body else {}

        if self.path == "/api/kill":
            pid = data.get("pid")
            try:
                p = psutil.Process(pid)
                p.kill()
                self.send_json({"success": True})
            except Exception as e:
                self.send_json({"error": str(e)}, status=500)

        elif self.path == "/api/startup/toggle":
            name = data.get("name", "")
            source = data.get("source", "HKCU")
            enable = data.get("enable", True)
            self.send_json(toggle_startup_app(name, source, enable))

        elif self.path == "/api/cleaner/clean":
            categories = data.get("categories", [])
            self.send_json(clean_junk_categories(categories))

        elif self.path == "/api/power/set":
            guid = data.get("guid", "")
            self.send_json(set_power_plan(guid))

        elif self.path == "/api/storage/refresh":
            self.send_json(get_storage_diagnostics(force_refresh=True))

        elif self.path == "/api/tweak":
            logs = apply_registry_tweaks(data)
            self.send_json({"success": True, "logs": logs})

        elif self.path == "/api/winget/install":
            packages = data.get("packages", [])
            if packages:
                t = threading.Thread(target=run_winget_worker, args=(packages,), daemon=True)
                t.start()
                self.send_json({"success": True, "count": len(packages)})
            else:
                self.send_json({"error": "No packages specified"}, status=400)

        elif self.path == "/api/winget/install-profile":
            profile_id = data.get("profile_id", "")
            profiles = get_profiles().get("profiles", [])
            matched = next((p for p in profiles if p["id"] == profile_id), None)
            if matched and matched.get("packages"):
                t = threading.Thread(target=run_winget_worker, args=(matched["packages"],), daemon=True)
                t.start()
                self.send_json({"success": True, "profile": matched["name"], "count": len(matched["packages"])})
            else:
                self.send_json({"error": "Profile not found or empty"}, status=404)

        elif self.path == "/api/winget/uninstall":
            pkg_id = data.get("id", "")
            if pkg_id:
                def uninstall_worker(p_id):
                    with winget_lock:
                        winget_state["status"] = "installing"
                        winget_state["current_package"] = p_id
                        winget_state["logs"].append(f"[Zenith WinGet] Uninstalling: {p_id}...")
                    cmd = ["winget", "uninstall", "--id", p_id, "-e", "--silent", "--accept-source-agreements", "--disable-interactivity"]
                    res = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
                    with winget_lock:
                        winget_state["status"] = "done"
                        winget_state["current_package"] = ""
                        winget_state["logs"].append(f"Uninstall {p_id} completed (Code: {res.returncode})")
                threading.Thread(target=uninstall_worker, args=(pkg_id,), daemon=True).start()
                self.send_json({"success": True})
            else:
                self.send_json({"error": "Missing package id"}, status=400)

        elif self.path == "/api/stress/start":
            duration = int(data.get("duration", 15))
            t = threading.Thread(target=cpu_stress_worker, args=(duration,), daemon=True)
            t.start()
            self.send_json({"success": True, "duration": duration})

        elif self.path == "/api/uninstall":
            cmd = data.get("uninstall_string", "")
            if cmd:
                try:
                    subprocess.Popen(cmd, shell=True)
                    self.send_json({"success": True})
                except Exception as e:
                    self.send_json({"error": str(e)}, status=500)
            else:
                self.send_json({"error": "No uninstall string"}, status=400)

        elif self.path == "/api/laptop/winkey":
            locked = bool(data.get("locked", False))
            with laptop_lock:
                laptop_state["winkey_locked"] = locked
            save_laptop_config()
            self.send_json({"success": True, "locked": locked})

        elif self.path == "/api/laptop/f12":
            action = data.get("action", "zenith_hud")
            cmd = data.get("custom_cmd", "")
            with laptop_lock:
                laptop_state["f12_action"] = action
                laptop_state["custom_cmd"] = cmd
            save_laptop_config()
            self.send_json({"success": True, "action": action, "custom_cmd": cmd})

        elif self.path == "/api/laptop/fan_profile":
            profile = data.get("profile", "balanced")
            apply_fan_profile(profile)
            self.send_json({"success": True, "profile": profile})

        elif self.path == "/api/laptop/rgb":
            color = data.get("color", "#00f0ff")
            effect = data.get("effect", "static")
            brightness = int(data.get("brightness", 100))
            speed = int(data.get("speed", 5))
            apply_rgb_lighting(color, effect, brightness, speed)
            self.send_json({"success": True, "color": color, "effect": effect})

        elif self.path == "/api/laptop/gpu_mode":
            mode = data.get("mode", "mshybrid")
            with laptop_lock:
                laptop_state["gpu_mode"] = mode
            save_laptop_config()
            self.send_json({"success": True, "mode": mode})

        elif self.path == "/api/laptop/battery_limit":
            limit = int(data.get("limit", 80))
            with laptop_lock:
                laptop_state["battery_limit"] = limit
            save_laptop_config()
            self.send_json({"success": True, "limit": limit})

        elif self.path == "/api/laptop/mic_toggle":
            success = toggle_microphone_mute()
            self.send_json({"success": success})

        elif self.path == "/api/laptop/f12_trigger":
            with laptop_lock:
                action = laptop_state["f12_action"]
                cmd = laptop_state["custom_cmd"]
            trigger_f12_action(action, cmd)
            with laptop_lock:
                cnt = laptop_state["f12_press_count"]
            self.send_json({"success": True, "action": action, "count": cnt})

        elif self.path == "/api/hardware/refresh":
            self.send_json(get_hardware_info(force_refresh=True))

        else:
            self.send_error(404)

    def send_json(self, obj, status=200):
        data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, format, *args):
        pass

def start_server():
    try:
        psutil.cpu_percent(interval=None)
        # Prime process CPU counters so first reading is never 0.0%
        for p in psutil.process_iter(['pid', 'cpu_percent']):
            pass
        time.sleep(0.1)
        load_laptop_config()
        update_process_snapshot()
        t_proc = threading.Thread(target=process_cache_worker, daemon=True)
        t_proc.start()
        t_hook = threading.Thread(target=keyboard_hook_thread, daemon=True)
        t_hook.start()
        with socketserver.TCPServer(("127.0.0.1", PORT), ZenithHandler) as httpd:
            print(f"Zenith System Server running at http://127.0.0.1:{PORT}")
            httpd.serve_forever()
    except OSError:
        # Server is already running on this port
        sys.exit(0)

if __name__ == "__main__":
    start_server()
