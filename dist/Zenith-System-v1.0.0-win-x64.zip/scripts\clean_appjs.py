import re

with open('web/app.js', 'r', encoding='utf-8') as f:
    text = f.read()

replacements = [
    ("speedBtn.textContent = 'Ölçülüyor...';", "speedBtn.textContent = 'Testing...';"),
    ("badge.textContent = `⚡ GÜNCELLE (${data.latest_version})`;", "badge.textContent = `⚡ UPDATE (${data.latest_version})`;"),
    ("badge.title = `Yeni sürüm mevcut (${data.latest_version})! İndirmek için tıklayın.`;", "badge.title = `New version available (${data.latest_version})! Click to download.`;"),
    ("alert('Zenith System güncel! En son sürümü kullanıyorsunuz.');", "alert('Zenith System is up to date! You are using the latest version.');"),
    ("alert('Güncelleme kontrolü başarısız: ' + e.message);", "alert('Update check failed: ' + e.message);"),
    ("Katalog yüklenirken hata oluştu:", "Error loading catalog:"),
    ("upgradesBtn.innerHTML = '<span>⏳ Taranıyor...</span>';", "upgradesBtn.innerHTML = '<span>⏳ Scanning...</span>';"),
    ("Güncellemeler taranıyor...", "Scanning for updates..."),
    ("Güncellemeler taranırken hata oluştu:", "Error scanning updates:"),
    ("upgradesBtn.innerHTML = '<span>🔄 Güncellemeleri Tara</span>';", "upgradesBtn.innerHTML = '<span>🔄 Check for Updates</span>';"),
    ("alert('Lütfen kurmak için en az bir paket seçin.');", "alert('Please select at least one package to install.');"),
    ("if (!res.ok) throw new Error('API isteği başarısız oldu.');", "if (!res.ok) throw new Error('API request failed.');"),
    ("Paket Hazır</div>", "Packages Ready</div>"),
    ("Bu kategoride paket bulunamadı.", "No packages found in this category."),
    ('için resmi Microsoft WinGet deposunda sonuç bulunamadı.', 'returned no results in Microsoft WinGet repo.'),
    ('Farklı bir arama terimi deneyin.', 'Try searching for an alternative package name.'),
    ('canlı sonuç bulundu:', 'results found:'),
    ('• Sürüm:', '• Version:'),
    ('Son', 'Latest'),
    ('Arama sırasında hata oluştu:', 'Error during package search:'),
    ('Tebrikler, tüm yazılımlarınız güncel!', 'All applications are up to date!'),
    ('Sisteminizdeki WinGet paketleri en güncel sürümde.', 'All WinGet packages on this system are running latest versions.'),
    ('Güncellenebilir Uygulamalar', 'Upgradable Applications'),
    ('Aşağıdaki uygulamaların daha yeni sürümleri mevcut', 'Newer versions are available for the following packages'),
    ('⚡ Hepsini Güncelle', '⚡ Upgrade All'),
    ("onclick=\"installSingleWingetPackage('${u.id}')\">Güncelle</button>", "onclick=\"installSingleWingetPackage('${u.id}')\">Upgrade</button>"),
    ("Arka plan kurulum kuyruğu başlatıldı...", "Background installation queue initiated..."),
    ("Bağlantılar yüklenirken hata oluştu:", "Error loading connections:"),
    ("Onarım araçları yüklenirken hata oluştu:", "Error loading repair tools:"),
    ("Onarım araçları alınırken hata oluştu:", "Error retrieving repair tools:"),
    ("Birkaç dakika sürebilir. Başlatılsın mı?", "It may take several minutes. Proceed?"),
    ("✓ Derin System Repair Başarıyla Tamamlandı!", "✓ Deep System Repair Completed Successfully!"),
    ("❌ Derin System Repair Hatayla Sonlandı", "❌ Deep System Repair Ended with Errors"),
    ("Kurallar yüklenirken hata oluştu:", "Error loading rules:"),
    ("Tanımlı otomasyon kuralı bulunmuyor.", "No automation rules defined."),
    ("Tetiklendi / Aktif", "Triggered / Active"),
    ("Ön Tanımlı", "Preset"),
    ("Prizden Çekilmiş", "On Battery"),
    ("Az önce", "Just now"),
    ("Tüm soketler, PCIe hatları ve sistem veri yolları hatasız çalışıyor.", "All sockets, PCIe lanes, and system buses are operating without faults.")
]

for src, dst in replacements:
    text = text.replace(src, dst)

with open('web/app.js', 'w', encoding='utf-8') as f:
    f.write(text)

remaining = len(re.findall(r'[çÇğĞıİöÖşŞüÜ]', text))
print(f"app.js cleaned. Remaining Turkish characters: {remaining}")
