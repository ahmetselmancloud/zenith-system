import re

with open('src/obd_diagnostics.py', 'r', encoding='utf-8') as f:
    text = f.read()

replacements = [
    ('whea_details = "WHEA donanım logları temiz. İşlemci çekirdeği voltaj düşmesi (MCE) veya L1/L2 önbellek hatası bulunmuyor."', 'whea_details = "WHEA hardware logs clean. No processor core voltage drops (MCE) or L1/L2 cache errors detected."'),
    ('"subsystem": "WHEA Donanım Katmanı"', '"subsystem": "WHEA Hardware Layer"'),
    ('Windows {fatal_count} adet kritik donanım hatası (WHEA Fatal Error) kaydetti.', 'Windows logged {fatal_count} critical hardware faults (WHEA Fatal Error).'),
    ('"recommendation": "Donanım voltajı, RAM frekansı ve anakart BIOS güncelliğini kontrol edin."', '"recommendation": "Inspect hardware voltages, memory frequencies, and verify motherboard BIOS updates."'),
    ('"subsystem": "İşlemci (CPU)"', '"subsystem": "Processor (CPU)"'),
    ('{mce_count} adet İşlemci Machine Check Exception (MCE) voltaj dalgalanması algılandı.', '{mce_count} processor Machine Check Exception (MCE) voltage anomalies detected.'),
    ('"recommendation": "Aşırı ısınma veya dengesiz voltaj/undervolt kaynaklı olabilir. Sıcaklıkları kontrol edin."', '"recommendation": "May be caused by thermal throttling or voltage fluctuations. Inspect CPU temperatures."'),
    ('"subsystem": "PCIe Veri Yolu"', '"subsystem": "PCIe Bus"'),
    ('{aer_count} adet PCIe Advanced Error Reporting (AER) veri paketi düşmesi düzeltildi.', '{aer_count} PCIe Advanced Error Reporting (AER) packet drop events corrected.'),
    ('"recommendation": "PCIe yuvasında toz veya anakart ile cihaz arasında hafif sinyal paraziti olabilir."', '"recommendation": "Check for dust in PCIe slots or loose connector contacts."'),
    ('"title": "WHEA & Donanım Kararlılığı"', '"title": "WHEA & Hardware Stability"'),
    ('port_details = "USB, kulaklık ve çevre birimi soketlerinde temassızlık veya anlık kopma tespit edilmedi."', 'port_details = "No loose contacts, port disconnects, or device flapping detected across peripheral ports."'),
    ('"Bilinmeyen Aygıt"', '"Unknown Device"'),
    ('aygıtta bağlantı hatası veya sürücü kilitlenmesi saptandı', 'device(s) reported connection errors or driver hangs'),
    ('"subsystem": "Soket & Kablo Girişi"', '"subsystem": "Socket & Cable Port"'),
    ('Soket veya kabloda temassızlık:', 'Intermittent port or cable connection:'),
    ('bağlantı sorunları raporluyor.', 'reporting connection drops.'),
    ('"recommendation": "Kabloyu çıkarıp tekrar takın, farklı bir USB portu deneyin veya kabloyu değiştirin."', '"recommendation": "Re-plug cable firmly, try an alternate port, or inspect cable integrity."'),
    ('"title": "Kablo & Soket Kararlılığı (Flapping)"', '"title": "Cable & Socket Stability (Flapping)"'),
    ('pcie_details = "GPU PCIe bağlantısı tam hızda çalışıyor."', 'pcie_details = "GPU PCIe bus link operating at optimal speed."'),
    ('Bant genişliği tam."', 'Full bus bandwidth."'),
    ('Boşta güç tasarrufu olabilir."', 'May represent power saving at idle."'),
    ('pcie_details = "NVIDIA dGPU PCIe veri yolu taranamadı (iGPU aktif veya sürücü sorgulanamadı)."', 'pcie_details = "NVIDIA dGPU PCIe link not queried (iGPU active or driver query bypass)."'),
    ('"title": "PCIe Veri Yolu & GPU Hatları"', '"title": "PCIe Bus & GPU Lanes"'),
    ('storage_details = "NVMe / SATA kontrolcülerinde veri bozulması (CRC) veya CRC paket hatası saptanmadı."', 'storage_details = "No CRC bus transfer errors or storage interface corruption detected."'),
    ('"title": "Disk Arayüzü & Veri Bütünlüğü"', '"title": "Storage Interface & Integrity"'),
    ('power_details = "Anakart ana güç rayı ve nominal voltaj seviyeleri stabil."', 'power_details = "Motherboard primary power rails and nominal voltage levels stable."'),
    ('Düşük voltajda ani kapanma riskine karşı prize takın."', 'Connect to AC power to avoid sudden shutdown from voltage drops."'),
    ('"title": "Güç Dağıtımı & Voltaj Rayları"', '"title": "Power Rails & Voltage Distribution"'),
    ('summary_text = "Tüm donanım hatları, PCIe veri yolları ve USB/Ses portları kusursuz durumda."', 'summary_text = "All hardware rails, PCIe lanes, and peripheral ports are in pristine condition."'),
    ('summary_text = "DİKKAT: Sistemde donanım seviyesinde arıza veya kritik soket kararsızlığı tespit edildi!"', 'summary_text = "ATTENTION: Hardware faults or critical connection instabilities detected!"'),
    ('summary_text = "UYARI: Bazı soketlerde veya PCIe hatlarında hafif temassızlık/parazit gözlendi."', 'summary_text = "WARNING: Minor connection fluttering or signal jitter observed on some ports/lanes."'),
    ('_cached_report["summary"] = "Arıza kodları kullanıcı tarafından sıfırlandı."', '_cached_report["summary"] = "Trouble codes were manually cleared by user."')
]

for src, dst in replacements:
    text = text.replace(src, dst)

with open('src/obd_diagnostics.py', 'w', encoding='utf-8') as f:
    f.write(text)

remaining = len(re.findall(r'[çÇğĞıİöÖşŞüÜ]', text))
print(f"OBD translated. Remaining Turkish characters: {remaining}")
