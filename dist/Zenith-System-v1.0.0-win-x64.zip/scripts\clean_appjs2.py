import re

with open('web/app.js', 'r', encoding='utf-8') as f:
    text = f.read()

replacements = [
    ('🔍 Microsoft WinGet deposunda "${q}" aranıyor...', '🔍 Searching "${q}" in Microsoft WinGet repo...'),
    ('🔄 Sisteminizdeki kurulu uygulamalar için güncellemeler taranıyor...', '🔄 Scanning for updates across installed applications...'),
    ('Güncelleme taraması başarısız oldu:', 'Update scan failed:'),
    ('Farklı bir arama terimi deneyin (örn: chrome, vlc, discord).', 'Try an alternate query (e.g. chrome, vlc, discord).'),
    ('"${query}" için <strong>${results.length}</strong> results found:', 'Found <strong>${results.length}</strong> results for "${query}":'),
    ('Kaynak: Microsoft WinGet Repository', 'Source: Microsoft WinGet Repository'),
    ('⚡ Şimdi Kur', '⚡ Install Now'),
    ('Sisteminizdeki WinGet paketleri için bekleyen yeni bir güncelleme bulunmuyor.', 'No pending upgrades found for installed WinGet packages.'),
    ('Ağ bağlantıları alınamadı:', 'Failed to load network connections:'),
    ('Eşleşen aktif bağlantı bulunamadı.', 'No matching active connections found.'),
    ('Onarım araçları taranıyor...', 'Scanning repair tools...'),
    ('Onarım araçları yüklenemedi:', 'Failed to load repair tools:'),
    ('Tanımlı kural bulunmuyor.', 'No automation rules defined.'),
    ("İzlemede", "Watching"),
    ("Devre Dışı", "Disabled"),
    ("Özel Kural", "Custom Rule"),
    ("Pil ≤ %${trigger.threshold} (${trigger.require_discharging ? 'Prizden Çıkarılınca' : ''})", "Battery ≤ ${trigger.threshold}% (${trigger.require_discharging ? 'On Battery' : ''})"),
    ("Saat ${trigger.start_hour}:00 - ${trigger.end_hour}:00", "Hours ${trigger.start_hour}:00 - ${trigger.end_hour}:00"),
    ("Tüm soketler, PCIe hatları ve sistem veri yolları hatasız çalışıyor.", "All sockets, PCIe lanes, and system buses are operating without faults."),
    ("Tüm soketler, PCIe hatları ve", "All sockets, PCIe lanes, and")
]

for src, dst in replacements:
    text = text.replace(src, dst)

with open('web/app.js', 'w', encoding='utf-8') as f:
    f.write(text)

remaining = len(re.findall(r'[çÇğĞıİöÖşŞüÜ]', text))
print(f"app.js cleaned. Remaining Turkish characters: {remaining}")
