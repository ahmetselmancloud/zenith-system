import re

with open('src/report_generator.py', 'r', encoding='utf-8') as f:
    text = f.read()

replacements = [
    ('health_txt = "Sağlıklı (100%)"', 'health_txt = "Healthy (100%)"'),
    ("<tr><td colspan='5' style='text-align:center;'>Disk bilgisi alınamadı</td></tr>", "<tr><td colspan='5' style='text-align:center;'>Disk information unavailable</td></tr>"),
    ("İnceleme gerekebilir.", "Investigation may be required."),
    ("✔ Aktif donanım arızası veya WHEA hatası bulunamadı. Donanım sağlığı mükemmel durumda.", "✔ No active hardware faults or WHEA errors detected. Hardware health is in pristine condition."),
    ("<title>Zenith System — Donanım & Teşhis Raporu ({hostname})</title>", "<title>Zenith System — Hardware & Diagnostic Report ({hostname})</title>"),
    ('onclick="window.print()">🖨️ Yazdır / PDF Olarak Kaydet</button>', 'onclick="window.print()">🖨️ Print / Save as PDF</button>'),
    ("Eksiksiz Donanım Envanteri ve Sağlık Teşhis Raporu (A4 Optimize Edildi)", "Comprehensive Hardware Inventory & Diagnostic Health Report (A4 Optimized)"),
    ("<strong>Kullanıcı:</strong>", "<strong>User:</strong>"),
    ("<strong>Oluşturulma Tarihi:</strong>", "<strong>Generated At:</strong>"),
    ("🩺 PC OBD-II Donanım Sağlığı & Teşhis Özeti", "🩺 PC OBD-II Hardware Health & Diagnostic Summary"),
    ("Donanım Sağlık Skoru:", "Hardware Health Score:"),
    ("WHEA Donanım mimarisi, PCIe veriyolu kararlılığı, PnP aygıt sürücüleri ve sistem olay günlükleri tarandı.", "WHEA Hardware architecture, PCIe bus stability, PnP driver links, and system event logs scanned."),
    ("Hata ve Durum Kayıtları (DTC Kodları)", "Trouble & Diagnostic Logs (DTC Codes)"),
    ("<th>Bileşen</th>", "<th>Component</th>"),
    ("<th>Açıklama</th>", "<th>Description</th>"),
    ("<th>Öneri</th>", "<th>Recommendation</th>"),
    ("⚡ İşlemci (CPU) & Anakart", "⚡ Processor (CPU) & Motherboard"),
    ("İşlemci Modeli", "Processor Model"),
    ("Çekirdek Yapısı", "Core Architecture"),
    ("Fiziksel, {total_threads} Mantıksal Çekirdek", "Physical, {total_threads} Logical Cores"),
    ("BIOS Sürümü & Tarihi", "BIOS Version & Date"),
    ("🎮 Ekran Kartı (GPU) & Bellek (RAM)", "🎮 Graphics Card (GPU) & Memory (RAM)"),
    ("Grafik İşlemcisi (GPU)", "Graphics Processor (GPU)"),
    ("Canlı Telemetri", "Live Telemetry"),
    ("Sıcaklık: {gpu_temp} | Yük: {gpu_load} | VRAM: {gpu_vram}", "Temp: {gpu_temp} | Load: {gpu_load} | VRAM: {gpu_vram}"),
    ("Sistem Belleği (RAM)", "System Memory (RAM)"),
    ("Kullanılabilir RAM", "Available RAM"),
    ("GB Boşta", "GB Free"),
    ("<th>Tür</th>", "<th>Type</th>"),
    ("<th>Sağlık</th>", "<th>Health</th>"),
    ("<th>Sıcaklık</th>", "<th>Temperature</th>"),
    ("🔋 Pil & Güç Durumu", "🔋 Battery & Power Status"),
    ("Pil Sağlığı", "Battery Health"),
    ("Döngü Sayısı (Cycle Count)", "Battery Cycle Count"),
    ("Rapor üretici kimliği:", "Report generator identity:")
]

for src, dst in replacements:
    text = text.replace(src, dst)

with open('src/report_generator.py', 'w', encoding='utf-8') as f:
    f.write(text)

remaining = len(re.findall(r'[çÇğĞıİöÖşŞüÜ]', text))
print(f"Report generator translated. Remaining Turkish characters: {remaining}")
